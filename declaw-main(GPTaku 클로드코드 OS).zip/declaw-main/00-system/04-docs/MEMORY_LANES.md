# Memory Lanes

declaw does not store all memory in one place.

## 1. Durable Memory (Wiki)

Files:
- `memory/MEMORY.md` — wiki index (table of contents)
- `memory/wiki/{category}/{slug}.md` — topic pages

Categories:
- `decisions/` — architecture, technology, direction choices with rationale
- `preferences/` — user conventions, style choices, behavioral defaults
- `project-context/` — stable facts about the project: structure, goals, constraints
- `tool-patterns/` — how specific tools are used, gotchas, configuration
- `pitfalls/` — recurring mistakes, anti-patterns

Use it for:
- stable facts that persist across sessions
- durable preferences and conventions
- recurring pitfalls with solutions
- long-lived project knowledge

Wiki page format:
- YAML frontmatter (title, category, created, updated, tags, status)
- Summary section (feeds the index)
- Detail section (full content)
- Cross-references section (links to related pages)
- Changelog section (append-only edit history)

Operations:
- **Ingest**: check index → create/update page → update index → update cross-refs
- **Query**: read index → follow links to relevant pages (max 3) → Grep if needed
- **Lint**: check orphan pages, broken cross-refs, stale pages (weekly review)

## 2. Agent Continuity Daily Memory

File:
- `memory/daily/YYYY-MM-DD.md`

Use it for:
- compact-safe handoff context
- short next-session continuation notes
- distilled operational state

This lane exists for agent continuity.

## 3. Human-Facing Daily Notes

File:
- `40-personal/41-daily/YYYY-MM-DD.md`

Use it for:
- daily working logs
- notes, drafts, and reflections
- human-readable summaries of the day

This lane exists for the human-facing workspace log.

## Key distinction

- `40-personal/41-daily/` = human notebook
- `memory/daily/` = agent continuity handoff
- `memory/wiki/` = durable topic knowledge (LLM-maintained)

These can overlap, but they should not be treated as the same thing.

Rules:
- human notes may be longer
- continuity notes should stay short and action-oriented
- only promote stable knowledge into wiki pages
- daily logs capture what happened; wiki pages capture what was decided/learned
