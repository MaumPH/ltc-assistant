# Operating Model

declaw operates in this order:

1. `CLAUDE.md` + `.claude/CLAUDE.md` + contracts + rules establish the base context
2. `.claude/commands/` provides the operator-facing entrypoints
3. `.claude/agents/` and subagents provide role separation
4. `.claude/skills/` and `skills/` provide repeatable workflows and capability packs
5. `memory/` and `40-personal/` store continuity and human-facing logs
6. hooks intervene at key lifecycle moments such as `SessionStart`, `PreCompact`, and `Stop`

In short:
- commands = UI
- agents = roles
- skills = capabilities
- hooks = automation
- memory = continuity
