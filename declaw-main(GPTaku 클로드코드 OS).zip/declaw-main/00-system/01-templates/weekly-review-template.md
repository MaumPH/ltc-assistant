# Weekly Review — {{week}}

## Progress

- 

## What Worked

- 

## What Blocked Progress

- 

## Patterns

- 

## Next Week Priorities

- 
