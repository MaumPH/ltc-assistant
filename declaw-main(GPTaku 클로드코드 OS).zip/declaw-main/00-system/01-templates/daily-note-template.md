# Daily Note — {{date}}

## Focus

- 

## In Progress

- 

## Decisions

- 

## Next Actions

- 

## Notes

- 
