# TOOLS

Tool registry for the declaw workspace OS. Each entry points to a detailed
reference in `../03-tools/`.

## Principles

- **Vanilla First**: prefer built-in Claude Code tools before adding wrappers
- **Draft-Approve-Execute**: external-impacting actions need approval before execution
- **Credential Isolation**: never expose raw secrets; use connectors when available
- **Tested Only**: every tool listed here has been verified to work in Claude Code

## Tier 1 — Built-in (always available)

Core tools embedded in Claude Code. No setup needed.

| name | path | what it does |
|------|------|-------------|
| file-ops | [03-tools/file-ops.md](../03-tools/file-ops.md) | Read, Write, Edit, Glob, Grep — file CRUD and search |
| bash | [03-tools/bash.md](../03-tools/bash.md) | Shell command execution, CLI tool gateway |
| web-search | [03-tools/web-search.md](../03-tools/web-search.md) | WebSearch — internet search with site: filters |
| web-fetch | [03-tools/web-fetch.md](../03-tools/web-fetch.md) | WebFetch — URL content extraction (with fallback strategies) |
| agent | [03-tools/agent.md](../03-tools/agent.md) | Task — sub-agent delegation for parallel/complex work |
| computer-use | [03-tools/computer-use.md](../03-tools/computer-use.md) | Desktop GUI control — screenshot, click, type, scroll |

## Tier 2 — CLI (via Bash, check availability)

Common CLI programs. Run `which {tool}` to confirm before use.

| name | path | what it does |
|------|------|-------------|
| git | [03-tools/git.md](../03-tools/git.md) | Version control — commit, branch, diff, log |
| gh | [03-tools/gh.md](../03-tools/gh.md) | GitHub CLI — PR, issue, Actions, release management |
| python3 | [03-tools/python3.md](../03-tools/python3.md) | Scripting, data parsing, JSON/CSV/XML processing |
| curl | [03-tools/curl.md](../03-tools/curl.md) | HTTP requests — API access, fallback web fetching |
| pandoc | [03-tools/pandoc.md](../03-tools/pandoc.md) | Document conversion — md/docx/pdf/html |
| ffmpeg | [03-tools/ffmpeg.md](../03-tools/ffmpeg.md) | Media processing — audio/video conversion, extraction |
| whisper | [03-tools/whisper.md](../03-tools/whisper.md) | Speech-to-text transcription from audio/video files |
| osascript | [03-tools/osascript.md](../03-tools/osascript.md) | macOS automation — Notes, Reminders, Calendar (macOS only) |
| say | [03-tools/say.md](../03-tools/say.md) | macOS 내장 TTS — 텍스트 음성 변환 (macOS only) |
| pdf-tools | [03-tools/pdf-tools.md](../03-tools/pdf-tools.md) | PDF 생성/병합/분할/테이블추출/OCR (Python libs) |
| office-docs | [03-tools/office-docs.md](../03-tools/office-docs.md) | Word/Excel/PPT 생성/편집 (openpyxl, docx-js, pptxgenjs, soffice) |
| image-tools | [03-tools/image-tools.md](../03-tools/image-tools.md) | 프로그래밍 이미지/GIF 생성 (Pillow) |
| wiki-memory | [03-tools/wiki-memory.md](../03-tools/wiki-memory.md) | LLM Wiki 패턴 메모리 — 인덱스 + 주제별 위키 페이지 (Read/Write/Grep만) |

## Tier 3 — Public API (no auth, via curl)

Free endpoints accessible without API keys. Use through Bash + curl + python3.

| name | path | what it does |
|------|------|-------------|
| x-twitter | [03-tools/x-twitter.md](../03-tools/x-twitter.md) | X/Twitter data — Syndication API, oEmbed API |
| reddit | [03-tools/reddit.md](../03-tools/reddit.md) | Reddit data — JSON API for posts, comments, search |
| hackernews | [03-tools/hackernews.md](../03-tools/hackernews.md) | Hacker News — Firebase API + RSS feed |
| wikipedia | [03-tools/wikipedia.md](../03-tools/wikipedia.md) | Wikipedia — REST API for article summaries |
| rss | [03-tools/rss.md](../03-tools/rss.md) | RSS/Atom feeds — blog/news content collection |
| github-api | [03-tools/github-api.md](../03-tools/github-api.md) | GitHub public API — repo info, stars, issues (rate limited) |
| imessage | [03-tools/imessage.md](../03-tools/imessage.md) | iMessage 이력 검색 — chat.db SQLite 직접 읽기 (macOS only) |

## Tier 4 — Connectors (user setup required)

Claude Code supports these as add-on integrations. Not included by default —
user connects when needed.

| name | path | what it enables | setup |
|------|------|----------------|-------|
| perplexity | [03-tools/connector-perplexity.md](../03-tools/connector-perplexity.md) | AI-powered web search with deep crawling | MCP server + API key |
| playwright | [03-tools/connector-playwright.md](../03-tools/connector-playwright.md) | Full browser automation, JS-rendered pages | MCP server |
| firecrawl | [03-tools/connector-firecrawl.md](../03-tools/connector-firecrawl.md) | Anti-bot web scraping, structured extraction | MCP server + API key |
| slack | [03-tools/connector-slack.md](../03-tools/connector-slack.md) | Slack 워크스페이스 메시지 검색/읽기 | MCP server + OAuth |
| discord | [03-tools/connector-discord.md](../03-tools/connector-discord.md) | Discord 봇 브릿지, 이력/첨부파일 | MCP server + Bot Token |
| telegram | [03-tools/connector-telegram.md](../03-tools/connector-telegram.md) | Telegram 봇 브릿지, 사진 수신 | MCP server + Bot Token |
| linear | [03-tools/connector-linear.md](../03-tools/connector-linear.md) | Linear 이슈 트래커 연동 | MCP server + API key |
| context7 | [03-tools/connector-context7.md](../03-tools/connector-context7.md) | 라이브러리 공식 문서 버전별 검색 | MCP server |
| gitlab | [03-tools/connector-gitlab.md](../03-tools/connector-gitlab.md) | GitLab MR/CI/이슈/위키 | MCP server + Token |
| github-mcp | [03-tools/connector-github.md](../03-tools/connector-github.md) | GitHub 공식 MCP (gh CLI보다 풍부) | MCP server + Token |
| imessage-mcp | [03-tools/connector-imessage.md](../03-tools/connector-imessage.md) | 구조화된 iMessage 접근 + 전송 | MCP server |
| supabase | [03-tools/connector-supabase.md](../03-tools/connector-supabase.md) | Postgres BaaS — SQL/인증/스토리지 | MCP server + API key |
| semantic-memory | [03-tools/connector-semantic-memory.md](../03-tools/connector-semantic-memory.md) | ChromaDB 시맨틱 검색 — wiki-memory 100+ 페이지 시 보조 | chromadb + OpenAI or Gemini |

## How to use this index

1. Check the tier — higher tiers need more setup
2. Read the linked doc for usage patterns and examples
3. For Tier 2, run `which {tool}` first to confirm availability
4. For Tier 4, follow the setup guide in each connector doc
5. When adding new tools, test first, then add doc + index entry
