# USER

This file describes the person or team using the workspace.

Fill in:
- who this workspace serves
- preferred response style
- common tasks
- what matters most
- what to avoid

Rules:
- keep team-shared facts here if they apply to everyone
- move personal-only details to `CLAUDE.local.md`
