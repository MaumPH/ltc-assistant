# Contracts

declaw treats contract documents as a first-class orchestration layer.

These files separate concerns that would otherwise be collapsed into a single
instruction blob:

- `IDENTITY.md` — what this workspace and agent system is
- `SOUL.md` — values, behavior, and non-negotiables
- `USER.md` — who this workspace serves
- `TOOLS.md` — how tools and external capabilities should be used

These files are loaded through `.claude/CLAUDE.md`, then reinforced by rules,
commands, hooks, and skills.
