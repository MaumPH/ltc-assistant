# Python 3

데이터 처리, JSON/CSV/XML 파싱, 스크립팅. `which python3`으로 확인.

## When to use

- curl 응답 JSON 파싱
- CSV/Excel 데이터 분석
- 텍스트 처리, 정규식
- data-analyst 스킬에서 사용

## Common patterns

```bash
# JSON 파싱 (curl 파이프라인)
curl -sL "{url}" | python3 -c "
import sys, json
data = json.load(sys.stdin)
print(data['key'])
"

# CSV 분석
python3 -c "
import pandas as pd
df = pd.read_csv('{path}')
print(df.describe())
"
```

## Available libraries (check with import)

- pandas — 데이터프레임, CSV/Excel
- matplotlib — 차트/그래프
- json, csv, xml — 표준 라이브러리
- re — 정규식
- subprocess — CLI 도구 호출
