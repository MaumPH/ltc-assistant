# RSS/Atom Feeds

블로그, 뉴스 사이트의 RSS/Atom 피드 수집.

## When to use

- 블로그/뉴스 사이트의 최신 글 일괄 확인
- rss-feeds 스킬에서 피드 스캔
- web-monitor 스킬에서 변경 감지

## Method

```bash
curl -sL "{feed_url}"
```

### Common feed URL patterns

| 플랫폼 | 패턴 |
|--------|------|
| WordPress | `https://{domain}/feed` |
| Tistory | `https://{blog}.tistory.com/rss` |
| Naver Blog | `https://rss.blog.naver.com/{blog_id}.xml` |
| Medium | `https://medium.com/feed/@{user}` |
| Substack | `https://{name}.substack.com/feed` |
| YouTube channel | `https://www.youtube.com/feeds/videos.xml?channel_id={id}` |
| GitHub releases | `https://github.com/{owner}/{repo}/releases.atom` |
| Hacker News | `https://news.ycombinator.com/rss` |

### Parsing with python3

```bash
curl -sL "{feed_url}" | python3 -c "
import sys, xml.etree.ElementTree as ET
root = ET.parse(sys.stdin).getroot()
ns = {'atom': 'http://www.w3.org/2005/Atom'}
# RSS 2.0
for item in root.findall('.//item')[:5]:
    print(item.findtext('title','?'))
    print(f'  {item.findtext(\"link\",\"?\")}')
    print('---')
# Atom
for entry in root.findall('.//atom:entry', ns)[:5]:
    print(entry.findtext('atom:title','?', ns))
    link = entry.find('atom:link', ns)
    if link is not None:
        print(f'  {link.get(\"href\",\"?\")}')
    print('---')
"
```

### Known limitations

| 사이트 | 상태 |
|--------|------|
| Reddit (.rss) | 403 — JSON API 사용 (reddit.md 참조) |
| X/Twitter | RSS 미지원 — Syndication API 사용 (x-twitter.md 참조) |
