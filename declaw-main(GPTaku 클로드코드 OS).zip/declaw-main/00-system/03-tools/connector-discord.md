# Discord (Connector)

Discord 봇 브릿지. 메시지 이력, 첨부파일 다운로드.

## What it enables

- 채널 메시지 읽기/응답
- 리액션 추가
- 메시지 편집
- 첨부파일 다운로드

## Setup

```bash
claude mcp add discord -- npx -y @anthropic/discord-mcp
```

Discord Bot Token 필요.

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/discord
