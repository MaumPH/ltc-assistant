# Bash

Shell 명령 실행. Tier 2 CLI 도구들의 진입점.

## When to use

- CLI 도구 실행 (git, curl, python3 등)
- 시스템 명령 (which, ls, mkdir, env)
- 파이프라인 구성 (curl | python3 -c)
- Tier 3 API 접근의 실행 레이어

## When NOT to use

- 파일 읽기 → Read
- 파일 수정 → Edit
- 파일 검색 → Glob/Grep
- 웹 검색 → WebSearch

## Key parameters

| param | description |
|-------|-------------|
| command | 실행할 쉘 명령 |
| timeout | 최대 실행 시간 (기본 120초, 최대 600초) |
| run_in_background | true면 백그라운드 실행 |

## Tips

- 작업 디렉토리는 호출 간 유지됨
- 여러 명령은 `&&`로 체이닝
- 병렬 실행 가능한 명령은 별도 Bash 호출로 동시 실행
