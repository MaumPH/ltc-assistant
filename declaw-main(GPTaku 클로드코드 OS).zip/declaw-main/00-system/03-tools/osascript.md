# osascript (macOS only)

macOS 앱을 AppleScript로 자동화. macOS 전용.

## When to use

- Apple Notes 읽기/쓰기
- Reminders 조회/추가
- Calendar 이벤트 조회
- apple-notes, apple-reminders, calendar 스킬에서 사용

## vs Computer Use

| 상황 | 추천 |
|------|------|
| 데이터 읽기/쓰기 | osascript (빠르고 정확) |
| GUI에서만 가능한 작업 | Computer Use |
| 앱 상태 확인 | Computer Use (스크린샷) |

## Common patterns

```bash
# Notes — 노트 목록
osascript -e 'tell application "Notes" to get name of every note in folder "Notes"'

# Notes — 노트 내용 읽기
osascript -e 'tell application "Notes" to get body of note "제목"'

# Notes — 새 노트 생성
osascript -e 'tell application "Notes" to make new note at folder "Notes" with properties {name:"제목", body:"내용"}'

# Reminders — 리스트 조회
osascript -e 'tell application "Reminders" to get name of every list'

# Reminders — 항목 추가
osascript -e 'tell application "Reminders" to make new reminder in list "Reminders" with properties {name:"할 일", due date:date "2026-04-08"}'

# Calendar — 캘린더 목록
osascript -e 'tell application "Calendar" to get name of every calendar'

# Calendar — 오늘 이벤트
osascript -e 'tell application "Calendar" to get summary of every event of calendar "직장" whose start date > (current date)'
```
