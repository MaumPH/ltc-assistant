# Image Tools

프로그래밍 방식 이미지/GIF 생성 및 편집. Pillow 기반.

## When to use

- 차트/다이어그램 외의 커스텀 이미지 생성
- 애니메이션 GIF 프레임 단위 제작
- 이미지 리사이즈, 크롭, 워터마크
- 썸네일 생성

## vs ffmpeg

| 작업 | ffmpeg | Pillow |
|------|--------|--------|
| 비디오 변환 | O | X |
| 오디오 추출 | O | X |
| 프로그래밍 이미지 생성 | X | O |
| 프레임 단위 GIF 제작 | 제한적 | O |
| 이미지 텍스트 합성 | X | O |
| 이미지 리사이즈/크롭 | O | O |

## Common patterns

### 이미지 생성

```bash
python3 -c "
from PIL import Image, ImageDraw, ImageFont
img = Image.new('RGB', (800, 400), color='#1a1a2e')
draw = ImageDraw.Draw(img)
draw.text((50, 50), 'Hello World', fill='white')
draw.rectangle([50, 150, 750, 350], outline='#e94560', width=3)
img.save('output.png')
"
```

### 이미지 리사이즈

```bash
python3 -c "
from PIL import Image
img = Image.open('input.png')
img.thumbnail((400, 400))
img.save('thumbnail.png')
"
```

### 애니메이션 GIF

```bash
python3 -c "
from PIL import Image, ImageDraw
frames = []
for i in range(20):
    img = Image.new('RGB', (200, 200), 'white')
    draw = ImageDraw.Draw(img)
    draw.ellipse([i*8, i*8, i*8+40, i*8+40], fill='red')
    frames.append(img)
frames[0].save('animation.gif', save_all=True, append_images=frames[1:],
               duration=100, loop=0)
"
```

## Prerequisites

```bash
pip install Pillow
```
