# X/Twitter

X/Twitter 포스트와 프로필 데이터 접근. API 키 불필요.

## When to use

- 특정 계정의 최근 포스트 확인
- 트윗 전문 및 engagement 수치 (좋아요, RT) 조회
- 개별 트윗 URL에서 내용 추출

## WebFetch/WebSearch 한계

- WebFetch → 402 에러 (x.com 차단)
- WebSearch → 검색 결과 snippet만, 전문 못 가져옴

## Method 1: Syndication API (타임라인)

특정 핸들의 최근 포스트 ~20개를 한 번에 가져온다.

```bash
curl -sL "https://syndication.twitter.com/srv/timeline-profile/screen-name/{handle}" | \
python3 -c "
import sys, json, re, html
content = sys.stdin.read()
match = re.search(r'__NEXT_DATA__.*?>(.*?)</script>', content)
if match:
    data = json.loads(match.group(1))
    for e in data['props']['pageProps']['timeline']['entries']:
        if e['type'] == 'tweet':
            t = e['content']['tweet']
            print(f\"@{t['user']['screen_name']} ({t.get('created_at','?')})\")
            print(f\"  {html.unescape(t.get('full_text',''))[:300]}\")
            print(f\"  Likes: {t.get('favorite_count',0)} | RTs: {t.get('retweet_count',0)}\")
            print('---')
"
```

### Available fields

| field | path | description |
|-------|------|-------------|
| full_text | tweet.full_text | 트윗 전문 |
| screen_name | tweet.user.screen_name | 핸들 |
| name | tweet.user.name | 표시 이름 |
| favorite_count | tweet.favorite_count | 좋아요 수 |
| retweet_count | tweet.retweet_count | RT 수 |
| created_at | tweet.created_at | 작성 시각 |
| id_str | tweet.id_str | 트윗 ID |
| media | tweet.entities.media[] | 미디어 URL |

### Limits

- 최근 ~20개만 반환, 페이지네이션 불가
- 비공개 계정 접근 불가
- 검색 기능 없음 (핸들 기반 타임라인만)

## Method 2: oEmbed API (개별 트윗)

트윗 URL을 알 때 전문을 가져온다.

```bash
curl -sL "https://publish.twitter.com/oembed?url=https://x.com/{user}/status/{tweet_id}"
```

JSON 응답: `author_name`, `author_url`, `html` (트윗 전문 포함)

## Workflow: 검색 → 상세

```
1. WebSearch(query="site:x.com {keyword}") → 트윗 URL 발견
2. curl oEmbed API → 트윗 전문 추출
```

## Connector upgrade

Tier 4 Perplexity MCP 연결 시 더 강력한 X 검색 가능.
xAI API 키가 있으면 openclaw의 x_search 도구와 동등한 기능.
