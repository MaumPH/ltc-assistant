# Git

버전 관리. `which git`으로 확인.

## When to use

- 변경 사항 추적 (diff, log, status)
- 커밋, 브랜치 관리
- github-workflow 스킬에서 사용

## Common patterns

```bash
git status                     # 현재 상태
git diff                       # 변경 사항
git log --oneline -10          # 최근 커밋
git add {files} && git commit  # 커밋
git branch -a                  # 브랜치 목록
```

## Rules

- 사용자 요청 없이 커밋하지 않음
- force push, reset --hard 등 파괴적 명령은 확인 후 실행
- --no-verify 등 훅 스킵 사용 안 함
