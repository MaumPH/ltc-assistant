# Firecrawl (Connector)

안티봇 우회 웹 스크래핑 + 구조화된 데이터 추출.

## What it enables

- Cloudflare, reCAPTCHA 등 봇 방어 우회
- 웹페이지를 마크다운으로 깔끔하게 변환
- 사이트 전체 크롤링 (sitemap 기반)
- 구조화된 데이터 추출 (JSON schema 지정)

## Tier 3 대비 차이

| 기능 | Tier 3 (curl) | Firecrawl |
|------|--------------|-----------|
| 봇 방어 | UA 우회만 | TLS 핑거프린트 등 종합 우회 |
| 출력 형식 | raw HTML | 깔끔한 마크다운 |
| 구조화 | 수동 파싱 | schema 기반 자동 추출 |

## Setup

```bash
claude mcp add firecrawl -- npx -y firecrawl-mcp

# API 키 설정
export FIRECRAWL_API_KEY="fc-..."
```

## Reference

- https://docs.firecrawl.dev/
