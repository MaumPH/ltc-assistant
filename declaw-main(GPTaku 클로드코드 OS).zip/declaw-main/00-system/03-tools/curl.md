# curl

HTTP 요청. Tier 3 API 접근의 핵심 도구.

## When to use

- 공개 API 호출 (X, Reddit, HN, Wikipedia 등)
- WebFetch 차단 사이트 우회
- RSS/Atom 피드 수집
- 웹 페이지 메타태그 추출

## Common patterns

```bash
# 기본 GET
curl -sL "{url}"

# Mobile UA (봇 감지 우회)
curl -sL -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15" "{url}"

# Googlebot UA (OG 메타태그 추출)
curl -sL -H "User-Agent: Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)" "{url}"

# JSON API + 파싱
curl -sL "{url}" | python3 -c "import sys, json; print(json.dumps(json.load(sys.stdin), indent=2))"

# HTTP 상태 코드만 확인
curl -sL -o /dev/null -w "%{http_code}" "{url}"
```

## Tips

- `-s` silent, `-L` follow redirects
- python3과 파이프라인으로 조합하여 사용
- UA 헤더가 필요한 사이트별 패턴은 개별 도구 문서 참조
