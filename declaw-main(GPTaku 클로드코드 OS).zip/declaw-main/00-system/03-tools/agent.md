# Agent (Task)

서브에이전트 위임. 복잡하거나 병렬 가능한 작업을 독립 에이전트에 맡김.

## When to use

- 병렬로 처리할 수 있는 독립 작업 2개 이상
- 코드베이스 탐색 등 컨텍스트를 많이 소모하는 작업
- orchestrator 스킬에서 다중 관점 분석

## Key parameters

| param | description |
|-------|-------------|
| prompt | 완전한 작업 설명 (에이전트는 부모 대화를 모름) |
| description | 3-5단어 요약 |
| subagent_type | 특화 에이전트 유형 (Explore, Plan 등) |
| model | sonnet, opus, haiku |
| run_in_background | 백그라운드 실행 |
| isolation | "worktree"로 격리된 git worktree에서 실행 |

## Tips

- 프롬프트에 파일 경로, 라인 번호, 컨텍스트를 구체적으로 포함
- 독립 작업은 하나의 메시지에서 여러 Agent 호출로 병렬 실행
- 결과는 사용자에게 안 보이므로 요약해서 전달
