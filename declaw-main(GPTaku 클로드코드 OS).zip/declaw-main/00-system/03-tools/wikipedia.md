# Wikipedia

Wikipedia 문서 요약 및 정보 조회. REST API.

## When to use

- 주제에 대한 빠른 배경지식 확보
- 용어 정의 확인
- deep-research 스킬에서 기초 자료 수집

## Method: REST API

```bash
# 영문 요약
curl -sL "https://en.wikipedia.org/api/rest_v1/page/summary/{title}"

# 한국어 요약
curl -sL "https://ko.wikipedia.org/api/rest_v1/page/summary/{title}"
```

### Parsing

```bash
curl -sL "https://en.wikipedia.org/api/rest_v1/page/summary/Claude_(language_model)" | \
python3 -c "
import sys, json
data = json.load(sys.stdin)
print(f\"Title: {data['title']}\")
print(f\"Extract: {data['extract']}\")
print(f\"URL: {data['content_urls']['desktop']['page']}\")
"
```

### Available fields

| field | description |
|-------|-------------|
| title | 문서 제목 |
| extract | 텍스트 요약 (첫 문단) |
| description | 짧은 설명 |
| thumbnail | 대표 이미지 URL |
| content_urls | 전체 문서 URL |
