# Perplexity (Connector)

AI 기반 웹 검색. 대부분의 차단 사이트도 자체 크롤러로 접근 가능.

## What it enables

- WebSearch보다 깊은 AI 합성 검색 결과
- 네이버 블로그 등 봇 차단 사이트도 크롤링 가능
- 도메인 필터링, 날짜 범위 검색
- deep-research, web-monitor 스킬 강화

## Tier 3 대비 차이

| 기능 | Tier 3 (WebSearch) | Perplexity |
|------|-------------------|------------|
| 검색 | 키워드 매칭 | AI 합성 답변 + 인용 |
| 차단 사이트 | 접근 불가 | 자체 크롤러로 접근 |
| 깊이 | snippet 수준 | 전문 추출 + 요약 |

## Setup

```bash
# MCP 서버 추가
claude mcp add perplexity -- npx -y @anthropic/perplexity-mcp

# API 키 설정
export PERPLEXITY_API_KEY="pplx-..."
```

## Reference

- https://docs.perplexity.ai/
