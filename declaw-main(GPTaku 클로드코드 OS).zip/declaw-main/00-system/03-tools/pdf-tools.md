# PDF Tools

PDF 생성, 편집, 분석, OCR. Python 라이브러리 기반.

## When to use

- PDF 생성 (보고서, 인보이스 등)
- 기존 PDF 병합, 분할, 회전, 암호화
- PDF에서 테이블/텍스트 추출
- 스캔 PDF를 텍스트로 변환 (OCR)

## 도구별 역할

| 도구 | 설치 | 역할 |
|------|------|------|
| pypdf | `pip install pypdf` | 병합, 분할, 회전, 암호화/복호화, 메타데이터 |
| pdfplumber | `pip install pdfplumber` | 테이블 추출, 텍스트 위치 기반 추출 |
| reportlab | `pip install reportlab` | PDF를 처음부터 생성 (캔버스, 레이아웃) |
| tesseract | `brew install tesseract` | 스캔 이미지 OCR → 텍스트 |

## vs Read 도구 / pandoc

| 작업 | Read 도구 | pandoc | PDF Tools |
|------|----------|--------|-----------|
| PDF 텍스트 읽기 | O | - | O |
| PDF 테이블 추출 | X | X | O (pdfplumber) |
| PDF 생성 | X | O (md→pdf) | O (자유 레이아웃) |
| PDF 병합/분할 | X | X | O (pypdf) |
| 스캔 PDF OCR | X | X | O (tesseract) |

## Common patterns

### PDF 병합

```bash
python3 -c "
from pypdf import PdfMerger
merger = PdfMerger()
merger.append('file1.pdf')
merger.append('file2.pdf')
merger.write('merged.pdf')
merger.close()
"
```

### PDF 테이블 추출

```bash
python3 -c "
import pdfplumber, pandas as pd
with pdfplumber.open('report.pdf') as pdf:
    for page in pdf.pages:
        tables = page.extract_tables()
        for table in tables:
            df = pd.DataFrame(table[1:], columns=table[0])
            print(df.to_string())
"
```

### PDF 생성

```bash
python3 -c "
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
c = canvas.Canvas('output.pdf', pagesize=A4)
c.drawString(72, 750, 'Hello, PDF!')
c.save()
"
```

### 스캔 PDF OCR

```bash
# tesseract + pdf2image 필요
python3 -c "
from pdf2image import convert_from_path
import pytesseract
images = convert_from_path('scanned.pdf')
for img in images:
    text = pytesseract.image_to_string(img, lang='kor+eng')
    print(text)
"
```

## Prerequisites

```bash
# Python 라이브러리
pip install pypdf pdfplumber reportlab pdf2image pytesseract

# OCR 엔진 (tesseract)
brew install tesseract tesseract-lang

# pdf2image 백엔드
brew install poppler
```
