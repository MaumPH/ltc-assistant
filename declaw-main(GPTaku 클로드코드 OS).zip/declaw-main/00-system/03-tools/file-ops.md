# File Operations

Claude Code 내장 파일 도구. 항상 사용 가능.

## Tools

| tool | what it does |
|------|-------------|
| Read | 파일 읽기 (PDF, 이미지, 노트북 포함) |
| Write | 파일 생성 또는 전체 덮어쓰기 |
| Edit | 기존 파일의 특정 부분만 수정 (old_string → new_string) |
| Glob | 파일 이름 패턴 검색 (`**/*.md`) |
| Grep | 파일 내용 정규식 검색 |

## Usage rules

- 기존 파일 수정 시 Write보다 Edit 선호 (변경분만 전송)
- Edit 전에 반드시 Read로 현재 내용 확인
- Bash의 cat/grep/find 대신 전용 도구 사용
- 파일 경로는 항상 절대 경로
