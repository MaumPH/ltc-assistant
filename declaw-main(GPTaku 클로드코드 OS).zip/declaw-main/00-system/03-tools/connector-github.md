# GitHub MCP (Connector)

공식 GitHub MCP. gh CLI보다 풍부한 API 접근.

## What it enables

- gh CLI의 모든 기능 + 코드 검색, 풍부한 API
- 원격 HTTP 기반 (로컬 CLI 설치 불필요)
- 조직/엔터프라이즈 레벨 접근

## Tier 2 대비 차이

| 기능 | gh CLI | GitHub MCP |
|------|--------|-----------|
| 설치 | 로컬 필요 | 원격 |
| 코드 검색 | 제한적 | 전체 |
| API 범위 | REST | REST + GraphQL |

## Setup

```bash
claude mcp add github -- npx -y @anthropic/github-mcp
```

GitHub Personal Access Token 필요.

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/github
