# Pandoc

문서 형식 변환. `which pandoc`으로 확인.

## When to use

- 마크다운 → PDF, DOCX, HTML 변환
- DOCX → 마크다운 변환
- document-converter 스킬에서 사용
- presentation 스킬에서 사용

## Common patterns

```bash
pandoc input.md -o output.pdf
pandoc input.md -o output.docx
pandoc input.docx -o output.md
pandoc input.md -o output.html --standalone
```
