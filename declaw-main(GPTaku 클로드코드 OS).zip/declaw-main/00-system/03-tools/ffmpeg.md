# FFmpeg

미디어 파일 처리. `which ffmpeg`으로 확인.

## When to use

- 오디오/비디오 형식 변환
- 비디오에서 오디오 추출 (whisper 전처리)
- transcribe 스킬에서 사용

## Common patterns

```bash
# 비디오 → 오디오 추출
ffmpeg -i input.mp4 -vn -acodec pcm_s16le -ar 16000 output.wav

# 오디오 형식 변환
ffmpeg -i input.m4a output.wav

# 오디오 자르기
ffmpeg -i input.wav -ss 00:01:00 -t 00:05:00 output.wav
```
