# Playwright (Connector)

Headless 브라우저 자동화. JS 렌더링이 필요한 SPA 사이트 접근.

## What it enables

- curl로 못 가져오는 SPA 페이지 콘텐츠 추출
- JS 렌더링 후 DOM에서 데이터 추출
- 로그인이 필요한 사이트 자동화 (세션 유지)

## Tier 3 대비 차이

| 기능 | Tier 3 (curl) | Playwright |
|------|--------------|------------|
| SPA | HTML 껍데기만 | 완전한 렌더링 |
| JS 실행 | 불가 | 가능 |
| 로그인 | 불가 | 세션 유지 가능 |

## Setup

```bash
claude mcp add playwright -- npx @playwright/mcp@latest
```

## Reference

- https://playwright.dev/docs/mcp
