# Wiki Memory

LLM이 직접 관리하는 마크다운 위키 기반 메모리 시스템. Karpathy의 LLM Wiki 패턴 적용.
ChromaDB/벡터DB 없이 Read/Write/Grep만으로 동작.

## When to use

- 메모리 저장 시: 주제별 위키 페이지 생성/업데이트
- 메모리 조회 시: 인덱스 스캔 → 관련 페이지 Read
- 세션 종료 시: 인덱스 정합성 확인
- 주간 리뷰 시: 위키 린트 (고아 페이지, 교차참조 점검)

## 핵심 원칙 (Karpathy LLM Wiki)

1. **인덱스 먼저**: MEMORY.md 인덱스를 스캔하고 관련 페이지로 드릴다운
2. **LLM이 관리**: 사람이 아니라 LLM이 위키를 생성/수정/교차참조
3. **모순은 숨기지 않고 표면화**: 새 정보가 기존과 충돌하면 페이지에 명시
4. **좋은 답변은 위키로 승격**: 가치 있는 세션 결과를 위키 페이지로 정리
5. **검색 도구는 나중에**: 인덱스 + Grep으로 충분할 때까지 벡터DB 불필요

## 구조

```
memory/
├── MEMORY.md                          ← 위키 인덱스 (목차)
├── wiki/                              ← 주제별 위키 페이지
│   ├── decisions/                     ← 아키텍처/방향 결정 + 근거
│   ├── preferences/                   ← 사용자 규칙, 스타일, 관례
│   ├── project-context/               ← 프로젝트 구조, 목표, 제약
│   ├── tool-patterns/                 ← 도구 사용법, 설정, 주의점
│   └── pitfalls/                      ← 반복 실수, 안티패턴
└── daily/                             ← 변경 없음: 세션 핸드오프
```

## 가드레일

| 규칙 | 이유 |
|------|------|
| 인덱스 엔트리는 **1줄 이내** | 세션 시작 토큰 절약 |
| 페이지는 Summary + 3줄 이상 | 의미 없는 미니 페이지 방지 |
| 세션당 위키 페이지 읽기 **최대 3개** | 컨텍스트 예산 보호 |
| 인덱스 **100줄 초과 시 린트에서 경고** | 비대화 감지 (상한 아님) |

## MEMORY.md 인덱스 형식

```markdown
# Memory Wiki Index

> Last updated: 2026-04-07 | Pages: 5

## Decisions
| Page | Summary | Updated |
|------|---------|---------|
| [three-lane-memory](wiki/decisions/three-lane-memory.md) | 메모리를 durable/continuity/daily 3레인으로 분리 | 2026-04-04 |

## Preferences
| Page | Summary | Updated |
|------|---------|---------|
| [english-first](wiki/preferences/english-first.md) | 레포 문서는 영어 기본, 개인 노트는 한국어 OK | 2026-04-02 |

## Project Context
| Page | Summary | Updated |
|------|---------|---------|

## Tool Patterns
| Page | Summary | Updated |
|------|---------|---------|

## Pitfalls
| Page | Summary | Updated |
|------|---------|---------|
```

## 위키 페이지 템플릿

파일: `memory/wiki/{category}/{slug}.md`

```markdown
---
title: Three Lane Memory
category: decisions
created: 2026-04-04
updated: 2026-04-04
tags: [memory, architecture]
status: active
---

# Three Lane Memory

## Summary
메모리를 durable/continuity/daily 3개 레인으로 분리한 이유와 방법.

## Detail
(상세 내용)

## Cross-references
- Related: [English First](../preferences/english-first.md)

## Changelog
- 2026-04-04: 초기 생성
```

### status 값

| status | 의미 |
|--------|------|
| active | 현재 유효 |
| draft | 작성 중 |
| archived | 더 이상 유효하지 않음 (삭제 안 함) |
| superseded | 다른 페이지로 대체됨 |

## 3가지 운영 (Operations)

### Ingest (메모리 저장 시)

```
1. MEMORY.md 인덱스 읽기 → 동일 주제 페이지 있는지 확인
2. 있으면 → 기존 페이지 Edit (업데이트)
3. 없으면 → 새 페이지 Write + 인덱스에 행 추가
4. 관련 페이지의 Cross-references 양방향 업데이트
```

### Query (메모리 조회 시)

```
1. MEMORY.md 인덱스 스캔 → 관련 페이지 식별
2. 관련 페이지 1-3개 Read
3. 인덱스에서 못 찾으면 → Grep memory/wiki/ 키워드 검색
4. 가치 있는 답변이 나오면 → 위키 페이지로 승격 (Ingest)
```

### Lint (주간 리뷰 시)

```
1. Glob memory/wiki/**/*.md → 전체 페이지 목록
2. MEMORY.md 인덱스와 대조 → 고아 페이지 발견
3. Grep cross-references → 깨진 링크 발견
4. 60일 이상 미갱신 페이지 → archived 후보 표시
5. 25개 상한 초과 시 → 병합/아카이브 제안
```

## 스킬 연동

| 시점 | 스킬 | 위키 동작 |
|------|------|----------|
| "기억해줘" | memory-capture | Ingest: 주제 분류 → 페이지 생성/업데이트 → 인덱스 갱신 |
| 세션 종료 | session-closeout | Ingest + 인덱스 정합성 확인 |
| 데일리 동기화 | daily-sync | 전일 핸드오프에서 위키 후보 추출 |
| PreCompact | settings.json hook | 긴급 저장: MEMORY.md 인덱스 끝에 `## Unsorted` 섹션에 1줄 메모 추가 (다음 세션에서 정리) |
| 주간 리뷰 | weekly-review | Lint 실행 |

### PreCompact 대응 (10 tool call 제한)

PreCompact 시에는 위키 페이지를 만들지 않는다. 대신:

```
1. 저장할 내용을 1줄 요약
2. MEMORY.md 끝의 ## Unsorted 섹션에 추가 (1 Edit call)
3. 다음 세션에서 memory-capture가 Unsorted → 정식 위키 페이지로 정리
```

## 스케일 단계

| 페이지 수 | 전략 | 도구 |
|-----------|------|------|
| ~30 이하 | 인덱스 전체 스캔 | Read MEMORY.md |
| ~30-100 | 카테고리별 스캔 | Read + 카테고리 필터 |
| ~100 이상 | 인덱스 + Grep 병행 | Read + Grep memory/wiki/ |
| 인덱스 100줄 초과 | 린트에서 경고, 병합/아카이브 검토 | Lint 운영 |

## 마이그레이션

현재 MEMORY.md가 비어있으므로 마이그레이션 불필요.

```bash
# 1. 위키 디렉토리 생성
mkdir -p memory/wiki/{decisions,preferences,project-context,tool-patterns,pitfalls}

# 2. MEMORY.md를 인덱스 형식으로 교체
# (기존 내용이 있으면 각 항목을 위키 페이지로 분리)

# 3. .gitignore에 추가하지 않음 (git으로 버전 관리)
```

## vs ChromaDB (connector-semantic-memory.md)

| 항목 | Wiki Memory | ChromaDB |
|------|-------------|----------|
| 설치 | 불필요 | pip install + API 키 |
| 검색 | 인덱스 + Grep (키워드) | 벡터 유사도 (의미) |
| 교차참조 | 명시적 링크 (정확) | 암시적 유사도 (근사) |
| 모순 감지 | 페이지에 명시 (확실) | 불가 |
| 관리 주체 | LLM이 직접 | 파이프라인 필요 |
| 적정 규모 | ~100 페이지까지 | 100+ 페이지 |
| 비용 | 무료 | 임베딩 API 비용 |

**결론**: 일반적인 워크스페이스에서는 Wiki Memory로 충분. ChromaDB는 100+ 페이지 시 선택적 추가.
