# GitHub CLI (gh)

GitHub 작업 자동화. `which gh`로 확인.

## When to use

- PR 생성/조회/리뷰
- 이슈 관리
- GitHub Actions 모니터링
- 릴리스 관리
- github-workflow 스킬에서 사용

## Common patterns

```bash
gh pr list                         # PR 목록
gh pr create --title "..." --body "..."  # PR 생성
gh pr view 123                     # PR 상세
gh issue list                      # 이슈 목록
gh run list                        # Actions 실행 목록
gh api repos/{owner}/{repo}        # API 호출
```

## Tips

- `gh api`로 GitHub REST API 직접 호출 가능
- WebFetch보다 gh CLI로 GitHub 콘텐츠 접근 선호
