# Whisper

음성 → 텍스트 변환 (STT). `which whisper`로 확인.

## When to use

- 녹음 파일, 회의 녹음, 팟캐스트 텍스트 변환
- transcribe 스킬에서 사용
- meeting-notes 스킬의 전처리

## Common patterns

```bash
# 기본 변환
whisper input.wav --language ko --model medium

# 영문 변환
whisper input.wav --language en --model medium

# SRT 자막 생성
whisper input.wav --language ko --model medium --output_format srt
```

## Prerequisites

- ffmpeg 필요 (오디오 디코딩)
- 큰 파일은 ffmpeg로 분할 후 처리 권장
