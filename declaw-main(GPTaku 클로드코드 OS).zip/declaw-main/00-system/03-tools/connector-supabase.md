# Supabase (Connector)

Postgres 기반 BaaS. SQL, 인증, 스토리지, 실시간.

## What it enables

- SQL 쿼리 직접 실행
- 사용자 인증 관리
- 파일 스토리지
- 실시간 구독

## Setup

```bash
claude mcp add supabase -- npx -y @anthropic/supabase-mcp
```

Supabase 프로젝트 URL + API 키 필요.

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/supabase
