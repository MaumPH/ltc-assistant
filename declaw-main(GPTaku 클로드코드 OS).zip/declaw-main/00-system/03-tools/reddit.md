# Reddit

Reddit 포스트, 댓글, 검색 데이터 접근. API 키 불필요.

## When to use

- 서브레딧의 핫/신규 포스트 목록 조회
- 개별 포스트 본문 + 댓글 트리 전체 가져오기
- 서브레딧 내 키워드 검색

## WebFetch 한계

- WebFetch → www.reddit.com, old.reddit.com 모두 차단
- RSS (.rss) → 403

## Method: JSON API (.json suffix)

URL 끝에 `.json`을 붙이면 구조화된 JSON 응답을 반환한다.
**필수: Mobile User-Agent 헤더** (없으면 403)

### Endpoints

```bash
UA="-H 'User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15'"

# 서브레딧 포스트 목록
curl -sL $UA "https://www.reddit.com/r/{subreddit}/hot.json?limit=10"

# 개별 포스트 + 댓글
curl -sL $UA "https://www.reddit.com/r/{subreddit}/comments/{post_id}/{slug}/.json"

# 서브레딧 내 검색
curl -sL $UA "https://www.reddit.com/r/{subreddit}/search.json?q={query}&restrict_sr=1"

# 유저 프로필
curl -sL $UA "https://www.reddit.com/user/{username}/.json"
```

### Post list parsing

```bash
curl -sL \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15" \
  "https://www.reddit.com/r/{subreddit}/hot.json?limit=10" | \
python3 -c "
import sys, json
data = json.load(sys.stdin)
for post in data['data']['children']:
    d = post['data']
    print(f\"[{d.get('score',0)}] {d['title']}\")
    print(f\"  by u/{d['author']} | {d.get('num_comments',0)} comments\")
    body = d.get('selftext','')
    if body:
        print(f\"  {body[:200]}\")
    print('---')
"
```

### Post + comments parsing

```bash
curl -sL \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15" \
  "https://www.reddit.com/r/{subreddit}/comments/{post_id}/{slug}/.json" | \
python3 -c "
import sys, json
data = json.load(sys.stdin)
post = data[0]['data']['children'][0]['data']
print(f\"Title: {post['title']}\")
print(f\"Author: u/{post['author']} | Score: {post['score']}\")
print(f\"Body: {post.get('selftext','')[:500]}\")
print('===')
for c in data[1]['data']['children'][:10]:
    d = c.get('data', {})
    if 'body' in d:
        print(f\"u/{d['author']} (score: {d.get('score',0)})\")
        print(f\"  {d['body'][:200]}\")
        print('---')
"
```

### Available fields — post

| field | path | description |
|-------|------|-------------|
| title | data.title | 포스트 제목 |
| author | data.author | 작성자 |
| score | data.score | 업보트 점수 |
| selftext | data.selftext | 본문 (마크다운) |
| num_comments | data.num_comments | 댓글 수 |
| url | data.url | 링크 URL |
| created_utc | data.created_utc | 작성 시각 (unix) |
| link_flair_text | data.link_flair_text | flair 태그 |

### Available fields — comment

| field | path | description |
|-------|------|-------------|
| body | data.body | 댓글 본문 (마크다운) |
| author | data.author | 작성자 |
| score | data.score | 점수 |
| replies | data.replies | 대댓글 트리 (재귀) |

### Sorting options

`hot.json`, `new.json`, `top.json?t=week`, `rising.json`
