# WebSearch

인터넷 검색. Claude Code 내장.

## When to use

- 최신 정보 검색 (학습 데이터 이후)
- 특정 사이트 내 검색 (`site:x.com`)
- 주제에 대한 여러 소스 탐색

## Usage

```
WebSearch(query="Claude Code 2026 latest features")
WebSearch(query="site:x.com openclaw", allowed_domains=["x.com"])
```

## Parameters

| param | description |
|-------|-------------|
| query | 검색 쿼리 |
| allowed_domains | 특정 도메인만 포함 |
| blocked_domains | 특정 도메인 제외 |

## Tips

- 날짜 포함 시 더 최신 결과: `"{topic} 2026"`
- `site:` 필터로 특정 사이트 검색: `site:reddit.com {keyword}`
- 검색 결과의 URL을 WebFetch나 curl로 상세 조회
