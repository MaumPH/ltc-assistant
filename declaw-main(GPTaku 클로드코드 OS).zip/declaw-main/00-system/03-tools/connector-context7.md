# Context7 (Connector)

라이브러리/프레임워크 공식 문서 검색. 버전별 정확한 API 문서 제공.

## What it enables

- npm/PyPI 등 패키지의 공식 문서를 버전별로 검색
- API 사용법, 파라미터, 예제 조회
- WebSearch보다 정확한 라이브러리 레퍼런스

## Tier 1 대비 차이

| 기능 | WebSearch | Context7 |
|------|-----------|---------|
| 검색 범위 | 웹 전체 | 공식 소스 코드/문서만 |
| 버전 특정 | 불가 | O (v18, v3 등 지정 가능) |
| 정확도 | 블로그/포럼 포함 | 공식 API만 |

## Setup

```bash
claude mcp add context7 -- npx -y @anthropic/context7-mcp
```

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/context7
