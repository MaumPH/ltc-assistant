# Hacker News

Hacker News 포스트 접근. Firebase API + RSS.

## When to use

- 테크 뉴스/트렌드 모니터링
- 특정 주제에 대한 HN 토론 확인
- morning-briefing, deep-research 스킬에서 참조

## Method 1: RSS feed

```bash
curl -sL "https://news.ycombinator.com/rss"
```

최근 30개 포스트 제목 + 링크 + 댓글 URL 반환.

## Method 2: Firebase API

```bash
# Top stories (ID 배열)
curl -sL "https://hacker-news.firebaseio.com/v0/topstories.json"

# 개별 아이템
curl -sL "https://hacker-news.firebaseio.com/v0/item/{id}.json"
```

### Quick top 5 script

```bash
curl -sL "https://hacker-news.firebaseio.com/v0/topstories.json" | \
python3 -c "
import sys, json, subprocess
ids = json.load(sys.stdin)[:5]
for i in ids:
    r = subprocess.run(['curl','-sL',f'https://hacker-news.firebaseio.com/v0/item/{i}.json'],
                       capture_output=True, text=True)
    item = json.loads(r.stdout)
    print(f\"[{item.get('score',0)}] {item.get('title','?')}\")
    print(f\"  {item.get('url','(no url)')}\")
    print('---')
"
```

### Endpoints

| endpoint | returns |
|----------|---------|
| /v0/topstories.json | Top 500 story IDs |
| /v0/newstories.json | New 500 story IDs |
| /v0/beststories.json | Best 500 story IDs |
| /v0/askstories.json | Ask HN story IDs |
| /v0/showstories.json | Show HN story IDs |
| /v0/item/{id}.json | Single item (story, comment, job) |
| /v0/user/{id}.json | User profile |
