# GitHub Public API

GitHub 공개 데이터 조회. 인증 없이 사용 가능 (rate limit 있음).

## When to use

- 리포 정보 빠른 조회 (stars, description)
- gh CLI가 없을 때 대안
- 공개 리포 메타데이터 수집

## Method

```bash
# 리포 정보
curl -sL "https://api.github.com/repos/{owner}/{repo}" | \
python3 -c "
import sys, json
data = json.load(sys.stdin)
print(f\"{data['full_name']} - stars: {data['stargazers_count']}\")
print(f\"Description: {data['description']}\")
"
```

## Rate limit

- 비인증: 60 requests/hour
- gh CLI 인증 시: 5000 requests/hour
- gh CLI가 있으면 `gh api` 사용 권장
