# WebFetch

URL에서 콘텐츠를 추출하는 내장 도구. 일부 사이트에서 차단되므로 fallback 전략을 함께 사용.

## When to use

- 특정 URL의 내용을 읽어야 할 때
- 문서, 블로그, 공식 사이트 내용 추출

## Basic usage

```
WebFetch(url="https://example.com/article", prompt="핵심 내용을 요약해줘")
```

- HTML → 마크다운 변환 후 소형 모델이 프롬프트에 따라 처리
- 15분 캐시 내장
- 리다이렉트 시 새 URL 반환 (재요청 필요)

## Known blocked sites

| 사이트 | 상태 | 대안 |
|--------|------|------|
| x.com | 402 | → x-twitter.md (Syndication/oEmbed) |
| reddit.com | 차단 | → reddit.md (JSON API) |
| old.reddit.com | 차단 | → reddit.md (JSON API) |
| blog.naver.com | 차단 | → curl + Mobile UA |

## Fallback: curl with Mobile UA

WebFetch 실패 시 Bash로 curl 실행.

```bash
# 모바일 UA로 봇 감지 우회
curl -sL \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15" \
  "{URL}"
```

## Fallback: OG metatag extraction

본문 전체는 못 가져와도 제목과 요약은 확보 가능.

```bash
curl -sL \
  -H "User-Agent: Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)" \
  "{URL}" | grep -iE 'og:description|og:title|meta name="description'
```

## Fallback: Wayback Machine

캐시된 버전 시도 (SPA 사이트는 실패할 수 있음).

```bash
curl -sL "https://web.archive.org/web/{URL}"
```

## Fallback priority

1. WebFetch (기본 시도)
2. curl + Mobile UA
3. OG metatag extraction (최소 요약)
4. Wayback Machine (캐시)
5. WebSearch로 대체 소스 검색
