# Telegram (Connector)

Telegram 봇 브릿지. 메시지/사진 수신 및 응답.

## What it enables

- 봇을 통한 메시지 수신/응답
- 사진 수신 및 처리
- 리액션, 메시지 편집

## Setup

```bash
claude mcp add telegram -- npx -y @anthropic/telegram-mcp
```

Telegram Bot Token 필요 (@BotFather에서 발급).

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/telegram
