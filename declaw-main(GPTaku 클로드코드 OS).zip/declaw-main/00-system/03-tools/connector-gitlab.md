# GitLab (Connector)

GitLab DevOps 연동. MR, CI/CD, 이슈, 위키.

## What it enables

- Merge Request 생성/조회/리뷰
- CI/CD 파이프라인 모니터링
- 이슈 관리
- 위키 편집

## Tier 2 대비 차이

gh CLI는 GitHub 전용. GitLab 사용 팀은 이 커넥터가 필요.

## Setup

```bash
claude mcp add gitlab -- npx -y @anthropic/gitlab-mcp
```

GitLab Personal Access Token 필요.

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/gitlab
