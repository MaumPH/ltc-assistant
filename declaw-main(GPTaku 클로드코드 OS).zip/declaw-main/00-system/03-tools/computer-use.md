# Computer Use

Claude Code 내장 데스크톱 제어. macOS 앱을 스크린샷/클릭/타이핑으로 직접 조작.

## When to use

- CLI가 없는 앱 조작 (지도, 사진, 시스템 설정 등)
- 앱의 현재 상태를 스크린샷으로 확인
- GUI에서만 가능한 작업 (드래그, 메뉴 선택 등)
- 브라우저 화면 읽기 (read tier — 클릭은 불가)

## When NOT to use

- CLI로 가능한 작업 → Bash 사용
- osascript로 가능한 작업 → osascript 사용 (더 빠르고 정확)
- 파일 작업 → Read/Write/Edit 사용
- 웹 검색 → WebSearch 사용

## Setup

Computer Use는 Claude Code 내장 MCP로 별도 설치 불필요.
`/plugin` 명령으로 활성화/재연결 가능.

## Usage flow

### 1. 접근 권한 요청 (필수)

```
mcp__computer-use__request_access({
  apps: ["com.apple.Notes", "com.apple.reminders"],
  reason: "노트 확인을 위해 접근이 필요합니다"
})
```

- 번들 ID 사용 권장 (앱 이름이 한국어일 때 인식 실패 방지)
- 사용자 승인 필요 — 자동 승인 아님

### 2. 앱 열기

```
mcp__computer-use__open_application({ app: "com.apple.Notes" })
```

### 3. 스크린샷

```
mcp__computer-use__screenshot()
```

### 4. 조작

```
mcp__computer-use__left_click({ coordinate: [x, y] })
mcp__computer-use__type({ text: "입력할 텍스트" })
mcp__computer-use__key({ text: "cmd+a" })
mcp__computer-use__scroll({ coordinate: [x, y], scroll_direction: "down", scroll_amount: 3 })
```

### 5. 배치 실행 (라운드트립 절약)

```
mcp__computer-use__computer_batch({
  actions: [
    { action: "left_click", coordinate: [100, 200] },
    { action: "type", text: "hello" },
    { action: "key", text: "Return" },
    { action: "screenshot" }
  ]
})
```

## Tier restrictions

| 앱 카테고리 | 허용 수준 | 제한 |
|------------|----------|------|
| 일반 앱 (Notes, Finder 등) | full | 제한 없음 |
| 브라우저 (Safari, Chrome 등) | read | 스크린샷만 가능, 클릭/타이핑 불가 |
| 터미널/IDE (Terminal, VS Code 등) | click | 클릭 가능, 타이핑 불가 |

## Common bundle IDs (macOS Korean)

| 앱 | 번들 ID |
|----|---------|
| 메모 | com.apple.Notes |
| 미리 알림 | com.apple.reminders |
| 캘린더 | com.apple.iCal |
| 시스템 설정 | com.apple.systempreferences |
| Finder | com.apple.finder |
| 사진 | com.apple.Photos |
| 지도 | com.apple.Maps |
| 미리보기 | com.apple.Preview |
