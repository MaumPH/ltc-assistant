# Linear (Connector)

Linear 이슈 트래커 연동. 이슈 생성/조회/상태 관리.

## What it enables

- 이슈 생성, 업데이트, 검색
- 프로젝트/팀별 이슈 필터링
- 상태 전환 자동화

## Tier 3 대비 차이

GitHub Issues와 별개의 이슈 트래커. 소프트웨어 팀 프로젝트 관리에 특화.

## Setup

```bash
claude mcp add linear -- npx -y @anthropic/linear-mcp
```

Linear API 키 필요.

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/linear
