# Slack (Connector)

Slack 워크스페이스 메시지 검색/읽기. 공식 OAuth MCP.

## What it enables

- 채널/DM 메시지 검색
- 스레드 읽기
- 채널 목록 조회

## Setup

```bash
claude mcp add slack -- npx -y @anthropic/slack-mcp
```

OAuth 인증 필요 — 설정 시 Slack 워크스페이스 연동.

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/slack
