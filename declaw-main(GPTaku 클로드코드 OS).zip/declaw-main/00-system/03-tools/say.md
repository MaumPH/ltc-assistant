# say (macOS TTS)

macOS 내장 텍스트 음성 변환. API 키 불필요. macOS 전용.

## When to use

- 알림이나 결과를 음성으로 전달
- 장문의 텍스트를 오디오 파일로 저장
- morning-briefing 등 스킬에서 음성 출력

## Basic usage

```bash
# 바로 읽어주기
say "작업이 완료되었습니다"

# 영어 음성
say -v Alex "Task completed successfully"

# 한국어 음성
say -v Yuna "안녕하세요"

# 파일로 저장
say -v Alex -o output.aiff "Hello world"

# 읽기 속도 조절 (단어/분)
say -r 150 "느리게 읽기"
```

## Available voices

```bash
# 설치된 음성 목록
say -v ?

# 주요 음성
# Alex (영어), Yuna (한국어), Kyoko (일본어)
```

## Tips

- 오디오 파일 변환은 ffmpeg과 조합: `say -o out.aiff "text" && ffmpeg -i out.aiff out.mp3`
- 긴 텍스트는 파일에서 읽기: `say -f input.txt`
