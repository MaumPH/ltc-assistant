# Office Documents

Word, Excel, PowerPoint 파일 생성/편집/읽기.

## When to use

- .docx, .xlsx, .pptx 파일 생성 (서식 보존)
- Office 파일에서 구조화된 데이터 추출
- Office → 마크다운/PDF 변환
- presentation, document-converter, data-analyst 스킬에서 사용

## 도구별 역할

| 도구 | 설치 | 파일 타입 | 역할 |
|------|------|----------|------|
| openpyxl | `pip install openpyxl` | .xlsx | Excel 읽기/쓰기 (서식, 수식, 차트) |
| docx (npm) | `npm install docx` | .docx | Word 생성 (목차, 표, 머리글) |
| pptxgenjs | `npm install pptxgenjs` | .pptx | PowerPoint 생성 (레이아웃, 도형, 이미지) |
| markitdown | `pip install markitdown` | 다수 | Office → 마크다운 추출 |
| soffice | LibreOffice 설치 | 다수 | 형식 변환, 수식 계산, PDF 렌더링 |

## vs pandoc

| 작업 | pandoc | Office Tools |
|------|--------|-------------|
| md → docx | O (기본 서식) | O (풍부한 서식) |
| md → pptx | O (매우 기본) | O (레이아웃 제어) |
| xlsx 읽기/쓰기 | X | O (openpyxl) |
| 수식 보존 | X | O (openpyxl, soffice) |
| pptx → md | X | O (markitdown) |

## Common patterns

### Excel 생성 (서식 포함)

```bash
python3 -c "
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
wb = Workbook()
ws = wb.active
ws['A1'] = '항목'
ws['B1'] = '금액'
ws['A1'].font = Font(bold=True)
ws['A1'].fill = PatternFill(start_color='4472C4', fill_type='solid')
ws['A2'] = '매출'
ws['B2'] = 1000000
ws['B2'].number_format = '#,##0'
wb.save('report.xlsx')
"
```

### Office → 마크다운 추출

```bash
# pptx, docx, xlsx 모두 지원
python3 -m markitdown presentation.pptx
python3 -m markitdown document.docx
```

### PowerPoint 생성

```bash
node -e "
const pptxgen = require('pptxgenjs');
const pres = new pptxgen();
const slide = pres.addSlide();
slide.addText('Hello World', { x: 1, y: 1, fontSize: 24 });
pres.writeFile({ fileName: 'output.pptx' });
"
```

### LibreOffice 변환

```bash
# docx → PDF
soffice --headless --convert-to pdf document.docx

# xlsx 수식 재계산 후 PDF
soffice --headless --calc --convert-to pdf spreadsheet.xlsx

# pptx → PDF
soffice --headless --convert-to pdf presentation.pptx
```

## Prerequisites

```bash
# Python
pip install openpyxl markitdown

# Node
npm install docx pptxgenjs

# LibreOffice (headless 변환용)
brew install --cask libreoffice
```
