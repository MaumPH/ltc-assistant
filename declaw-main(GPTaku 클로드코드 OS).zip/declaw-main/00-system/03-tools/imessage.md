# iMessage (macOS)

macOS iMessage 이력 읽기. chat.db 직접 접근. macOS 전용.

## When to use

- 특정 연락처와의 메시지 이력 검색
- 최근 메시지 확인
- 메시지 통계/분석

## Method: chat.db (SQLite)

macOS는 iMessage 데이터를 SQLite DB에 저장한다.

```bash
# 최근 메시지 10개
sqlite3 ~/Library/Messages/chat.db "
SELECT
  datetime(m.date/1000000000 + 978307200, 'unixepoch', 'localtime') as time,
  CASE WHEN m.is_from_me = 1 THEN 'Me' ELSE h.id END as sender,
  m.text
FROM message m
LEFT JOIN handle h ON m.handle_id = h.ROWID
WHERE m.text IS NOT NULL
ORDER BY m.date DESC
LIMIT 10;
"
```

### 특정 연락처 검색

```bash
sqlite3 ~/Library/Messages/chat.db "
SELECT
  datetime(m.date/1000000000 + 978307200, 'unixepoch', 'localtime') as time,
  m.text
FROM message m
LEFT JOIN handle h ON m.handle_id = h.ROWID
WHERE h.id LIKE '%010-1234-5678%'
  AND m.text IS NOT NULL
ORDER BY m.date DESC
LIMIT 20;
"
```

### 키워드 검색

```bash
sqlite3 ~/Library/Messages/chat.db "
SELECT
  datetime(m.date/1000000000 + 978307200, 'unixepoch', 'localtime') as time,
  h.id as sender,
  m.text
FROM message m
LEFT JOIN handle h ON m.handle_id = h.ROWID
WHERE m.text LIKE '%키워드%'
ORDER BY m.date DESC
LIMIT 10;
"
```

## Permissions

- "전체 디스크 접근 권한" 필요 (시스템 설정 > 개인 정보 보호)
- 터미널/Claude Code에 해당 권한이 없으면 접근 불가

## vs osascript

| 작업 | osascript | chat.db |
|------|-----------|---------|
| 메시지 보내기 | O | X (읽기 전용) |
| 이력 검색 | X | O |
| 키워드 검색 | X | O |
| 통계/분석 | X | O |

## Connector upgrade

Tier 4 iMessage MCP 연결 시 더 구조화된 접근 + 메시지 전송 가능.
