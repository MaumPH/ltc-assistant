# Semantic Memory (Connector)

ChromaDB 기반 시맨틱 메모리 검색. 키워드가 아닌 의미 기반으로 과거 메모리를 찾는다.

**선택적 기능** — 기본 Grep 키워드 검색으로도 충분. 메모리가 많아져서 키워드로 못 찾을 때 도입.

## What it enables

- "지난번 그 프로젝트 구조 관련 결정" 같은 모호한 검색
- 유사한 맥락의 메모리를 의미 기반으로 연결
- 메모리 간 관련성 자동 발견

## vs 기본 검색

| 기능 | Grep (기본) | Semantic Memory |
|------|------------|----------------|
| "ChromaDB 설정" 검색 | O (정확 매칭) | O |
| "DB 관련 결정" 검색 | X (키워드 불일치) | O (의미 매칭) |
| 설치 | 불필요 | Python + API 키 |
| 속도 | 빠름 | 느림 (임베딩 호출) |

## Architecture

```
메모리 저장 → 임베딩 생성 → ChromaDB 저장
                                ↓
검색 쿼리 → 임베딩 생성 → ChromaDB 유사도 검색 → 결과 반환
```

## Setup

### 1. ChromaDB 설치

```bash
pip install chromadb
```

### 2. 임베딩 모델 선택 (둘 중 하나)

**Option A: OpenAI** (추천 — 빠르고 정확)

```bash
pip install openai
export OPENAI_API_KEY="sk-..."
```

**Option B: Gemini** (Google AI Studio 무료 tier 가능)

```bash
pip install google-generativeai
export GEMINI_API_KEY="..."
```

### 3. 초기화 스크립트

아래 스크립트를 최초 1회 실행하면 DB가 생성된다.

```bash
python3 -c "
import chromadb

client = chromadb.PersistentClient(path='.chromadb')
collection = client.get_or_create_collection(
    name='memory',
    metadata={'hnsw:space': 'cosine'}
)
print(f'Collection ready: {collection.count()} documents')
"
```

## Usage

### 메모리 인덱싱 (저장 시 호출)

```bash
python3 -c "
import chromadb, os, hashlib

# --- config ---
EMBEDDING_PROVIDER = 'openai'  # or 'gemini'
DB_PATH = '.chromadb'
# --- end config ---

def get_embedding_fn():
    if EMBEDDING_PROVIDER == 'openai':
        from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
        return OpenAIEmbeddingFunction(
            api_key=os.environ['OPENAI_API_KEY'],
            model_name='text-embedding-3-small'
        )
    elif EMBEDDING_PROVIDER == 'gemini':
        from chromadb.utils.embedding_functions import GoogleGenerativeAiEmbeddingFunction
        return GoogleGenerativeAiEmbeddingFunction(
            api_key=os.environ['GEMINI_API_KEY'],
            model_name='models/text-embedding-004'
        )

client = chromadb.PersistentClient(path=DB_PATH)
collection = client.get_or_create_collection(
    name='memory',
    embedding_function=get_embedding_fn()
)

# 인덱싱할 파일
import sys
file_path = sys.argv[1] if len(sys.argv) > 1 else 'memory/MEMORY.md'

with open(file_path, 'r') as f:
    content = f.read()

# 청크 분할 (섹션 단위)
chunks = [c.strip() for c in content.split('\n## ') if c.strip()]
for i, chunk in enumerate(chunks):
    doc_id = hashlib.md5(f'{file_path}:{i}'.encode()).hexdigest()
    collection.upsert(
        ids=[doc_id],
        documents=[chunk],
        metadatas=[{'source': file_path, 'chunk': i}]
    )

print(f'Indexed {len(chunks)} chunks from {file_path}')
print(f'Total documents: {collection.count()}')
" "\$1"
```

### 시맨틱 검색

```bash
python3 -c "
import chromadb, os

EMBEDDING_PROVIDER = 'openai'  # or 'gemini'
DB_PATH = '.chromadb'

def get_embedding_fn():
    if EMBEDDING_PROVIDER == 'openai':
        from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
        return OpenAIEmbeddingFunction(
            api_key=os.environ['OPENAI_API_KEY'],
            model_name='text-embedding-3-small'
        )
    elif EMBEDDING_PROVIDER == 'gemini':
        from chromadb.utils.embedding_functions import GoogleGenerativeAiEmbeddingFunction
        return GoogleGenerativeAiEmbeddingFunction(
            api_key=os.environ['GEMINI_API_KEY'],
            model_name='models/text-embedding-004'
        )

client = chromadb.PersistentClient(path=DB_PATH)
collection = client.get_or_create_collection(
    name='memory',
    embedding_function=get_embedding_fn()
)

import sys
query = sys.argv[1] if len(sys.argv) > 1 else 'project decision'
results = collection.query(query_texts=[query], n_results=5)

for i, (doc, meta, dist) in enumerate(zip(
    results['documents'][0],
    results['metadatas'][0],
    results['distances'][0]
)):
    score = 1 - dist  # cosine similarity
    print(f'[{score:.3f}] {meta[\"source\"]}#{meta[\"chunk\"]}')
    print(f'  {doc[:200]}')
    print('---')
" "\$1"
```

## Integration points

스킬/커맨드에서 자동 호출하도록 연결할 수 있는 지점:

| 시점 | 스킬/커맨드 | 동작 |
|------|-----------|------|
| 메모리 저장 | memory-capture | 저장 후 인덱싱 호출 |
| 세션 종료 | session-closeout | 변경된 메모리 파일 일괄 재인덱싱 |
| 데일리 동기화 | daily-sync | 당일 메모리 인덱싱 |
| 메모리 검색 | 수동 또는 스킬 내부 | 시맨틱 검색 → 관련 메모리 로드 |

## Embedding model comparison

| 항목 | OpenAI | Gemini |
|------|--------|--------|
| 모델 | text-embedding-3-small | text-embedding-004 |
| 비용 | $0.02/1M tokens | 무료 tier 있음 |
| 차원 | 1536 | 768 |
| 속도 | 빠름 | 보통 |
| 정확도 | 높음 | 높음 |
| API 키 | OPENAI_API_KEY | GEMINI_API_KEY |

## .gitignore

```
.chromadb/
```

## Notes

- ChromaDB는 로컬 파일 기반 — 서버 불필요
- `.chromadb/` 폴더에 모든 데이터 저장
- 메모리 파일이 100개 이상일 때 효과가 두드러짐
- 그 전까지는 기본 Grep 검색으로 충분
