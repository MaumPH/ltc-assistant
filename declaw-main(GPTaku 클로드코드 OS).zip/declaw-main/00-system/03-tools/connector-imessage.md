# iMessage MCP (Connector)

구조화된 iMessage 접근. chat.db 직접 읽기 + AppleScript 전송.

## What it enables

- 전체 메시지 이력 구조화 검색
- 메시지 전송 (AppleScript 경유)
- 대화 스레드 추적

## Tier 3 대비 차이

| 기능 | chat.db (Tier 3) | osascript (Tier 2) | iMessage MCP |
|------|------------------|--------------------|-------------|
| 이력 검색 | O | X | O |
| 메시지 전송 | X | O | O |
| 구조화 API | X | X | O |

## Setup

```bash
claude mcp add imessage -- npx -y @anthropic/imessage-mcp
```

macOS "전체 디스크 접근 권한" 필요.

## Reference

- https://github.com/anthropics/claude-plugins-official/tree/main/external_plugins/imessage
