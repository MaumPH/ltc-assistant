# Daily Notes

This directory is for human-facing daily notes.

Recommended naming:
- `YYYY-MM-DD.md`

Use this lane for:
- daily logs
- working notes
- drafts
- reflections
