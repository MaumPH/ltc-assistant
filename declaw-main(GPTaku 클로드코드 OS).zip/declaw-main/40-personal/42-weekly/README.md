# Weekly Reviews

This directory stores weekly review documents.

Recommended naming:
- `YYYY-Www.md`

Recommended flow:
- run `/weekly-review`
- promote stable lessons into `memory/MEMORY.md`
