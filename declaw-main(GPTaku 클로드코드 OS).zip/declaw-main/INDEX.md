# Workspace Index

## Sections

- `00-inbox/` — raw incoming capture
- `00-system/` — templates, contracts, docs, operating patterns
- `10-backlog/` — ideas and pending work
- `20-testing/` — validation logs and gate records
- `30-docs/` — product and usage documentation
- `40-personal/` — daily, weekly, and todo lanes
- `50-resources/` — supporting references and assets
- `90-archive/` — completed or retired material
- `memory/` — durable and continuity memory

## Operator Surface

- `.claude/commands/README.md`
- `.claude/agents/README.md`
- `.claude/skills/`
- `00-system/02-contracts/`

## Core Commands

- `/onboarding`
- `/setup-workspace`
- `/daily-note`
- `/daily-review`
- `/weekly-review`
- `/todo`
- `/todos`
- `/idea`
- `/thinking-partner`
- `/inbox-processor`
- `/create-command`
- `/sync`

## Core Skills

- `onboarding`
- `workspace-bootstrap`
- `memory-capture`
- `daily-sync`
- `session-closeout`
- `skill-builder`
- `bridge-placeholder`

## Memory Lanes

- `memory/MEMORY.md`
- `memory/daily/`
- `40-personal/41-daily/`
- `40-personal/42-weekly/`
- `40-personal/46-todos/`
- `00-system/04-docs/MEMORY_LANES.md`

## Contract Layer

- `00-system/02-contracts/IDENTITY.md`
- `00-system/02-contracts/SOUL.md`
- `00-system/02-contracts/USER.md`
- `00-system/02-contracts/TOOLS.md`
