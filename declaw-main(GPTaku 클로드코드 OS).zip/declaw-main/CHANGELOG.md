# Changelog

## v0.2.0 — 2026-04-04

### Self-improvement loop

- SessionStart hook injects durable memory + daily notes + pending skill candidates
- PreCompact hook agent reads session JSONL and auto-captures knowledge to memory
- Stop hook agent extracts repeatable patterns from session JSONL into pending.json
- Next session surfaces pending candidates as a nudge — user approves before creation
- New rule: 80-skill-self-healing (diagnose → backup → patch → record)
- New directory: .claude/skills/_candidates/ for pending.json + patch backups

### Proactive prompt engineering

- 50-memory-policy: proactive save triggers, 10-exchange checkpoint, check-before-answer
- 60-flow-policy: skill awareness protocol, scan SKILLS_INDEX before responding, dormant skill hygiene
- CLAUDE.md: skill awareness section added
- SKILLS_INDEX.md: full skill catalog with 7-pack taxonomy

### New skills (6)

- `github-workflow` (devops) — gh CLI PR/issue/CI/release automation
- `rss-feeds` (research) — RSS/Atom subscription and new article tracking
- `obsidian-pkm` (platform) — Obsidian vault CRUD via native file tools
- `notion-sync` (platform) — Notion API integration via curl
- `social-publish` (content) — Draft-Approve-Execute social posting
- `diagram-gen` (content) — Mermaid + Excalidraw diagram generation

### Multi-agent orchestration

- Orchestrator skill with auto-trigger (Micro/Sprint/Full Council routing)
- 70-orchestration-policy rule for complexity-based agent selection
- 7 new agents: analyst, advocate, critic, planner, implementer, chairman, gate-keeper
- Agent-builder skill for creating new sub-agents via expert discussion
- AGENTS_INDEX.md catalog (11 agents total)
- Independence protocol for unbiased parallel agent judgment

### Workspace OS core

- 14 operator commands (all with YAML frontmatter)
- 9 modular rules (00-80, auto-loaded)
- 3-lane memory system (durable + continuity + daily log)
- Contract layer (IDENTITY, SOUL, USER, TOOLS)
- Bootstrap files (BOOT, BOOTSTRAP, HEARTBEAT)
- Beyond the Terminal guide (Remote Control, Channels, Scheduled Tasks)

### Documentation

- README.md + README.ko.md with language switcher
- GETTING_STARTED.md first-run guide
- PACKS.md + 4 pack docs (assistant, research, evolution, bridge)
- MEMORY_LANES.md lane model
- OPERATING_MODEL.md operating flow

---

## v0.1.0 — 2026-03-14

Initial skill pack release (pre-workspace OS).

- 7 skills: onboarding, skill-builder, morning-briefing, email-automation, web-monitor, meeting-notes, deep-research
- Basic CLAUDE.md
- plugin.json
