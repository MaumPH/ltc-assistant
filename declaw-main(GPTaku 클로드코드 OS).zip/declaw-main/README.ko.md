[English](README.md) | 한국어

# declaw

![declaw](declaw-banner-v9.png)

> **Claude Code를 위한 범용 workspace OS starter kit.**

Claude Code를 코딩 도우미가 아니라 범용 workspace 운영체제로 바꿔줍니다.

[시작하기](#시작하기) • [Commands](#commands) • [Agents](#agents) • [Skills](#skills) • [Memory](#memory-lanes) • [문서](#문서)

---

## 시작하기

### 1. 클론

```bash
git clone https://github.com/fivetaku/declaw.git
cd declaw
```

### 2. Claude Code 실행

```bash
claude
```

### 3. 온보딩

```
/onboarding
```

온보딩이 안내하는 것:
- workspace 구조 파악
- 정체성/사용자 계약 파일 채우기
- scaffold 유효성 검증
- capability pack 선택

### 4. 작업 시작

```
/daily-note          # 오늘 일지 시작
/todo 버그 수정       # 할 일 캡처
/thinking-partner    # 문제 구조화
/setup-workspace     # scaffold 검증
```

### 어떻게 동작하나요?

declaw를 클론하면 `CLAUDE.md` 하나가 아니라 **미리 구조화된 workspace**를 받습니다:

```
declaw/
├── CLAUDE.md                  # 루트 헌법
├── INDEX.md                   # workspace 네비게이션 맵
├── .claude/
│   ├── CLAUDE.md              # 컨트롤 플레인 (contracts + rules import)
│   ├── commands/              # 12개 슬래시 커맨드
│   ├── agents/                # 4개 역할형 에이전트
│   ├── rules/                 # 7개 규칙 파일 (자동 로딩)
│   ├── skills/                # 코어 OS 스킬 + capability packs
│   ├── bootstrap/             # 세션 시작/셋업/상태체크 체크리스트
│   └── settings.json          # 라이프사이클 hooks
├── 00-inbox/                  # 임시 저장
├── 00-system/
│   ├── 01-templates/          # 일지, todo, 주간 리뷰 템플릿
│   ├── 02-contracts/          # IDENTITY, SOUL, USER, TOOLS
│   ├── 03-tools/              # 39개 도구 레퍼런스 문서 (TOOLS.md로 인덱싱)
│   └── 04-docs/               # MEMORY_LANES, OPERATING_MODEL
├── 10-backlog/                # 아이디어/대기 작업
├── 20-testing/                # 검증 기록
├── 30-docs/                   # 사용 가이드, pack 문서
├── 40-personal/
│   ├── 41-daily/              # 사람용 일지
│   ├── 42-weekly/             # 주간 리뷰
│   └── 46-todos/              # 할 일 목록
├── 50-resources/              # 참고 자료
├── 90-archive/                # 완료/폐기
├── memory/
│   ├── MEMORY.md              # 위키 인덱스 (LLM Wiki 패턴)
│   ├── wiki/                  # 위키 페이지로 관리하는 장기 기억
│   │   ├── decisions/
│   │   ├── preferences/
│   │   ├── project-context/
│   │   ├── tool-patterns/
│   │   └── pitfalls/
│   └── daily/                 # 에이전트 세션 handoff
```

Claude Code는 매 세션마다 `CLAUDE.md`, `.claude/CLAUDE.md`, `.claude/rules/*.md`를 자동 로딩합니다. 별도 설정 없이 클론하고 바로 시작하면 됩니다.

---

## 왜 declaw인가?

- **CLAUDE.md 하나가 아닙니다** — contracts, memory lanes, commands, agents, skills, hooks를 갖춘 완전한 workspace 구조
- **코딩 도우미만이 아닙니다** — 리서치, 운영, 지식 관리, 개인 비서, 콘텐츠, 코드 작업까지 포괄
- **문서 기반 에이전트 오케스트레이션에서 영감** — Claude Code 네이티브 기능으로 재구성
- **세션이 이어집니다** — memory lanes + daily handoff로 매 세션이 이전 세션을 이어받음
- **조작 표면** — 12개 슬래시 커맨드로 채팅이 아니라 workspace UI를 제공
- **역할 에이전트** — architect, reviewer, researcher, operator에게 도구 접근 범위를 제한하고 위임
- **확장 가능** — 코어 위에 commands, agents, skills, capability pack 자유롭게 추가

---

## Commands

슬래시 커맨드는 workspace를 조작하는 UI입니다.

| 커맨드 | 설명 |
|--------|------|
| `/onboarding` | 첫 실행 — 구조 파악, 계약 채우기, scaffold 검증 |
| `/setup-workspace` | workspace scaffold 유효성 검증 |
| `/daily-note` | 오늘 일지 열기/생성 |
| `/daily-review` | 하루 리뷰, memory 업데이트, handoff 작성 |
| `/session-closeout` | 세션 종료 시 상태 캡처 + handoff 작성 |
| `/weekly-review` | 주간 리뷰 생성 |
| `/todo [할 일]` | 할 일 빠르게 캡처 |
| `/todos` | 현재 할 일 상태 확인 |
| `/idea [아이디어]` | 아이디어를 inbox에 캡처 |
| `/thinking-partner` | 대화를 통한 문제 구조화 |
| `/inbox-processor` | inbox 항목 분류/라우팅 |
| `/sync` | workspace 변경 요약 및 동기화 |
| `/create-command` | 새 커맨드 생성 |

---

## Agents

위임된 추론을 위한 역할형 에이전트.

| 에이전트 | 역할 | 적합한 작업 |
|----------|------|-------------|
| `architect` | 구조화, 분해, 시스템 판단 | 설계 결정, 태스크 분해, 아키텍처 리뷰 |
| `reviewer` | 리스크, 회귀, 검증 | 코드 리뷰, 품질 게이트, 회귀 체크 |
| `researcher` | 근거 수집과 합성 | 문서 리서치, 경쟁 분석, 팩트 체크 |
| `operator` | workspace 유지보수와 조직화 | 파일 관리, 정리, 루틴 운영 |

---

## Skills

스킬은 재사용 가능한 capability입니다.

### Core Skills (Workspace OS)

| 스킬 | 설명 |
|------|------|
| `workspace-bootstrap` | scaffold 검증 및 초기 설정 |
| `memory-capture` | 결정/지식을 장기 기억에 기록 |
| `daily-sync` | 일지와 continuity handoff 동기화 |
| `session-closeout` | 세션 종료 시 memory flush와 handoff 작성 |
| `bridge-placeholder` | 외부 서비스 연동 확장 지점 |
| `onboarding` | 첫 실행 가이드 |
| `skill-builder` | 반복 워크플로우에서 새 스킬 생성 |

### Capability Packs

| 팩 | 스킬 | 설명 |
|----|------|------|
| **Assistant** | `morning-briefing`, `email-automation`, `calendar`, `habit-tracker` | 개인 비서 |
| **Research** | `deep-research`, `web-monitor`, `data-analyst`, `transcribe` | 조사/분석 |
| **Content** | `content-draft`, `presentation`, `document-converter` | 콘텐츠 제작 |
| **Platform** | `apple-notes`, `apple-reminders` | macOS 앱 연동 |
| **DevOps** | `docker-ops`, `ci-monitor` | 인프라 모니터링 |

---

## Memory Lanes

기억을 3개 lane으로 분리하여 세션 간 맥락 유지와 깨끗한 handoff를 보장합니다. 장기 기억은 **LLM Wiki 패턴**을 사용합니다 — 인덱스 파일이 구조화된 위키 페이지를 가리키는 방식으로, 벡터 DB 없이 동작합니다.

| Lane | 위치 | 용도 | 대상 |
|------|------|------|------|
| **위키 (장기 기억)** | `memory/MEMORY.md` + `memory/wiki/` | YAML frontmatter를 가진 위키 페이지로 관리하는 안정적 지식 | 에이전트 (인덱스 자동 로딩) |
| **Continuity** | `memory/daily/YYYY-MM-DD.md` | 세션 handoff | 에이전트 |
| **일지** | `40-personal/41-daily/YYYY-MM-DD.md` | 사람이 읽는 작업 일지 | 사람 |

위키 페이지는 카테고리별(`decisions`, `preferences`, `project-context`, `tool-patterns`, `pitfalls`)로 구성되며, 인덱스 우선 검색 방식으로 조회합니다: `MEMORY.md` 읽기 → 관련 페이지 링크 따라가기 → 못 찾으면 Grep.

자세한 내용: `00-system/04-docs/MEMORY_LANES.md`

---

## Contract Layer

하나의 거대한 `CLAUDE.md` 대신 모듈화된 계약 문서를 사용합니다.

| 계약 | Claude Code 매핑 | 용도 |
|------|------------------|------|
| `IDENTITY.md` | `.claude/rules/10-identity.md` | workspace 에이전트 정체성 |
| `SOUL.md` | `.claude/rules/10-identity.md` | 핵심 가치관과 행동 원칙 |
| `USER.md` | `CLAUDE.local.md` | 사용자 정보 |
| `TOOLS.md` | `.claude/rules/40-tooling.md` | 도구 사용 원칙 |

전체 계약: `00-system/02-contracts/`

---

## Tool Registry

declaw는 4-tier 도구 레지스트리를 유지하여 에이전트가 무엇을 쓸 수 있고, 어떻게 사용하는지 알 수 있게 합니다.

| Tier | 종류 | 예시 |
|------|------|------|
| **Tier 1 — Built-in** | Claude Code 내장, 항상 사용 가능 | Read, Write, Edit, Bash, WebSearch, WebFetch, Agent, Computer Use |
| **Tier 2 — CLI** | Bash로 호출 (`which`로 확인) | git, gh, python3, curl, pandoc, ffmpeg, whisper, osascript |
| **Tier 3 — Public API** | 인증 불필요, curl로 접근 | X/Twitter Syndication API, Reddit JSON API, HN Firebase API, Wikipedia REST |
| **Tier 4 — Connectors** | 사용자 설정 필요 (MCP 서버) | Perplexity, Playwright, Slack, Discord, Linear, Supabase |

- **인덱스**: `00-system/02-contracts/TOOLS.md` — 매 세션 `@TOOLS.md`로 로딩
- **레퍼런스 문서**: `00-system/03-tools/{tool}.md` — 39개 개별 도구 문서 (사용 패턴 + 예시)
- **선택 순서**: Tier 1 먼저 → 부족하면 Tier 2 → 외부 데이터는 Tier 3 → 설정된 경우만 Tier 4

서브 에이전트에 작업을 위임할 때, 오케스트레이터가 해당 도구 문서를 읽고 패턴을 에이전트 프롬프트에 포함합니다 — 에이전트는 도구별 패턴을 기본적으로 모릅니다.

---

## Lifecycle Hooks

hooks가 세션 경계에서 workspace 규율을 자동화합니다.

| 이벤트 | 동작 |
|--------|------|
| `SessionStart` | boot 체크리스트와 최근 memory context 주입 |
| `Stop` | memory 캡처와 handoff 작성 리마인드 |
| `PreCompact` | context 압축 전 memory flush 유도 |
| `Setup:init` | 첫 실행 시 `/setup-workspace` 안내 |
| `SubagentStart` | 위임 작업 스코핑 리마인드 |
| `SubagentStop` | 결과 형식 검증 |

설정 위치: `.claude/settings.json`

---

## 터미널 너머로

온보딩이 끝나면 터미널에 머물 필요 없습니다. declaw는 **Remote Control**, **Channels**, **Scheduled Tasks**를 통해서도 동작합니다.

### Remote Control — 폰/브라우저에서 사용

```bash
claude remote-control
```

세션 URL과 QR 코드가 표시됩니다. 어떤 기기에서든 접속 가능. 파일은 로컬에 유지됩니다.

### Channels — 메시징 브리지

외부 메시지를 Claude Code 세션에 직접 push합니다. 지원되는 채널을 활성화하고, 발신자를 인증한 뒤, workspace의 commands/skills/memory를 통해 작업을 라우팅합니다.

채널 설정의 구체적인 방법은 `.claude/skills/bridge-placeholder/SKILL.md`를 참고하세요.

### Scheduled Tasks — 반복 자동화

| 방법 | 실행 위치 | 머신 필요 | 최소 간격 |
|------|----------|----------|----------|
| `/loop` | 로컬 | 세션 열려있어야 | 1분 |
| Cloud tasks | Claude 호스팅 | 불필요 | 1시간 |
| Desktop tasks | 로컬 | 앱 열려있어야 | 1분 |

```
/loop 5m 프로젝트 상태 확인하고 이슈 있으면 알려줘
/schedule daily 매일 9am 아침 브리핑
```

### 기능 비교

| 기능 | 트리거 | 적합한 용도 |
|------|--------|------------|
| **Remote Control** | 브라우저/폰에서 직접 조작 | 진행 중인 작업을 다른 기기에서 이어서 |
| **Channels** | 외부 이벤트 push | 메시지로 작업 지시 |
| **Scheduled Tasks** | 크론/인터벌 | 아침 브리핑, 주기적 상태 점검, 반복 리뷰 |

---

## declaw가 아닌 것

- **게이트웨이 제품이 아닙니다** — Claude Code 기능을 workspace 운영 모델로 조합한 것
- **코딩 전용 플러그인이 아닙니다** — 코딩은 여러 use case 중 하나
- **스킬 모음이 아닙니다** — 스킬은 workspace OS core 위에 얹힘
- **CLAUDE.md 템플릿이 아닙니다** — 7개 계층을 가진 완전한 운영 구조

---

## 문서

| 문서 | 설명 |
|------|------|
| `INDEX.md` | workspace 네비게이션 맵 |
| `30-docs/GETTING_STARTED.md` | 시작 가이드 + 예시 |
| `30-docs/PACKS.md` | capability pack 개요 |
| `00-system/04-docs/MEMORY_LANES.md` | memory lane 모델과 정책 |
| `00-system/04-docs/OPERATING_MODEL.md` | 전체 운영 흐름 |
| `00-system/02-contracts/README.md` | contract layer 설명 |

---

## 요구 사항

- [Claude Code](https://docs.anthropic.com/claude-code) CLI
- Claude Max/Pro 구독 또는 Claude API 키

다른 의존성 없음. npm install 없음. 빌드 없음. 클론하고 바로 시작.

---

## 라이선스

MIT

---

<div align="center">

**Claude Code is the only claw you need.**

</div>
