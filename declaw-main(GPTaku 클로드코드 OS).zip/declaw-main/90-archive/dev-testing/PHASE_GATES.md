# Phase Gates

declaw development progresses by phase, and each phase must pass a review gate
before the next one begins.

## Gate Rules

1. Every phase must have explicit outputs and acceptance criteria.
2. Gate results must be one of: `PASS`, `PASS with follow-ups`, or `FAIL`.
3. A `FAIL` blocks the next phase.
4. `PASS with follow-ups` means non-blocking items must be resolved before the next relevant gate.

## Current Gates

### Phase 1-4: Workspace OS Core Seed

Status: `PASS`

Validated:
- README, CLAUDE, and INDEX exist
- contract docs exist
- `.claude/commands`, `.claude/agents`, `.claude/rules`, `.claude/bootstrap`, and `.claude/skills` exist
- memory lanes exist
- templates exist

Non-blocking follow-ups:
- validate hooks in real use
- validate command ergonomics
- refine capability pack taxonomy

### Phase 5: Usability Validation

Status: `PASS with follow-ups`

Validated:
- daily note and continuity lanes can be applied to real files
- todo flow attaches to the file structure cleanly
- memory policy and hook guidance were clarified

Follow-ups:
- validate hook verbosity in real use
- continue refining pack boundaries

### Phase 6: Capability Pack Taxonomy

Status: `PASS`

Validated:
- skills can be read through assistant / research / evolution / bridge grouping
- core vs pack boundaries are consistent across README, INDEX, and PACKS docs

Non-blocking follow-ups:
- physical pack reorganization can wait
- validate whether the grouping is intuitive in real use

### Phase 7: Live Session Validation

Status: `PASS with follow-ups`

Validated:
- daily note flow
- todo flow
- thinking-partner flow
- continuity vs durable memory split
- closeout handoff flow

Follow-ups:
- validate hook usefulness in an actual Claude session

### Next Gate: Phase 8 Hook-in-the-loop Validation

Goal:
- verify that `SessionStart`, `PreCompact`, `Stop`, `SubagentStart`, and `SubagentStop` seeds are actually useful in a Claude session

Pass conditions:
- hook messages are not too noisy
- they help memory and closeout behavior
- they do not get in the way of the operator surface

### Phase 8: Hook-in-the-loop Validation

Status: `PASS with follow-ups`

Validated:
- `SessionStart` fired in a real Claude session
- `Stop` fired in a real Claude session
- `SubagentStart` fired in a real Claude session
- `SubagentStop` fired in a real Claude session
- project hook logging worked through `20-testing/hook-events.log`

Follow-ups:
- validate `PreCompact` in a real compact flow
- decide whether hook logging should stay enabled outside testing
- assess interaction with user/global hook layers
