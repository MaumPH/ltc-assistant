# Reviewer Scenarios

This document defines scenario-based review flows for another Claude Code
session or human reviewer.

## How to use this document

For each scenario:
1. follow the steps in order
2. inspect the listed evidence
3. record a verdict
4. list friction and improvements

Use verdicts:
- PASS
- PASS with follow-ups
- FAIL

## Scenario 1: First-run orientation

Goal:
- determine whether a new user can understand what declaw is and how to begin

Steps:
1. read `README.md`
2. read `INDEX.md`
3. read `30-docs/GETTING_STARTED.md`
4. inspect `.claude/commands/onboarding.md`

Evidence:
- `README.md`
- `INDEX.md`
- `30-docs/GETTING_STARTED.md`
- `.claude/commands/onboarding.md`

Pass if:
- the project reads as a workspace OS, not just a skill bundle
- the first entrypoints are clear

## Scenario 2: Operator surface clarity

Goal:
- determine whether commands feel like a coherent operator UI

Steps:
1. read `.claude/commands/README.md`
2. inspect `daily-note`, `todo`, `thinking-partner`, `sync`

Evidence:
- `.claude/commands/README.md`
- `.claude/commands/daily-note.md`
- `.claude/commands/todo.md`
- `.claude/commands/thinking-partner.md`
- `.claude/commands/sync.md`

Pass if:
- each command has a distinct operator role
- the set feels like a usable workspace surface

## Scenario 3: Contract layer coherence

Goal:
- determine whether the contract docs and rules form a coherent system

Steps:
1. read `.claude/CLAUDE.md`
2. inspect `00-system/02-contracts/*`
3. inspect `.claude/rules/*`

Evidence:
- `.claude/CLAUDE.md`
- `00-system/02-contracts/README.md`
- `00-system/02-contracts/IDENTITY.md`
- `00-system/02-contracts/SOUL.md`
- `00-system/02-contracts/USER.md`
- `00-system/02-contracts/TOOLS.md`
- `.claude/rules/*.md`

Pass if:
- the include chain is clear
- contracts and rules do not feel redundant

## Scenario 4: Memory lane usability

Goal:
- determine whether durable memory, continuity memory, and human-facing logs are understandable

Steps:
1. read `00-system/04-docs/MEMORY_LANES.md`
2. inspect `memory/MEMORY.md`
3. inspect one continuity note
4. inspect one daily note

Evidence:
- `00-system/04-docs/MEMORY_LANES.md`
- `memory/MEMORY.md`
- `memory/daily/2026-04-04.md`
- `40-personal/41-daily/2026-04-04.md`

Pass if:
- the three lanes are clearly distinguishable
- the reviewer can explain what belongs where

## Scenario 5: Daily loop

Goal:
- determine whether the basic day-to-day loop feels natural

Steps:
1. inspect `/daily-note`
2. inspect `/todo`
3. inspect `memory-capture`
4. inspect `session-closeout`

Evidence:
- `.claude/commands/daily-note.md`
- `.claude/commands/todo.md`
- `.claude/skills/memory-capture/SKILL.md`
- `.claude/skills/session-closeout/SKILL.md`
- `40-personal/46-todos/active-todos.md`

Pass if:
- the loop leaves a useful handoff
- tasks and notes feel connected

## Scenario 6: Hook usefulness

Goal:
- determine whether hook seeds are useful and not too noisy

Steps:
1. read `.claude/settings.json`
2. inspect `20-testing/hook-events.log`
3. read `phase-08-hook-in-the-loop-validation.md`

Evidence:
- `.claude/settings.json`
- `20-testing/hook-events.log`
- `20-testing/phase-08-hook-in-the-loop-validation.md`
- `20-testing/phase-08-hook-validation-result.md`

Pass if:
- the hook messages are light enough
- SessionStart and Stop help more than they distract
- subagent hooks meaningfully support delegated work

## Scenario 7: Active skill path sanity

Goal:
- determine whether the actual active skills are in the right place for Claude discovery

Steps:
1. inspect `.claude/skills/`
2. inspect `skills/README.md`
3. compare core skills vs capability skills

Evidence:
- `.claude/skills/`
- `skills/README.md`

Pass if:
- the reviewer can explain active runtime copies vs pack source role
- there is no confusion about what Claude can discover

## Scenario 8: Capability pack model

Goal:
- determine whether the pack model is coherent

Steps:
1. read `30-docs/PACKS.md`
2. inspect each pack doc

Evidence:
- `30-docs/PACKS.md`
- `30-docs/packs/assistant-pack.md`
- `30-docs/packs/research-pack.md`
- `30-docs/packs/evolution-pack.md`
- `30-docs/packs/bridge-pack.md`

Pass if:
- core vs pack separation is understandable
- future growth direction is obvious

## Scenario 9: Product definition

Goal:
- determine whether declaw now reads as a workspace OS starter kit

Steps:
1. read `README.md`
2. read `CLAUDE.md`
3. read `plugin.json`

Evidence:
- `README.md`
- `CLAUDE.md`
- `plugin.json`

Pass if:
- the reviewer would describe declaw as a workspace OS
- not as a coding-only plugin

## Result template

```markdown
# Reviewer Scenario Result

## Scenario
- [name]

## Verdict
- PASS / PASS with follow-ups / FAIL

## Evidence
- [file]
- [file]

## Findings
- [finding]

## Friction
- [friction]

## Recommended changes
- [change]
```
