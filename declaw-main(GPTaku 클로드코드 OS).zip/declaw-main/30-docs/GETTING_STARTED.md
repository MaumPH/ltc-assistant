# Getting Started

declaw is a workspace operating system, not just a skill pack. This guide walks you through first-time setup and daily usage.

---

## What happens when you launch Claude Code

When you run `claude` inside the declaw directory, Claude Code automatically:

1. **Loads `CLAUDE.md`** — the root constitution defining workspace principles
2. **Loads `.claude/CLAUDE.md`** — the control plane that imports all contracts and rules
3. **Auto-loads `.claude/rules/*.md`** — 7 modular rule files (identity, user contract, project map, tooling, memory policy, flow policy, operating system)
4. **Reads `settings.json` hooks** — SessionStart injects the boot checklist, Stop reminds to capture memory

You don't need to configure anything. The workspace is ready from the first session.

---

## First-run: `/onboarding`

```
/onboarding
```

The onboarding skill guides you through 7 steps:

| Step | What it does |
|------|-------------|
| 1 | Checks your environment (Python, Node, calendar CLI, etc.) |
| 2 | Walks you through the workspace structure (README → INDEX → contracts) |
| 3 | Helps you fill in your contract files (IDENTITY, USER, SOUL, TOOLS) |
| 4 | Shows you the operator surface (commands, agents, skills) |
| 5 | Demonstrates memory lanes with a live example |
| 6 | Lets you choose which capability packs to activate |
| 7 | Optionally sets up external integrations (Google Workspace, MCP) |

You can skip steps or resume later: `/onboarding step=3`

---

## Filling in your contracts

After onboarding, customize these files to make the workspace yours:

### `00-system/02-contracts/USER.md`

```markdown
# USER

- Name: Your Name
- Role: Developer / PM / Researcher / ...
- Preferred response style: concise, detailed, conversational
- Common tasks: code review, research, writing, planning
- What matters most: accuracy, speed, creativity
- What to avoid: unsolicited suggestions, overly verbose responses
```

### `00-system/02-contracts/IDENTITY.md`

Already filled with declaw defaults. Modify if you want to change the workspace persona.

### `CLAUDE.local.md`

Add personal, machine-specific overrides here (this file is gitignored):

```markdown
# Local Overrides

- My timezone: Asia/Seoul
- Preferred language: Korean for conversation, English for code
- Local tools: gcalcli configured, himalaya for email
```

---

## Daily workflow

### Start of day

```
/daily-note              # Create today's log
/morning-briefing        # Get email + calendar + news summary (if configured)
```

### During work

```
/todo fix the auth bug   # Capture a task
/thinking-partner        # Structure a complex problem through dialogue
/deep-research AI agents # Research a topic with scoped questions
```

### End of day

```
/daily-review            # Review the day, update memory, write handoff
```

Or for a quick session end:

```
/session-closeout        # Write handoff + flush memory (agent-focused)
```

### Memory

```
remember this: we decided to use PostgreSQL instead of SQLite
```

This triggers the memory-capture skill, which saves the decision to the right memory lane:
- Durable decision → `memory/MEMORY.md`
- Today's context → `memory/daily/2026-04-04.md`
- Human log → `40-personal/41-daily/2026-04-04.md`

---

## Commands reference

| Command | What it does |
|---------|-------------|
| `/onboarding` | First-run guided setup |
| `/setup-workspace` | Validate scaffold integrity |
| `/daily-note` | Create/open today's daily note |
| `/daily-review` | End-of-day review + memory update |
| `/weekly-review` | Weekly synthesis from daily notes |
| `/todo [task]` | Quick task capture |
| `/todos` | View current tasks |
| `/idea [idea]` | Capture an idea to inbox |
| `/thinking-partner` | Structure a problem through dialogue |
| `/inbox-processor` | Triage and route inbox items |
| `/sync` | Summarize and sync workspace changes |
| `/create-command` | Create a new custom command |

---

## Commands vs skills vs agents

| Surface | Purpose | How to use | Example |
|---------|---------|-----------|---------|
| **Commands** | Operator-facing workspace UI | `/command-name` | `/daily-note`, `/todo fix bug` |
| **Skills** | Reusable capabilities | Triggered automatically or by name | `memory-capture`, `deep-research`, `morning-briefing` |
| **Agents** | Role-oriented delegated reasoning | `@agent-name task` or auto-delegated | `@architect review this design`, `@reviewer check for regressions` |

---

## Memory lanes

| Lane | File | Purpose | Written by |
|------|------|---------|------------|
| Durable | `memory/MEMORY.md` | Stable knowledge (survives all sessions) | memory-capture skill |
| Continuity | `memory/daily/YYYY-MM-DD.md` | Agent handoff (what to do next session) | memory-capture skill |
| Daily log | `40-personal/41-daily/YYYY-MM-DD.md` | Human-readable work journal | daily-note command / memory-capture |
| Weekly | `40-personal/42-weekly/` | Weekly reviews | weekly-review command |
| Todos | `40-personal/46-todos/active-todos.md` | Active task list | todo command |

Full model: `00-system/04-docs/MEMORY_LANES.md`

---

## Capability packs

Once the core is understood, activate packs as needed:

| Pack | Skills | Use case |
|------|--------|----------|
| **Assistant** | morning-briefing, email-automation, calendar, habit-tracker | Daily personal assistance |
| **Research** | deep-research, web-monitor, data-analyst, transcribe | Investigation and analysis |
| **Content** | content-draft, presentation, document-converter | Writing and publishing |
| **Platform** | apple-notes, apple-reminders | macOS native app integration |
| **DevOps** | docker-ops, ci-monitor | Infrastructure monitoring |

Pack details: `30-docs/PACKS.md`

---

## Beyond the terminal

declaw also works through:

- **Remote Control**: `claude remote-control` — access from phone/browser
- **Channels**: Discord, Telegram, iMessage — push messages into your session
- **Scheduled Tasks**: `/loop 5m check status` or `/schedule daily briefing at 9am`

See the README for full setup instructions.

---

## Troubleshooting

**"Command not found"**: Make sure you're inside the declaw directory when running `claude`.

**"Skill not triggered"**: Try the exact trigger phrase from the skill's description. Or invoke directly: `/skill-name`.

**"Missing external tool"**: Skills that need CLI tools (gcalcli, pandoc, whisper, etc.) will guide you through installation on first use.

**"Memory not persisting"**: Check that `memory/` directory exists. Run `/setup-workspace` to validate.
