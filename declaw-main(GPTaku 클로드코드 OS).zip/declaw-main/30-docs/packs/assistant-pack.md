# Assistant Pack

## Purpose

This pack handles day-to-day assistant-style automation.

## Included Skills

- `morning-briefing`
- `email-automation`
- `web-monitor`
- `meeting-notes`

## Problems It Solves

- day-start summaries
- inbox triage
- change monitoring
- meeting capture and action extraction
