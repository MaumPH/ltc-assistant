# Research Pack

## Purpose

This pack handles structured research, investigation, and synthesis.

## Included Skills

- `deep-research`

## Future Candidates

- `agent-council`
- domain-specific council variants

## Problems It Solves

- scoped research
- evidence gathering
- question decomposition
- structured outputs for downstream decisions
