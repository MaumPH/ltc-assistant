# Self-Evolution Pack

## Purpose

This pack lets declaw extend and improve itself.

## Included Skills

- `skill-builder`

## Future Candidates

- command-builder
- pattern-capture
- workspace-auditor

## Problems It Solves

- turning repeated work into reusable capabilities
- evaluating and improving skill quality
- growing the operator surface over time
