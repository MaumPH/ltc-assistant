# Bridge Pack

## Purpose

This pack defines how declaw connects to external systems.

## Current State

Core currently ships only placeholders and patterns, not full bridge implementations.

## Current Anchors

- `.claude/skills/bridge-placeholder/`
- `00-system/02-contracts/TOOLS.md`
- optional productivity integration patterns in `.claude/skills/onboarding/SKILL.md`

## Future Candidates

- messaging delivery bridge
- calendar and mail bridge
- webhook wrapper
- MCP-backed service bridge

## Principle

- core stays bridge-ready
- real integrations live in packs or wrappers
- declaw is not trying to ship a native gateway daemon
