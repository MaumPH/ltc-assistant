# Packs

declaw is organized in two layers.

## Workspace OS Core

Location:
- `CLAUDE.md`
- `INDEX.md`
- `.claude/`
- `memory/`
- numbered workspace tree

Composition:
- rules
- commands
- agents
- bootstrap
- core skills
- settings and hooks

## Capability Packs

Location:
- `skills/`

Current packs:
- Assistant Pack
- Research Pack
- Setup Pack
- Self-Evolution Pack
- Bridge Pack

Key rule:
- core comes first
- packs layer on top of core
- bridge starts as placeholder patterns before hard integrations
