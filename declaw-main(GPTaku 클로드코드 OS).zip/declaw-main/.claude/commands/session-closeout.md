---
description: Capture end-of-session state and write a clean handoff
allowed-tools: Read, Write, Edit, Glob
---

Close the session cleanly.

1. Review today's daily note and recent work state.
2. Write a short continuity handoff in `memory/daily/YYYY-MM-DD.md`.
3. Capture durable learnings that belong in `memory/MEMORY.md`.
4. Note unfinished work, risks, and the first next action.
5. Confirm where the next session should resume.
