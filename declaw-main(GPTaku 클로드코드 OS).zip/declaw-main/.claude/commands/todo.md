---
description: Add a new todo quickly
argument-hint: Todo text
allowed-tools: Read, Write, Edit, Bash
---

Add a new todo to `40-personal/46-todos/active-todos.md`.

If the file does not exist, create it from `00-system/01-templates/todo-template.md`.

Format:
- [ ] todo
  - added: YYYY-MM-DD HH:mm
  - context:
