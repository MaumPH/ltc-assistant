---
description: Show the current todo state in a structured view
allowed-tools: Read, Glob
---

Read the current todo state from `40-personal/46-todos/` and organize it as:

- today's tasks
- stale tasks
- project groupings
- cleanup or archive suggestions
