---
description: Capture an idea from the conversation into the workspace
argument-hint: Idea text or category
allowed-tools: Read, Write, Edit
---

Store the idea in `10-backlog/` or another clearly appropriate lane.

Include:
- one-line definition
- why it matters
- next step
