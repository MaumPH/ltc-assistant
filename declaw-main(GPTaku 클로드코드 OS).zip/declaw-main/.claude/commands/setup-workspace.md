---
description: Inspect the declaw workspace OS scaffold and identify missing seed files
allowed-tools: Read, Glob, Write, Edit, Bash
---

Inspect the declaw workspace scaffold.

1. Check whether required folders and files exist.
2. Validate `CLAUDE.md`, `00-system/02-contracts`, `.claude/rules`, `.claude/commands`, `.claude/agents`, and `memory/`.
3. Find files that still contain placeholders.
4. Propose or create missing seeds when appropriate.
5. Summarize the result as a checklist.
