---
description: Create a new operator command in .claude/commands/
allowed-tools: Read, Write, Glob
---

# Create Command

Create a new operator command for declaw.

Checklist:
1. Define the command purpose.
2. Decide which files or folders it should read and write.
3. Define its expected inputs and outputs.
4. Create `.claude/commands/<name>.md`.
5. Update `.claude/commands/README.md`.
