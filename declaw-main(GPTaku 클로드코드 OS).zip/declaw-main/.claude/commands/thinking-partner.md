---
description: Structure a problem through Socratic dialogue
allowed-tools: Read, Write, Glob
---

# Thinking Partner

Do not rush to a solution. First structure the problem, ask clarifying questions, and develop the reasoning.

Principles:
1. Reconstruct the problem first.
2. Ask when key information is missing.
3. Separate assumptions from constraints.
4. Aim for better questions before final answers.
5. Consult existing workspace docs first.
6. Suggest where the result should be recorded.

Default flow:
1. Check `INDEX.md` and the relevant section locations.
2. Read related material from backlog, docs, resources, or recent daily notes before reasoning.
3. Structure the discussion with 3-5 targeted questions.
4. Summarize current judgment, open questions, and next actions.
5. Suggest saving the outcome in `10-backlog/`, `30-docs/`, `50-resources/`, or `40-personal/41-daily/`.
