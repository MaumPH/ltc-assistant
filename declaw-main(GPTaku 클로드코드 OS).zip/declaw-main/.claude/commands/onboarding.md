---
description: First-run workspace onboarding — read structure, fill contracts, validate scaffold
allowed-tools: Read, Write, Glob
---

# Onboarding

Start declaw workspace OS onboarding.

This command should:
1. route the user into the `onboarding` skill
2. present the core docs in the right order
3. establish the first-run workspace OS flow

Read in this order:
1. `README.md`
2. `INDEX.md`
3. `00-system/02-contracts/README.md`
4. `00-system/04-docs/MEMORY_LANES.md`
5. `30-docs/GETTING_STARTED.md`
6. `.claude/skills/onboarding/SKILL.md`

Execution paths:
- ask for "start declaw onboarding"
- or use the `onboarding` skill directly

Focus:
- understand the workspace OS core first
- fill contracts second
- choose capability packs last
