---
description: Summarize session changes and sync workspace state
allowed-tools: Read, Bash, Glob
---

# Sync

Write a short session summary, inspect git state, and then sync safely.

Checklist:
1. Save the current session summary to `sessions/` or today's daily note.
2. Run `git status`.
3. Pull or rebase only when needed.
4. Summarize changes, then propose commit or push.

Do not force through conflicts.
Do not sync without writing a summary first.
