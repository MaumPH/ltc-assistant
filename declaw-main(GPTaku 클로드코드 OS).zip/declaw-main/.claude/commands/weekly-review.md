---
description: Create a weekly review and extract recurring patterns
allowed-tools: Read, Write, Glob
---

Create a weekly review using this week's daily notes.

Include:
- weekly progress
- recurring problems
- patterns worth keeping
- next week's priorities

If the target file does not exist, create it from `00-system/01-templates/weekly-review-template.md`.
