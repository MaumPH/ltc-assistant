---
description: Open or create today's daily note
allowed-tools: Read, Write, Bash
---

Open or create `40-personal/41-daily/YYYY-MM-DD.md` for today's date.

Use these sections:
- today's focus
- in progress
- decisions
- next actions

If the file does not exist, create it from `00-system/01-templates/daily-note-template.md`.

Additional rules:
- Check `memory/daily/YYYY-MM-DD.md` first if it exists so the human log and continuity note stay aligned.
- Keep `40-personal/41-daily/` human-facing and `memory/daily/` agent-facing.
