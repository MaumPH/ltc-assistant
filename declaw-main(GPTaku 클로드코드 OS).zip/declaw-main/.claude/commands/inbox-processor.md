---
description: Triage and route items from 00-inbox/ to appropriate locations
allowed-tools: Read, Write, Edit, Glob
---

# Inbox Processor

Read items in `00-inbox/` and route them to the right workspace lane.

Target lanes:
- `10-backlog/`
- `20-testing/`
- `30-docs/`
- `40-personal/`
- `50-resources/`
- `90-archive/`
