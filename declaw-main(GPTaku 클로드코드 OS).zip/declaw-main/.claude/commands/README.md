# Commands

These commands form declaw's operator surface.

## Core

- `/onboarding` — first-run entrypoint
- `/setup-workspace` — validate and complete the scaffold
- `/daily-note` — open or create today's daily note
- `/daily-review` — review the day and update handoff context
- `/weekly-review` — create a weekly review
- `/todo` — capture a todo quickly
- `/todos` — inspect current todo state
- `/idea` — capture an idea
- `/thinking-partner` — structure a problem through dialogue
- `/inbox-processor` — triage inbox items
- `/create-command` — create a new operator command
- `/sync` — summarize and sync workspace changes
- `/session-closeout` — capture end-of-session state and write a handoff

## Principle

Commands are the user-facing workspace UI.
Skills are the capability layer behind the UI.
