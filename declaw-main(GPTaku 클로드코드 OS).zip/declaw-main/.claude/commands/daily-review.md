---
description: Summarize today's work and leave a next-session handoff
allowed-tools: Read, Write, Edit, Glob
---

Summarize today's work.

1. Review today's daily note.
2. Capture key decisions, progress, and risks.
3. Write a short next-session handoff in `memory/daily/YYYY-MM-DD.md`.
4. Propose anything that should be promoted to `memory/MEMORY.md`.
