# Bootstrap

Complete these once:
- fill in workspace-specific commands and context
- finish the contract documents
- decide how daily notes and continuity notes should be used
- review the hook seeds
- confirm which capability packs should be active first
