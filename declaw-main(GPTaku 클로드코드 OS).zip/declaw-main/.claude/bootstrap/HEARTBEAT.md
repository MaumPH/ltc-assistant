# Heartbeat

- capture important context before it drifts away
- promote stable lessons into durable memory
- leave the next session a clear starting point
