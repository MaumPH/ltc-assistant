# Session Start Checklist

- what workspace area is active right now?
- is there recent continuity memory to read?
- should the session begin from backlog, testing, or current daily work?
- which command, agent, or skill is the right entrypoint?
