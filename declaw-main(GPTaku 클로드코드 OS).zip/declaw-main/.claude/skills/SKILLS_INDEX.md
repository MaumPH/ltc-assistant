# Skills Index

This index is read by the orchestrator and flow policy to select appropriate skills before responding.

| name | path | trigger | description | pack |
|------|------|---------|-------------|------|
| workspace-bootstrap | workspace-bootstrap/SKILL.md | "validate workspace", "check scaffold", "setup workspace", /setup-workspace | Validate the declaw workspace OS scaffold and report or fix missing pieces | core |
| session-closeout | session-closeout/SKILL.md | "end session", "close session", "wrap up", "세션 종료" | Agent-facing session handoff -- flush memory, flag risks, write continuity notes | core |
| onboarding | onboarding/SKILL.md | "set up declaw", "get started", "처음 설정", "온보딩" | Guide the user through first-time declaw workspace OS setup | core |
| orchestrator | orchestrator/SKILL.md | multi-perspective analysis, architecture decisions, strategic planning | Complexity-based routing to independent sub-agents with synthesis | core |
| skill-builder | skill-builder/SKILL.md | "make a skill", "create a skill", "스킬 만들어줘", "커맨드 만들어줘" | Assemble expert agents to analyze an idea and generate a production-ready skill | evolution |
| agent-builder | agent-builder/SKILL.md | "create agent", "build agent", "에이전트 만들어줘" | Build specialized sub-agents and auto-register them in AGENTS_INDEX.md | evolution |
| memory-capture | memory-capture/SKILL.md | "remember this", "기억해줘", "메모리에 저장", PreCompact hook | Capture session knowledge into the correct memory lane | core |
| daily-sync | daily-sync/SKILL.md | "sync today", "daily sync", "오늘 정리", "일지 갱신" | Keep daily memory lanes synchronized between sessions | core |
| morning-briefing | morning-briefing/SKILL.md | "morning briefing", "아침 브리핑", "daily brief" | Combined summary of email, calendar, news, and workspace status | assistant |
| deep-research | deep-research/SKILL.md | "research this", "리서치해줘", "deep research", "딥리서치" | Structured multi-agent research with triangulation and sourcing | research |
| calendar | calendar/SKILL.md | "check schedule", "일정 확인", "add event", "free time" | View, add, and search calendar events through CLI tools | assistant |
| email-automation | email-automation/SKILL.md | "check email", "이메일 확인", "inbox cleanup", "draft reply" | Draft-first email management with explicit approval before sending | assistant |
| meeting-notes | meeting-notes/SKILL.md | "meeting notes", "회의록 정리", "action items", "회의 요약" | Structure raw meeting input into formatted notes with action items | assistant |
| content-draft | content-draft/SKILL.md | "write blog", "draft content", "블로그 써줘", "글 써줘" | Research-backed content drafting for blogs, SNS, newsletters, articles | content |
| presentation | presentation/SKILL.md | "make slides", "프레젠테이션", "pitch deck", "PPT" | Create structured presentation outlines and slide decks | content |
| document-converter | document-converter/SKILL.md | "convert to PDF", "문서 변환", "pandoc", "docx로 만들어" | Convert documents between formats using pandoc | content |
| transcribe | transcribe/SKILL.md | "transcribe audio", "음성 변환", "STT", "whisper" | Convert audio/video files to text using Whisper CLI | content |
| data-analyst | data-analyst/SKILL.md | "analyze data", "데이터 분석", "CSV 분석", "시각화" | Analyze structured data files -- CSV, JSON, SQLite -- with CLI tools | research |
| web-monitor | web-monitor/SKILL.md | "watch this site", "사이트 감시", "변경 감지" | Monitor web pages for meaningful changes with snapshot comparison | research |
| apple-notes | apple-notes/SKILL.md | "check my notes", "Apple Notes", "노트 확인", "메모 검색" | Interact with macOS Notes.app through CLI (macOS only) | platform |
| apple-reminders | apple-reminders/SKILL.md | "remind me", "리마인더", "알림 설정", "check reminders" | Manage macOS Reminders.app through CLI (macOS only) | platform |
| habit-tracker | habit-tracker/SKILL.md | "track habit", "습관 기록", "streak check", "루틴 체크" | Track daily habits, maintain streaks, and review consistency | assistant |
| docker-ops | docker-ops/SKILL.md | "check containers", "docker status", "도커 확인" | Manage Docker containers and Compose stacks through natural language | devops |
| ci-monitor | ci-monitor/SKILL.md | "check CI", "build status", "GitHub Actions", "pipeline" | Monitor CI/CD pipelines -- GitHub Actions, builds, deployments | devops |
| github-workflow | github-workflow/SKILL.md | "create PR", "triage issues", "check CI", "PR 만들어줘", "이슈 정리", "릴리스" | gh CLI based PR/issue/code-review/CI/release automation | devops |
| bridge-placeholder | bridge-placeholder/SKILL.md | "connect external service", "bridge setup", "integrate with" | Extension point for connecting the workspace to external services | platform |
| obsidian-pkm | obsidian-pkm/SKILL.md | "obsidian note", "vault 검색", "데일리 노트", "PKM", "second brain" | Obsidian vault CRUD via native file tools (Read/Write/Grep/Glob) | platform |
| notion-sync | notion-sync/SKILL.md | "notion sync", "노션에 저장", "notion page", "노션 조회", "노션 DB" | Notion API integration via curl -- query, create, update pages | platform |
| rss-feeds | rss-feeds/SKILL.md | "subscribe feed", "RSS 구독", "피드 추가", "새 글 확인", "블로그 모니터링" | RSS/Atom feed subscription, scan, and new article tracking | research |
| social-publish | social-publish/SKILL.md | "post tweet", "트윗 올려줘", "SNS 발행", "social post", "스레드 발행" | Draft-Approve-Execute social publishing (X/Twitter via x-cli) | content |
| diagram-gen | diagram-gen/SKILL.md | "draw diagram", "다이어그램 그려", "flowchart", "mermaid", "excalidraw" | Generate Mermaid code + Excalidraw JSON diagrams | content |

## Pack Legend

| Pack | Purpose |
|------|---------|
| core | Workspace OS lifecycle -- bootstrap, memory, orchestration, session management |
| assistant | Daily productivity -- calendar, email, briefing, habits |
| research | Investigation and data -- deep research, data analysis, web monitoring |
| content | Creation and conversion -- writing, slides, documents, transcription |
| platform | OS-native integrations -- Apple Notes, Reminders, external bridges |
| devops | Infrastructure -- Docker, CI/CD monitoring |
| evolution | Self-improvement -- skill builder, agent builder |
