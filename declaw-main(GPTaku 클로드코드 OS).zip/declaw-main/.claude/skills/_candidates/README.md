# Skill Candidates

This directory holds automatically discovered skill candidates and backup copies of patched skills.

## Structure

| Path | Purpose |
|------|---------|
| `pending.json` | Skill candidates detected by the Stop hook (auto-generated, `.gitignore`d) |
| `backups/` | Pre-patch backups of skills before self-healing edits (`.gitignore`d) |

## Lifecycle

1. **Detection** -- The Stop hook scans recent session logs for repeated workflows and writes candidates to `pending.json`.
2. **Review** -- On next SessionStart, `pending.json` contents are surfaced in the bootstrap context for the user to review.
3. **Promotion** -- Approved candidates are built into full skills via `/skill-builder` and moved out of this directory.
4. **Cleanup** -- Rejected candidates are removed from `pending.json` manually or during session closeout.
5. **Backups** -- Before any skill self-healing patch is applied, the original file is copied into `backups/`. Backups are personal data and not committed to git.

## Notes

- `pending.json` and `backups/` are listed in `.gitignore` because they contain per-user session-derived data.
- Do not manually edit `pending.json` -- let the Stop hook manage it.
