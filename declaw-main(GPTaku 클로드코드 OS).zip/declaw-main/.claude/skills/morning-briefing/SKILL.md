---
name: morning-briefing
description: This skill should be used when the user asks to "morning briefing", "daily brief", "아침 브리핑", "오늘 브리핑", "아침 요약", "briefing please". Generates a combined summary of email, calendar, and news. For calendar-only queries like "오늘 일정" use calendar skill instead.
arguments:
  - name: format
    description: Output format — "file" (save to disk), "inline" (show in chat). Default is "file".
    default: "file"
  - name: topics
    description: Comma-separated news topics.
    default: "tech,ai,startup"
tools:
  - WebSearch
  - WebFetch
  - Bash
  - Read
  - Write
---

# Morning Briefing

> A concise AI-generated morning briefing for daily planning. Combines email, calendar, news, and workspace status.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Start gathering inputs immediately. Do not ask what to include — include everything available.

---

## Workflow

### Step 1: Check available data sources
**Type**: script

Detect which data sources are accessible:

```bash
# Calendar
command -v gcalcli >/dev/null 2>&1 && echo "CALENDAR=gcalcli"
command -v icalBuddy >/dev/null 2>&1 && echo "CALENDAR=icalBuddy"

# Email
command -v himalaya >/dev/null 2>&1 && echo "EMAIL=himalaya"
command -v gog >/dev/null 2>&1 && echo "EMAIL=gog"

# Workspace state
test -f memory/daily/$(date -v-1d +%Y-%m-%d 2>/dev/null || date -d yesterday +%Y-%m-%d).md && echo "YESTERDAY_HANDOFF=yes"
test -f 40-personal/46-todos/active-todos.md && echo "TODOS=yes"
```

Skip unavailable sources gracefully. Do not error — just omit that section and note "Calendar/Email not configured."

### Step 2: Gather inputs in parallel
**Type**: script + prompt

Collect data from all available sources simultaneously:

**A. Calendar** (if available)
- Invoke calendar skill's "view" action for today's schedule
- Or: `gcalcli agenda $(date +%Y-%m-%d)` / `icalBuddy -f eventsToday`

**B. Email** (if available)
- Invoke email-automation skill's "summary" action for top 10 unread
- Or: `himalaya list --page-size 10`

**C. News** (always available)
- WebSearch for each topic in `$ARGUMENTS.topics`
- Extract top 3 headlines per topic

**D. Workspace status** (always available)
- Read yesterday's handoff (`memory/daily/{YESTERDAY}.md`)
- Read active todos (`40-personal/46-todos/active-todos.md`)
- Check incomplete habits if habit-tracker is active (`40-personal/habits.md`)

### Step 3: Synthesize briefing
**Type**: prompt

Combine all inputs into a prioritized briefing:

```markdown
# Morning Briefing — {date}

## Top Priorities
1. {most urgent/important item from any source}
2. {second priority}
3. {third priority}

## Schedule
{today's calendar events, or "Calendar not configured"}

## Email
{unread summary with urgency, or "Email not configured"}

## Carry-Forward
{items from yesterday's handoff}

## Active Todos
{from active-todos.md}

## News
### {topic 1}
- {headline with brief context}
### {topic 2}
- {headline}

## Suggested Actions
- [ ] {actionable recommendation}
- [ ] {actionable recommendation}
```

Priority ordering:
1. Urgent (meetings in <2 hours, high-priority emails)
2. Important (carry-forward items, deadlines)
3. Informational (news, low-priority emails)

### Step 4: Deliver
**Type**: generate

**Format: file** (default)
Save to `40-personal/41-daily/{DATE}-briefing.md`

**Format: inline**
Output the briefing directly in the chat.

Report:
```
Morning briefing ready ({date}).
Sources: {calendar/email/news/workspace — which were available}
Priorities: {N} items flagged
{If file: "Saved to: {path}"}
```

---

## Edge Cases

**No external tools configured**: Generate a workspace-only briefing (carry-forward + todos + news). Note which sources are missing and suggest setup via bridge-placeholder skill.

**Weekend/holiday**: Reduce email urgency thresholds. Skip "carry-forward" if yesterday was Friday and today is Monday (check last 3 days instead).

**Empty day (no events, no emails, no todos)**: Report "Light day ahead" and suggest proactive work from backlog.

**Rate-limited search**: If WebSearch fails, skip news section. Don't block the entire briefing.

---

## Integration Points

- **calendar**: Calls calendar skill for schedule section. Calendar handles the actual CLI interaction.
- **email-automation**: Calls email-automation for inbox summary. Email handles auth and CLI.
- **daily-sync**: morning-briefing can trigger daily-sync "start" mode to load yesterday's context.
- **habit-tracker**: Includes incomplete habits in the briefing if available.
- **web-monitor**: Can include watched page changes in the briefing.
- **Scheduled Tasks**: Ideal for `/schedule daily morning briefing at 9am` (Cloud Task) or Desktop Task.
