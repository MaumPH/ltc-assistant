---
name: presentation
description: This skill should be used when the user asks to "make slides", "프레젠테이션 만들어", "슬라이드 만들어", "presentation outline", "발표 자료", "pitch deck", "create a deck", "PPT 만들어", or any slide/presentation creation request.
arguments:
  - name: topic
    description: Presentation topic or title.
    default: ""
  - name: slides
    description: Target number of slides. Default is 10.
    default: "10"
  - name: format
    description: "outline" (markdown), "marp" (Marp slides), "reveal" (reveal.js). Default is "outline".
    default: "outline"
tools:
  - Read
  - Write
  - WebSearch
---

# Presentation

> Create structured presentation outlines and slide decks. Supports markdown outlines, Marp, and reveal.js formats.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

If topic is provided, start creating. If not, ask what the presentation is about.

---

## Workflow

### Step 1: Understand presentation
**Type**: prompt

From `$ARGUMENTS`, determine:
- **Topic**: what is the presentation about
- **Audience**: who is watching (executives, developers, students, etc.)
- **Duration**: how long (5/10/15/30 min) → maps to slide count
- **Purpose**: inform / persuade / teach / pitch
- **Format**: outline / marp / reveal.js

Duration-to-slides mapping:
| Duration | Slides |
|----------|--------|
| 5 min | 5-7 |
| 10 min | 8-12 |
| 15 min | 12-18 |
| 30 min | 20-30 |

### Step 2: Research key points
**Type**: prompt

For informational/persuasive presentations:
- Use WebSearch for 3-5 supporting facts/stats
- Identify the narrative arc

For pitch decks, follow standard structure:
Problem → Solution → Market → Product → Traction → Team → Ask

### Step 3: Create slide outline
**Type**: generate

```markdown
# {Title}

## Slide 1: Title Slide
- Title
- Subtitle
- Presenter / Date

## Slide 2: {Hook / Problem}
- Key point
- Supporting visual suggestion

## Slide 3: {Main Point 1}
- Bullet 1
- Bullet 2
- Speaker note: {what to say}

...

## Slide N: Closing / CTA
- Key takeaway
- Call to action
- Contact info
```

Each slide includes:
- Title
- 2-3 bullet points (not paragraphs)
- Visual suggestion (chart/image/diagram type)
- Speaker notes (what to say, not what to show)

### Step 4: Format output
**Type**: generate

**Format: outline** (default)
Save as markdown file. Human-readable, easy to paste into any tool.

**Format: marp**
Generate Marp-compatible markdown:
```markdown
---
marp: true
theme: default
---

# Title

---

## Slide 2

- Point 1
- Point 2

![bg right](image-suggestion.png)

---
```

**Format: reveal**
Generate reveal.js HTML structure.

### Step 5: Save and report
**Type**: generate

Save to `{topic-slug}-presentation.md` in current directory.

```
Presentation created: {filename}
Slides: {count}
Format: {format}
Duration: ~{estimated minutes} min

To present with Marp: npx @marp-team/marp-cli {filename} --html
```

---

## Edge Cases

**No topic**: Ask with 3 example topics (product pitch, tech talk, project update).
**Too many slides requested**: Cap at 40. Suggest splitting into parts.
**Marp not installed**: Provide installation: `npm install -g @marp-team/marp-cli`

---

## Integration Points

- **deep-research**: Research → presentation pipeline.
- **document-converter**: Convert slides to PDF for distribution.
- **content-draft**: Blog post → presentation adaptation.
