---
name: apple-reminders
description: This skill should be used when the user asks to "remind me", "set reminder", "리마인더", "알림 설정", "check reminders", "리마인더 확인", "할일 알림", or wants to interact with macOS Reminders app.
arguments:
  - name: action
    description: "list", "add", "complete", "search". Default is "list".
    default: "list"
  - name: content
    description: Reminder text, search term, or list name.
    default: ""
tools:
  - Bash
---

# Apple Reminders

> Manage macOS Reminders.app through CLI. Add, list, complete, and search reminders.

**Platform**: macOS only.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

---

## Workflow

### Step 1: Check platform
**Type**: script

```bash
[[ "$(uname)" == "Darwin" ]] && echo "MACOS=yes" || echo "MACOS=no"
```

If not macOS, suggest using workspace `/todo` command instead.

### Step 2: Execute action via AppleScript
**Type**: script

**Action: list**
```bash
osascript -e 'tell application "Reminders"
  set output to ""
  repeat with r in (reminders of default list whose completed is false)
    set output to output & name of r & linefeed
  end repeat
  return output
end tell'
```

**Action: add**
```bash
osascript -e 'tell application "Reminders"
  make new reminder in default list with properties {name:"'"$CONTENT"'"}
end tell'
```

With due date:
```bash
osascript -e 'tell application "Reminders"
  set d to date "'"$DATE"'"
  make new reminder in default list with properties {name:"'"$CONTENT"'", due date:d}
end tell'
```

**Action: complete**
```bash
osascript -e 'tell application "Reminders"
  set r to first reminder of default list whose name is "'"$CONTENT"'"
  set completed of r to true
end tell'
```

**Action: search**
```bash
osascript -e 'tell application "Reminders"
  set output to ""
  repeat with r in (reminders whose name contains "'"$CONTENT"'")
    set output to output & name of r & " [" & name of container of r & "]" & linefeed
  end repeat
  return output
end tell'
```

### Step 3: Report
**Type**: prompt

Format output and confirm action taken.

---

## Edge Cases

**Not macOS**: Suggest `/todo` command as workspace-native alternative.
**Reminders app not responding**: Retry once. If still failing, report error.
**Duplicate reminder names**: Show list name to disambiguate.

---

## Integration Points

- **/todo**: Workspace-native todo. Apple Reminders is for native OS integration.
- **morning-briefing**: Include overdue reminders in briefing.
- **calendar**: Cross-reference reminders with calendar events.
