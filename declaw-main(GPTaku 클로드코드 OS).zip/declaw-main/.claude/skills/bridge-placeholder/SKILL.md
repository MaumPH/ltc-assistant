---
name: bridge-placeholder
description: This skill should be used when the user asks to "connect external service", "bridge setup", "integrate with", "set up a channel", "configure remote control", "configure scheduled tasks", or wants to extend the workspace with external services. Provides integration patterns and guides.
arguments:
  - name: target
    description: The external service or pattern to integrate (e.g. "telegram", "calendar", "scheduled-task", "remote").
    default: ""
tools:
  - Bash
  - Read
  - Write
  - WebSearch
---

# Bridge Placeholder

> Extension point for connecting the workspace to external services. Provides patterns for Channels, Remote Control, Scheduled Tasks, and custom integrations.

---

## WHEN TRIGGERED

If `$ARGUMENTS` specifies a target, jump to the matching integration pattern below.
If no target, show the available patterns and ask what the user wants to connect.

---

## Available Integration Patterns

### Pattern 1: Claude Code Channels (Messaging Bridge)

Connect the workspace to external messaging platforms. Claude Code natively supports push-based channels.

**Supported channels:**
- iMessage (macOS only, Full Disk Access required)
- Telegram (Bot token required)
- Discord (Bot token required)
- Custom webhook (build your own MCP channel)

**Setup steps:**

1. Follow the current official Claude Code channel setup for the target platform.
2. Pair or authorize the sender using the platform's current access flow.
3. Start the workspace with the relevant channel enabled.

**How it works:**
- External messages arrive as `<channel>` tags in Claude's context
- Claude can reply back through a `reply(chat_id, text)` tool
- Sender allowlists prevent unwanted messages

**Custom webhook channel:**
Build an MCP server that declares `capabilities.experimental['claude/channel']` and emits `notifications/claude/channel` events. See Claude Code docs for the full spec.

**Workspace integration:**
- Incoming messages can trigger workspace commands
- Bridge skill can route messages to appropriate workspace areas (inbox, projects, etc.)

---

### Pattern 2: Remote Control (Mobile/Browser Access)

Access this workspace from phone, tablet, or browser while Claude Code runs locally.

**Setup:**
```bash
claude remote-control --name "My Workspace"
```

Or from inside a running session:
```
/remote-control My Workspace
```

**How it works:**
- Claude stays local (filesystem, MCP, tools all accessible)
- Connect from claude.ai/code, Claude mobile app, or direct URL
- Outbound HTTPS only (no inbound port exposure)
- Auto-reconnects on network drops

**Use cases:**
- Review work from phone during commute
- Approve actions remotely
- Quick todo capture from mobile

---

### Pattern 3: Scheduled Tasks (Periodic Automation)

Run workspace operations on a schedule without an open session.

**Three options:**

| Type | Runs on | Persistent | Min interval | Local files |
|------|---------|-----------|--------------|-------------|
| Cloud Task | Claude-hosted scheduled execution | Yes | 1 hour | No (fresh clone) |
| Desktop Task | Your machine | Yes | 1 minute | Yes |
| `/loop` | Active session | No (7-day expiry) | 1 minute | Yes |

**Cloud Task setup (recommended for daily automation):**
```
/schedule daily morning briefing at 9am
```
Or visit `claude.ai/code/scheduled` to create via web UI.

**Desktop Task setup (for local access):**
Desktop app → Schedule sidebar → New local task

**In-session loop:**
```
/loop 30m check project status and flag issues
```

**Workspace integration examples:**
- Morning briefing → Cloud Task, daily 9am
- Heartbeat status check → Desktop Task, hourly
- Deployment monitor → `/loop 5m` during active work

---

### Pattern 4: Headless CLI (Programmatic Access)

Run workspace operations from scripts, CI/CD, or other programs.

**Basic usage:**
```bash
claude -p "run /daily-review and save results" --allowedTools "Read,Write,Edit,Glob,Bash"
```

**Structured output:**
```bash
claude -p "list open todos" --output-format json
```

**In a cron job:**
```bash
# Daily 7am briefing
0 7 * * * cd /path/to/workspace && claude -p "/morning-briefing" --bare
```

**Agent SDK (Python/TypeScript):**
For deeper integration, use the Agent SDK to invoke workspace skills programmatically.

---

### Pattern 5: Optional Productivity Integrations

Connect calendar, email, and drive via CLI tools or MCP.

**Calendar (gcalcli):**
```bash
brew install gcalcli
gcalcli agenda  # verify it works
```

Then morning-briefing and calendar commands can pull live calendar data.

**Email (himalaya or gog):**
CLI email clients that avoid exposing OAuth tokens to Claude context.

**Drive or docs storage:**
Use an MCP server or a vendor CLI for file access.

**Credential rule:** Never expose raw OAuth tokens in Claude context. Use CLI tools that handle auth independently.

---

## Creating a New Bridge

To create a bridge for a service not listed above:

1. **Define the target**: What service? What operations? (read/write/both?)
2. **Choose the pattern**: Channel (push), Scheduled Task (periodic), Headless CLI (scripted), or direct API?
3. **Implement the connector**: CLI wrapper, MCP server, or API script
4. **Create a skill**: Write a SKILL.md that wraps the connector with workspace-aware logic
5. **Add to settings**: Hook or command entry point

Template for a new bridge skill:
```yaml
---
name: bridge-{service}
description: Connect workspace to {service} for {operations}.
tools:
  - Bash
  - Read
  - Write
---
```

---

## Edge Cases

**No internet**: Report that external bridges require internet. Suggest working offline and syncing later.

**Missing CLI tools**: Check if required tools (gcalcli, himalaya, etc.) are installed. If not, provide installation instructions.

**Auth expired**: If a CLI tool reports auth errors, guide the user through re-authentication without exposing credentials to Claude.
