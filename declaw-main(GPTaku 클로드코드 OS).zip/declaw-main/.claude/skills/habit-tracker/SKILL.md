---
name: habit-tracker
description: This skill should be used when the user asks to "track habit", "log habit", "습관 기록", "습관 추적", "streak check", "daily check-in", "how am I doing", "루틴 체크", or wants to maintain recurring personal goals.
arguments:
  - name: action
    description: "log" (record today), "status" (view streaks), "add" (new habit), "remove" (delete habit). Default is "status".
    default: "status"
  - name: habit
    description: Name of the habit to act on.
    default: ""
tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
---

# Habit Tracker

> Track daily habits, maintain streaks, and review personal consistency. File-based, no external dependencies.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Run the requested action against `40-personal/habits.md`.

---

## Workflow

### Step 1: Load habit file
**Type**: script

Check if `40-personal/habits.md` exists. If not, create with starter template:

```markdown
# Habits

| Habit | Goal | Created |
|-------|------|---------|

## Log

<!-- Daily entries below -->
```

### Step 2: Execute action
**Type**: prompt

**Action: status** — Show current habits and streaks
- Read `40-personal/habits.md`
- Calculate streak for each habit (consecutive days logged)
- Show today's completion status

Output:
```
Habit Status:
  Exercise     ████████░░ 8-day streak  ✅ today done
  Reading      ██████░░░░ 6-day streak  ❌ not yet
  Journaling   ██░░░░░░░░ 2-day streak  ❌ not yet
```

**Action: log** — Record today's habit completion
- Append entry: `| {date} | {habit} | done |`
- Update streak count

**Action: add** — Add a new habit to track
- Add row to habits table
- Confirm: "Now tracking: {habit}"

**Action: remove** — Stop tracking a habit
- Remove from active list (move to archive section)

### Step 3: Nudge
**Type**: prompt

After showing status, if habits are incomplete today:
```
You haven't logged {habit} today. Want to mark it done?
```

---

## Edge Cases

**First use**: Create the habits file with a welcome message and suggest 1-3 starter habits.
**Missed days**: Don't backfill. Just restart the streak. Show "last logged: {date}".
**Multiple logs same day**: Ignore duplicates for the same habit on the same date.

---

## Integration Points

- **/daily-note**: Include habit status summary in daily notes.
- **/daily-review**: Review habit streaks as part of daily review.
- **morning-briefing**: Mention incomplete habits in the briefing.
