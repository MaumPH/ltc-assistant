---
name: meeting-notes
description: This skill should be used when the user asks to "meeting notes", "회의록 정리", "회의 요약", "summarize a transcript", "액션 아이템 뽑아줘", "meeting summary", "extract action items", or provides a transcript/recording to structure.
arguments:
  - name: source
    description: File path (audio/text), URL, or "clipboard". Default is "clipboard".
    default: "clipboard"
  - name: format
    description: "summary", "detailed", or "action-items". Default is "detailed".
    default: "detailed"
tools:
  - Bash
  - WebFetch
  - Read
  - Write
---

# Meeting Notes

> Turn raw meeting input into structured notes. The meeting should happen once — the structuring should be automated.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Detect source type and start processing.

---

## Workflow

### Step 1: Detect and ingest source
**Type**: script + prompt

Determine source type from `$ARGUMENTS`:

| Source | Detection | Action |
|--------|-----------|--------|
| Audio file (.mp3, .wav, .m4a) | File extension | **Delegate to transcribe skill** first, then proceed with text |
| Text file (.md, .txt) | File extension | Read file directly |
| URL | Starts with http | WebFetch the content |
| Clipboard | Default / "clipboard" | Read from clipboard context |
| Inline text | No file/URL pattern | Use the provided text directly |

**Audio pipeline**: If source is an audio file, invoke the `transcribe` skill to convert audio → text first. Then continue with the transcript as the text source.

### Step 2: Extract structure
**Type**: prompt

From the raw text, extract:

1. **Participants** — who was present (names, roles if mentioned)
2. **Date/Time** — when the meeting happened
3. **Agenda** — topics discussed (in order of appearance)
4. **Key discussion points** — main arguments, proposals, concerns per topic
5. **Decisions** — what was decided (with who decided)
6. **Action items** — task, owner, deadline (if mentioned)
7. **Open questions** — unresolved items that need follow-up

### Step 3: Format output
**Type**: generate

**Format: summary** (1 page)
```markdown
# Meeting Summary — {date}

Participants: {list}

## Key Decisions
- {decision 1}
- {decision 2}

## Action Items
- [ ] {task} — {owner} — {deadline}

## Next Steps
- {what happens next}
```

**Format: detailed** (full notes)
```markdown
# Meeting Notes — {date}

Participants: {list}

## Agenda
1. {topic 1}
2. {topic 2}

## Discussion

### {Topic 1}
- {point}
- {counterpoint}
- **Decision**: {what was decided}

### {Topic 2}
...

## Action Items
| Task | Owner | Deadline | Status |
|------|-------|----------|--------|
| {task} | {owner} | {deadline} | Pending |

## Open Questions
- {unresolved item}
```

**Format: action-items** (just the tasks)
```markdown
# Action Items — {date}

| Task | Owner | Deadline |
|------|-------|----------|
| {task} | {owner} | {deadline} |
```

### Step 4: Save and report
**Type**: generate

Save to `sessions/{date}-meeting-notes.md` (or user-specified path).

```
Meeting notes saved: {path}
Format: {format}
Participants: {N}
Action items: {N}
Decisions: {N}
```

---

## Edge Cases

**Audio without transcribe skill**: If transcribe skill fails or whisper is not installed, guide the user to install whisper first or provide a text transcript instead.

**Very long transcript (>10,000 words)**: Summarize in chunks. Process each agenda topic separately.

**Multiple languages in one meeting**: Note the primary language. Translate key points if needed.

**No clear action items**: Report "No explicit action items identified" rather than inventing them.

**Incomplete transcript**: Note gaps: "Transcript appears incomplete from {time}."

---

## Integration Points

- **transcribe**: Audio → text preprocessing. meeting-notes calls transcribe for audio inputs.
- **memory-capture**: Promote key decisions from meetings to durable memory.
- **/daily-review**: Meeting notes link to daily review for context.
- **document-converter**: Export meeting notes as PDF/DOCX for distribution.
- **email-automation**: Draft follow-up email based on action items.
