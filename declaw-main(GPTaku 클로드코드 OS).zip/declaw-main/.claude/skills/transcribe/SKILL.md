---
name: transcribe
description: This skill should be used when the user asks to "transcribe audio", "음성 변환", "STT", "오디오 텍스트로", "녹음 파일 변환", "whisper", "voice to text", "음성 인식", or provides an audio file for transcription.
arguments:
  - name: source
    description: Path to audio file (mp3, wav, m4a, webm, mp4).
    default: ""
  - name: language
    description: Language code (ko, en, ja, etc.). Default auto-detect.
    default: ""
tools:
  - Bash
  - Read
  - Write
---

# Transcribe

> Convert audio/video files to text using Whisper CLI. Supports multiple languages and output formats.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

If a source file is provided, start transcription immediately.

---

## Workflow

### Step 1: Check Whisper installation
**Type**: script

```bash
command -v whisper >/dev/null 2>&1 && echo "WHISPER=cli" || \
(python3 -c "import whisper" 2>/dev/null && echo "WHISPER=python" || echo "WHISPER=none")
```

If not installed:
```bash
pip install openai-whisper
# or for faster inference:
pip install whisper-ctranslate2
```

### Step 2: Validate audio file
**Type**: script

```bash
file "$SOURCE"
ffprobe -v quiet -print_format json -show_format "$SOURCE" 2>/dev/null | python3 -c "import json,sys; d=json.load(sys.stdin); print(f'Duration: {float(d[\"format\"][\"duration\"]):.0f}s, Format: {d[\"format\"][\"format_name\"]}')"
```

Supported: mp3, wav, m4a, webm, mp4, ogg, flac
Warn if >60 minutes (will take a while).

### Step 3: Transcribe
**Type**: script

```bash
whisper "$SOURCE" --model medium --language "$LANGUAGE" --output_format txt --output_dir "$(dirname $SOURCE)" 2>&1
```

Model selection:
- Short audio (<5 min): `small` (fast)
- Normal audio: `medium` (balanced)
- High accuracy needed: `large-v3` (slow but accurate)

If language is not specified, Whisper auto-detects.

### Step 4: Post-process
**Type**: prompt

Read the raw transcript and:
1. Fix obvious recognition errors (common words, names)
2. Add paragraph breaks at natural pause points
3. Add speaker labels if multiple speakers detected (basic heuristic)
4. Add timestamps at major section breaks

### Step 5: Save and report
**Type**: generate

Save processed transcript to `{source_name}_transcript.md`:

```markdown
# Transcript: {filename}
Date: {date}
Duration: {duration}
Language: {language}

---

{processed transcript}
```

Report:
```
Transcription complete:
- Source: {filename} ({duration})
- Output: {output_path}
- Words: {word_count}
- Language: {detected_language}
```

---

## Edge Cases

**No Whisper**: Suggest installation. If macOS, also suggest `brew install ffmpeg` for format support.
**Very long audio (>2h)**: Process in chunks. Warn about processing time.
**Poor audio quality**: Warn that accuracy may be low. Suggest `large-v3` model.
**Video files**: Extract audio first with ffmpeg, then transcribe.

---

## Integration Points

- **meeting-notes**: Transcribe → then pass to meeting-notes for structuring.
- **deep-research**: Transcribe interviews or podcasts as research input.
- **memory-capture**: Extract key decisions from transcribed meetings.
