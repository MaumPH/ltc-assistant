---
name: workspace-bootstrap
description: This skill should be used when the user asks to "validate workspace", "check scaffold", "setup workspace", "workspace 점검", "scaffold 확인", "누락 파일 확인", or when the Setup:init hook triggers on first run. Also triggered by /setup-workspace command.
arguments:
  - name: fix
    description: If "true", automatically create missing files with seed content. If empty, report only.
    default: ""
tools:
  - Bash
  - Glob
  - Read
  - Write
---

# Workspace Bootstrap

> Validate the declaw workspace OS scaffold. Report missing pieces, offer to create them.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

This is an execution directive. First action: run Step 1 immediately.

---

## Workflow

### Step 1: Scan required structure
**Type**: script

Check for all required files and directories using Glob and Bash.

**Required directories:**
```
00-inbox/
00-system/01-templates/
00-system/02-contracts/
00-system/04-docs/
10-projects/          (or 10-backlog/ accepted)
20-operations/        (or 20-testing/ accepted)
30-knowledge/         (or 30-docs/ accepted)
40-personal/41-daily/
40-personal/42-weekly/
40-personal/46-todos/
50-resources/
90-archive/
memory/
memory/daily/
.claude/commands/
.claude/agents/
.claude/rules/
.claude/bootstrap/
.claude/skills/
sessions/
```

**Required files:**
```
CLAUDE.md
INDEX.md
.gitignore
.claude/CLAUDE.md
.claude/settings.json
```

**Required contracts (00-system/02-contracts/):**
```
IDENTITY.md
SOUL.md
USER.md
TOOLS.md
README.md
```

**Required rules (.claude/rules/):**
```
00-operating-system.md
10-identity.md
20-user-contract.md
30-project-map.md
40-tooling.md
50-memory-policy.md
60-flow-policy.md
```

**Required bootstrap (.claude/bootstrap/):**
```
BOOT.md
BOOTSTRAP.md
HEARTBEAT.md
```

**Required memory:**
```
memory/MEMORY.md
```

---

### Step 2: Check contract completeness
**Type**: prompt

Read each contract file in `00-system/02-contracts/` and check if it contains only placeholder text or has been filled in by the user.

Placeholder indicators:
- "Fill in:" still present
- Fewer than 3 substantive lines
- Only headings with no content underneath

Report which contracts are filled vs still placeholder.

---

### Step 3: Check settings.json hooks
**Type**: script

Read `.claude/settings.json` and verify hook events are configured:

Required hooks:
- `SessionStart`
- `Stop`
- `PreCompact`
- `Setup` (with "init" matcher)

Report which hooks are present vs missing.

---

### Step 4: Check commands, agents, skills
**Type**: script

Count files in each surface:
- `.claude/commands/*.md` — expect 10+
- `.claude/agents/*.md` — expect 4+
- `.claude/skills/*/SKILL.md` — expect 5+

List what exists in each directory.

---

### Step 5: Generate report
**Type**: generate

Produce a structured validation report:

```
Workspace Bootstrap Report
==========================

Structure:
  [PASS] directories: {N}/{total} present
  [PASS/FAIL] files: {N}/{total} present
  {list of missing items}

Contracts:
  [FILLED] IDENTITY.md
  [PLACEHOLDER] USER.md — needs: who uses this workspace
  ...

Hooks:
  [PASS] SessionStart configured
  [MISS] Stop — not configured
  ...

Surfaces:
  Commands: {N} files
  Agents: {N} files
  Skills: {N} files

Overall: {PASS / N issues found}
```

---

### Step 6: Auto-fix (conditional)
**Type**: generate

If `$ARGUMENTS` contains "fix" or "true":

1. Create missing directories with `.gitkeep`
2. Create missing files with minimal seed content:
   - Missing contracts: create with section headers and "Fill in:" prompts
   - Missing rules: create with single-line principle matching the filename
   - Missing bootstrap files: create with empty checklist template
   - Missing MEMORY.md: create with 4 section headers (Preferences, Decisions, Knowledge, Pitfalls)
3. Report what was created

If `$ARGUMENTS` is empty:
- Report only. End with: "Run `/setup-workspace fix` to auto-create missing items."

---

## Edge Cases

**Already complete workspace**: If everything passes, report "Workspace scaffold is complete" and suggest next steps (fill placeholder contracts, try /daily-note, etc.)

**Partial workspace (non-declaw repo)**: If CLAUDE.md exists but declaw structure is absent, warn that this appears to be a non-declaw workspace. Offer to scaffold declaw structure alongside existing files without overwriting.

**Read-only filesystem**: If auto-fix fails due to permissions, report the error and output the file contents so the user can create them manually.

---

## Integration Points

- **Setup:init hook**: When triggered by first run, this skill runs in report-only mode to show what needs attention.
- **/setup-workspace command**: Main operator entry point. Delegates to this skill.
- **/onboarding**: Calls this skill as part of the onboarding flow.
