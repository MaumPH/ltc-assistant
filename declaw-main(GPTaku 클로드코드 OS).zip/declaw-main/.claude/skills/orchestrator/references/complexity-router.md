# Complexity Router

> Criteria for classifying requests into Micro, Sprint, or Full Council.

---

## Tier Definitions

### Micro — Handle Directly

**Characteristics**: Single-step, single-file, low ambiguity, no trade-offs.

**Signals**:
- Request targets a specific file, function, or variable
- Answer can be found by reading one or two files
- No design trade-offs or alternative approaches to weigh
- Execution takes under 2 minutes

**Examples**:
- "What does this function return?"
- "Fix the typo on line 42"
- "Add a log statement here"
- "Read CLAUDE.md and summarize it"
- "Rename this variable to X"
- "What is the current directory structure?"

**Action**: Skill terminates. Main session handles directly.

---

### Sprint — 1-3 Agents

**Characteristics**: Focused task requiring multiple steps or perspectives, but bounded in scope.

**Signals**:
- Task involves reviewing, researching, or evaluating something specific
- Benefits from 2-3 viewpoints but does not require exhaustive coverage
- Scope is contained to one feature, module, or topic
- Execution takes 2-15 minutes

**Examples**:
- "Review this pull request" → reviewer + architect
- "Research how other projects handle auth" → researcher
- "Is this the right data model?" → architect + reviewer
- "Debug why this test is flailing" → architect + researcher
- "Evaluate these two library options" → researcher + architect
- "Check this code for security issues" → reviewer + researcher

**Typical agent combinations**:

| Task type | Recommended agents |
|-----------|--------------------|
| Code review | reviewer, architect |
| Research | researcher |
| Design review | architect, reviewer |
| Debugging | architect, researcher |
| Refactoring plan | architect, reviewer |

**Action**: Spawn 1-3 agents in parallel. Synthesize results.

---

### Full Council — 5+ Agents

**Characteristics**: Strategic, high-stakes, or multi-dimensional. Requires diverse perspectives to avoid blind spots.

**Signals**:
- Decision affects system architecture, project direction, or multiple teams
- Multiple valid approaches exist with significant trade-offs
- Risk of irreversible consequences if wrong
- Requires analysis from different angles (technical, operational, risk, etc.)
- Stakeholders would want multiple opinions before committing

**Examples**:
- "Should we rewrite this service in a different language?"
- "Evaluate our migration strategy"
- "What's the best approach for scaling this system?"
- "Assess the risk of open-sourcing this component"
- "Plan the next major version of our product"
- "How should we restructure the team's workflow?"

**Required perspectives** (at minimum):

| Perspective | Role | Purpose |
|-------------|------|---------|
| Analyst | architect or researcher | Objective data and facts |
| Advocate | architect | Best-case reasoning, opportunities |
| Critic | reviewer | Risks, failure modes, edge cases |
| Operator | operator | Practical execution feasibility |
| Domain expert | (varies) | Domain-specific knowledge |

**Action**: Spawn 5+ agents in parallel. Synthesize with weighted judgment.

---

## Edge Cases

| Situation | Resolution |
|-----------|------------|
| Unclear complexity | Default to Sprint. Escalate to Full if initial results reveal deeper complexity. |
| User explicitly requests council | Honor the request regardless of assessed complexity. |
| User explicitly says "just do it" | Treat as Micro. Skip orchestration. |
| Task starts Micro but grows | Re-assess mid-task. Escalate if needed. |
| Only 1 agent type is relevant | Sprint with 1 agent is valid. No need to artificially inflate. |
