---
name: orchestrator
description: This skill activates when the user's request involves multi-perspective analysis, architecture decisions, risk evaluation, strategic planning, complex debugging, quality review, or any task that benefits from multiple expert viewpoints. It routes to appropriate sub-agents based on task complexity.
disable-model-invocation: false
allowed-tools: Read Glob Agent
---

# Orchestrator

> Complexity-based routing to independent sub-agents with synthesis.

## Overview

This skill classifies incoming requests by complexity, spawns the appropriate set of independent agents, and synthesizes their outputs into a unified recommendation. Micro tasks are returned to the main session. Sprint and Full Council tasks are delegated to sub-agents.

---

## Workflow

### Step 0: Complexity Assessment
**Type**: prompt

1. Read `.claude/agents/AGENTS_INDEX.md` to load available agents and their capabilities.
2. Analyze the user's request against complexity criteria:
   - **Micro**: Single file read/edit, quick lookup, one-step fix, factual question. Examples: "fix this typo", "what does this function do", "rename this variable".
   - **Sprint**: Focused multi-step work involving 1-3 perspectives. Examples: "review this PR", "research how X works", "evaluate this design approach".
   - **Full Council**: Strategic decision requiring 5+ perspectives, trade-off analysis, or risk evaluation. Examples: "should we migrate to X", "evaluate our architecture", "assess the risk of this approach".
3. If **Micro** → skill terminates. Return control to the main session to handle directly.
4. If **Sprint** or **Full Council** → proceed to Step 1.

See `references/complexity-router.md` for detailed classification criteria.

### Step 1: Agent Selection
**Type**: prompt

1. Match the request against the `suitable_tasks` column in AGENTS_INDEX.md.
2. For **Sprint** (1-3 agents):
   - Select the most relevant agents for the specific task.
   - Typical patterns:
     - Code review → reviewer + architect
     - Research → researcher
     - Design review → architect + reviewer
     - Debugging → architect + researcher
3. For **Full Council** (5+ agents):
   - Always include at minimum: analyst perspective, advocate perspective, critic perspective.
   - Select agents whose `suitable_tasks` overlap with the request.
   - Add supplementary agents if the topic spans multiple domains.
4. Record selected agents and their assigned focus areas.

### Step 2: Parallel Execution
**Type**: prompt (Agent tool)

**All selected agents must be spawned in a single message. Sequential execution is prohibited.**

For each agent, construct a prompt containing:

```
[Role assignment from AGENTS_INDEX.md description]
+
[Task description derived from user's request]
+
[Independence protocol]
  - You are one of several independent agents analyzing the same question.
  - Judge independently. Do not defer to other perspectives.
  - Base conclusions on evidence, not assumptions.
  - If evidence is insufficient, say so explicitly.
  - Cite sources, file paths, or concrete reasoning for every claim.
  - Deliver your conclusion even if it may be uncomfortable.
+
[Output format]
  - State your conclusion clearly at the top.
  - Provide supporting evidence and reasoning.
  - Note risks, uncertainties, or gaps in your analysis.
  - Keep response focused and under 300 words.
```

Agent tool configuration:

| Parameter | Value |
|-----------|-------|
| description | "[Agent name] - [focus area for this task]" |
| model | Use the model specified in AGENTS_INDEX.md for that agent |
| prompt | Constructed prompt as above |

See `references/independence-protocol.md` for the full independence protocol.

### Step 3: Synthesis (Chairman Role)
**Type**: prompt

The orchestrator itself acts as Chairman to synthesize results:

1. **Collect**: Gather all agent responses. Note any agent failures.
2. **Summarize**: Extract each agent's core conclusion in one sentence.
3. **Find agreements**: Identify points where 2+ agents converge.
4. **Find conflicts**: Identify points where agents disagree. Note the evidence each side cites.
5. **Detect gaps**: Identify important aspects no agent addressed.
6. **Weight**: Give higher weight to conclusions backed by concrete evidence (file paths, data, specific reasoning) over general assertions.
7. **Decide**: Produce a unified recommendation.
   - If a decision is needed: **Go** / **Pivot** / **No-Go**
   - If analysis only: synthesized findings with confidence level

Decision criteria:

| Verdict | Condition |
|---------|-----------|
| **Go** | Majority agreement + risks identified and manageable |
| **Pivot** | Split opinions (near 50/50) or significant unknowns |
| **No-Go** | Majority warns against + concrete risk evidence |
| **More Info** | Critical data missing — cannot make informed judgment |

### Step 4: Dev-QA Loop (if implementation needed)
**Type**: prompt

Only execute this step if the synthesized recommendation leads to implementation work.

1. Route implementation to the most suitable agent (typically architect for design, or delegate to main session for code changes).
2. After implementation, route to reviewer agent for validation.
3. Reviewer returns **PASS** or **FAIL** with specific feedback.
4. If **FAIL**: feed reviewer feedback back to implementer. Retry up to 3 times.
5. If **PASS**: proceed to Step 5.
6. If 3 failures: escalate to user with failure details and reviewer feedback.

### Step 5: Delivery
**Type**: prompt

1. Present the synthesized result to the user in this structure:

```markdown
## Agent Perspectives

### [Agent 1 Name] ([focus])
[1-2 sentence summary of their conclusion]

### [Agent 2 Name] ([focus])
[1-2 sentence summary of their conclusion]

...

---

## Synthesis

**Agreements**: [what agents converge on]
**Conflicts**: [where they disagree and why]
**Gaps**: [what was not addressed]

---

## Recommendation: [Go / Pivot / No-Go / More Info]

**Confidence**: [High / Medium / Low] — [reason]
**Key reasoning**: [the decisive factor]
**Conditions**: [if any]

---

## Suggested next steps
1. [action item]
2. [action item]
```

2. If the result contains durable knowledge worth preserving, suggest the user capture it to memory.

---

## Core Principles

These rules are non-negotiable:

1. **Independence**: Each agent must judge independently. Do not show one agent's output to another. Do not prime agents with expected conclusions.
2. **Evidence over claims**: Agents must cite sources — file paths, data points, or concrete reasoning. Unsupported assertions receive zero weight in synthesis.
3. **No over-orchestration**: Never spawn agents for Micro-level tasks. A single file edit does not need a council.
4. **Graceful degradation**: If an agent fails or returns empty, proceed with remaining agents. Minimum 2 agent responses required for a valid synthesis. If fewer than 2 succeed, report the limitation and provide best-effort analysis.
5. **Transparency**: Always tell the user which agents were consulted, what they said, and how the synthesis was derived. No black-box decisions.

---

## References

- **`references/complexity-router.md`** — Detailed Micro/Sprint/Full classification criteria with examples
- **`references/independence-protocol.md`** — Agent independence protocol ensuring unbiased parallel judgment
