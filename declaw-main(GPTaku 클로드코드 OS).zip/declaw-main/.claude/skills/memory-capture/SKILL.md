---
name: memory-capture
description: This skill should be used when the user asks to "remember this", "save this to memory", "capture what we decided", "기억해줘", "메모리에 저장", "이거 기억해둬", or when PreCompact hook triggers a memory flush. Also use when /daily-review or /session-closeout needs to persist session context. For session-end workflows, use session-closeout instead.
arguments:
  - name: content
    description: Specific content to capture. If empty, scan the current session for decisions, preferences, and learnings.
    default: ""
tools:
  - Bash
  - Glob
  - Read
  - Write
  - Edit
---

# Memory Capture

> Capture session knowledge into the right memory lane. Durable knowledge goes to wiki pages. Continuity goes to daily handoffs.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

This is an execution directive, not a reference document.
First action: run Step 1 immediately. Do not ask what to capture — scan the session and propose.

---

## Workflow

### Step 1: Date and path setup
**Type**: script

Run the date command and verify lane directories exist.

```bash
echo "DATE=$(date +%Y-%m-%d)"
mkdir -p memory/daily
mkdir -p memory/wiki/{decisions,preferences,project-context,tool-patterns,pitfalls}
mkdir -p 40-personal/41-daily
```

Resolve today's date as `YYYY-MM-DD`. All file paths below use this date.

Lane file paths:
- Wiki index: `memory/MEMORY.md`
- Wiki pages: `memory/wiki/{category}/{slug}.md`
- Continuity: `memory/daily/{DATE}.md`
- Daily log: `40-personal/41-daily/{DATE}.md`

---

### Step 2: Read existing content
**Type**: script

1. Read `memory/MEMORY.md` — the wiki index. Note existing pages and their categories.
2. If `memory/daily/{DATE}.md` exists, read it. Note what was already captured today.
3. If `40-personal/41-daily/{DATE}.md` exists, read it.
4. Check `## Unsorted` section in MEMORY.md — if items exist from a previous PreCompact, they need to be promoted to wiki pages in this session.

If Unsorted items exist:
- For each item, determine the appropriate wiki category
- Include them in Step 3's scan results for processing

---

### Step 3: Scan session for capturable content
**Type**: prompt

If `$ARGUMENTS` is provided, use that as the content to capture.

If `$ARGUMENTS` is empty, scan the current conversation for:

1. **Decisions made** — architecture choices, technology picks, direction changes
2. **Preferences learned** — user style, workflow habits, tool preferences
3. **Stable knowledge** — facts that will remain true across sessions (project structure, team roles, recurring patterns)
4. **Work completed** — what was built, fixed, or changed
5. **Open items** — unfinished work, blockers, next steps
6. **Pitfalls discovered** — things that failed or should be avoided

Do NOT capture:
- Transient debugging output
- Sensitive information (API keys, passwords, tokens — warn and skip)
- Content already present in existing wiki pages or lane files (dedup)

---

### Step 4: Classify into lanes + wiki categories
**Type**: prompt

Classify each captured item using two levels:

**Level 1 — Lane selection:**

| Lane | Criterion | Examples |
|------|-----------|---------|
| **Wiki** (durable) | Will this still be true next week? Would a new session need this? | Architecture decisions, user preferences, recurring pitfalls, project conventions |
| **Continuity** (`memory/daily/{DATE}.md`) | Does the next session need this to pick up where we left off? | Work in progress, blockers, immediate next steps, today's context |
| **Daily log** (`40-personal/41-daily/{DATE}.md`) | Is this a human-readable record of today's work? | Tasks completed, key discussions, meeting notes, personal reflections |

When uncertain, default to **Continuity**. Only promote to Wiki when the knowledge is clearly stable and reusable.

**Level 2 — Wiki category (for Wiki lane items only):**

| Category | What belongs here | Decision hint |
|----------|-------------------|---------------|
| `decisions` | Architecture, technology, direction choices with rationale | "We chose X because Y" |
| `preferences` | User conventions, style, behavioral defaults | "Always do X", "I prefer Y" |
| `project-context` | Stable project facts: structure, goals, constraints | "This project is...", "The repo structure..." |
| `tool-patterns` | How specific tools are used, gotchas, config | "When using X, do Y" |
| `pitfalls` | Recurring mistakes, anti-patterns, things that broke | "Don't do X", "X failed because Y" |

**Slug determination:**
- Check MEMORY.md index for an existing page on the same topic
- If a related page exists → plan to Edit (update) that page
- If no match → generate a slug: lowercase, hyphen-separated, descriptive (e.g., `english-first-docs`)
- Grep `memory/wiki/` for the candidate slug to prevent duplicates across categories

---

### Step 5a: Compose wiki pages
**Type**: generate

For each Wiki-lane item:

**New page — create with template:**
```markdown
---
title: {Title}
category: {category}
created: {DATE}
updated: {DATE}
tags: [{tag1}, {tag2}]
status: active
---

# {Title}

## Summary
{One paragraph — this text feeds the index.}

## Detail
{Full content. Use sub-headings as needed.}

## Cross-references
- Related: [{related page title}](../{category}/{slug}.md)

## Changelog
- {DATE}: Initial creation
```

**Existing page — compose Edit:**
- Read the existing page
- Append new information to the Detail section
- Update `updated` date in frontmatter
- Append to Changelog
- Update Cross-references if new relationships found

**Frontmatter validation (required fields):**
Before writing, verify these 5 fields are present and non-empty: `title`, `category`, `created`, `updated`, `status`. If any is missing, fill it before Write.

### Step 5b: Compose index update
**Type**: generate

For each new or updated wiki page, compose the index row:

```
| [{slug}](wiki/{category}/{slug}.md) | {Summary first sentence} | {DATE} |
```

- New page → add row to the appropriate category table
- Updated page → update the Summary and Updated columns of the existing row
- Update the page count in the index header: `Pages: N`
- Extract Summary from the page's `## Summary` section — do not invent a separate summary

### Step 5c: Compose continuity and daily log
**Type**: generate

Same as before — no changes to these lanes.

**Continuity handoff format** (`memory/daily/{DATE}.md`):
```markdown
# {DATE} Continuity Note

## Done
- {completed item}

## In Progress
- {open item} — {current state}

## Next Session
- {what to do first}

## References
- {file paths or context needed}
```

**Daily log format** (`40-personal/41-daily/{DATE}.md`):
```markdown
# {DATE} Daily Note

## Focus
- {main focus of the day}

## Progress
- {what was accomplished}

## Decisions
- {key decisions made}

## Notes
- {observations, reflections}
```

If files already exist, merge: append new items, skip duplicates.

---

### Step 6: Write to files
**Type**: script

Execute writes in this order:

1. **Wiki pages** (new or updated):
   - New page → Write to `memory/wiki/{category}/{slug}.md`
   - Existing page → Edit with targeted changes
   - If Edit fails → Read → reconstruct → Write

2. **MEMORY.md index**:
   - Read current MEMORY.md
   - For new pages: insert row into the appropriate category table
   - For updated pages: update the existing row
   - Update page count in header
   - Clear any Unsorted items that were promoted to wiki pages
   - Write the updated MEMORY.md

3. **Continuity and Daily log**: same as before (Edit append or Write new)

Safety rules:
- Never overwrite existing wiki page content. Always append or merge.
- Before writing, verify the item is not already present (dedup by meaning, not exact string).
- If any write fails, output the content as plain text so the user can manually save it.
- Report partial success explicitly — "2/3 pages written, 1 failed: {reason}"

---

### Step 7: Report results
**Type**: prompt

After writing, report what was saved:

```
Memory captured:
- Wiki: {N} pages — {page names with categories}
  - New: {list of new pages}
  - Updated: {list of updated pages}
- Continuity (memory/daily/{DATE}.md): {summary}
- Daily log (40-personal/41-daily/{DATE}.md): {summary}
- Unsorted promoted: {N} items moved to wiki pages

{Any items skipped and why}
{Any write failures}
```

If nothing was worth capturing (empty session), report:
```
No significant changes to capture this session.
```

Do NOT output the full saved content. Just confirm what went where.

---

## Edge Cases

**Empty session**: If no meaningful work was done, skip all writes and report "nothing to capture." Do not create empty files.

**Sensitive information**: If content contains patterns matching API keys (`[A-Za-z0-9_-]{20,}`), passwords, or tokens, warn the user and exclude those items. Never silently store credentials.

**Multiple calls same day**: Append to existing files with a timestamp separator. Dedup by checking if the same decision/fact already exists in wiki pages.

**Missing directories**: Step 1 creates all required directories including wiki category subdirectories.

**Durable memory promotion uncertainty**: When unsure if something belongs in Wiki, keep it in Continuity only. The user or a future session can promote it later.

**Slug collision**: If the generated slug already exists in a different category, append the category prefix: `{category}-{slug}.md`.

---

## Integration Points

- **PreCompact hook**: When called from PreCompact, do NOT create wiki pages. Only append 1-line summaries to `## Unsorted` in MEMORY.md. Maximum efficiency — 1 Edit call. Next session will promote Unsorted items to proper wiki pages.
- **/daily-review**: When called from daily-review, include a more thorough scan. The review command handles the human-facing summary; this skill handles the memory writes.
- **/session-closeout**: When called from session-closeout, ensure wiki pages are up to date and Continuity handoff is complete.
- **Manual call**: When called directly by the user, respect `$ARGUMENTS` if provided. If not, propose what to capture and let the user confirm before writing.
