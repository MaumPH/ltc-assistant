---
name: github-workflow
description: This skill should be used when the user asks to "create PR", "open pr", "PR 만들어줘", "triage issues", "이슈 정리", "request review", "리뷰 요청", "check CI", "CI 상태", "release", "릴리스", or any GitHub PR/issue/review/CI automation request.
arguments:
  - name: action
    description: "pr-create", "pr-review", "issue-create", "issue-triage", "ci-check", "release". Default is "pr-create".
    default: "pr-create"
  - name: target
    description: PR number, issue number, or branch/tag name for the action.
    default: ""
tools:
  - Bash
  - Read
  - Write
---

# GitHub Workflow

> One entrypoint for PR, issue, review, CI, and release automation. gh CLI first, curl fallback.

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Detect auth, confirm target, run the action. Never push/merge/close without user approval.

## Workflow

### Step 1: Detect gh CLI and repo
```bash
command -v gh >/dev/null && gh auth status >/dev/null 2>&1 && AUTH=gh || AUTH=curl
OWNER_REPO=$(git remote get-url origin | sed -E 's|.*github\.com[:/]||; s|\.git$||')
```
If no `gh` and no `GITHUB_TOKEN`, guide install (`brew install gh && gh auth login`) — Credential Isolation: never ask for tokens in chat.

### Step 2: Confirm intent (Draft-Approve-Execute)
Summarize planned change (repo, target, irreversible steps) and await approval. Skip only for read-only actions (`ci-check`).

### Step 3: Execute action
- **pr-create**: `git push -u origin HEAD` → draft title+body from branch+commits → `gh pr create --title "$T" --body "$B" --base main`
- **pr-review**: `gh pr checkout $TARGET` → read diff → `gh pr review $TARGET --comment|--approve|--request-changes`
- **issue-create**: `gh issue create --title "$T" --body "$B" --label "$L"` using bug/feature template
- **issue-triage**: `gh issue list --label needs-triage --state open` → propose labels/assignees → apply after approval
- **ci-check**: `gh pr checks $TARGET` → on failure offer `gh run view <id> --log-failed`
- **release**: `git tag -a $TARGET -m ...` → `gh release create $TARGET --draft` (always draft first)

### Step 4: Report
```
GitHub action: {action}  Repo: {owner/repo}  Target: {id}
Result: {url or status}  Next: {reviewer / CI watch / manual publish}
```

## Safety Rules
- Draft-Approve-Execute for every write (PR, merge, close, release, force-push).
- Never auto-merge; never force-push to main/master.
- Credential Isolation: use `gh auth` / keychain, never echo tokens.
- One destructive action per turn.

## Edge Cases
- **No gh / no token**: guide install; do not attempt curl blindly.
- **PR conflicts**: report files, propose rebase, wait for approval.
- **CI failing 3+ runs same commit**: stop loop, ask user.
- **Triage ambiguity**: label `needs-human-review` rather than guess.
- **Uncommitted changes on release**: abort; require clean tree.
- **Protected branch rejection**: report rule violated, stop.

## Integration Points
- **ci-monitor**: shares CI reads; this skill triggers fixes.
- **session-closeout**: often ends with `pr-create`.
- **content-draft**: drafts PR bodies and release notes.
- **memory-capture**: promote merged decisions to durable memory.
- **deep-research**: research findings feed into issue-create.
