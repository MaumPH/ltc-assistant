---
name: email-automation
description: This skill should be used when the user asks to "check email", "이메일 정리", "메일 요약", "inbox cleanup", "draft a reply", "답장 초안", "classify mail", "inbox zero", "이메일 확인", or any email management request.
arguments:
  - name: action
    description: "summary", "classify", "draft", "inbox-zero". Default is "summary".
    default: "summary"
  - name: count
    description: Number of emails to process.
    default: "20"
tools:
  - Bash
  - Read
  - Write
---

# Email Automation

> Turn inbox review into a structured draft-first workflow. Never send mail without explicit user approval.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Check email CLI availability, then run the requested action.

---

## Workflow

### Step 1: Check email CLI
**Type**: script

```bash
command -v himalaya >/dev/null 2>&1 && echo "CLIENT=himalaya"
command -v gog >/dev/null 2>&1 && echo "CLIENT=gog"
command -v mail >/dev/null 2>&1 && echo "CLIENT=mail"
```

If no email CLI installed, guide setup:
```
No email CLI found. Install one:
- himalaya (recommended): cargo install himalaya
- gog (Google Workspace): pip install gog
- Or use bridge-placeholder skill to set up Google Workspace integration
```

Do not attempt to access email APIs directly. Use CLI wrappers that handle auth independently (Credential Isolation principle).

### Step 2: Fetch messages
**Type**: script

```bash
# himalaya
himalaya list --max-width 120 --page-size $COUNT

# gog
gog mail list --max $COUNT
```

Parse into structured working set: sender, subject, date, preview.

### Step 3: Execute action
**Type**: prompt

**Action: summary**
- Summarize each message in 1-2 sentences
- Estimate urgency: HIGH / MEDIUM / LOW
- Identify required action: reply / forward / schedule / archive / none

Output:
```
Email Summary ({N} messages):

HIGH:
  1. {sender}: {subject} — {summary}. Action: {reply/schedule/...}

MEDIUM:
  2. {sender}: {subject} — {summary}

LOW:
  3-N. {grouped by type}
```

**Action: classify**
Categorize each message:
| Category | Criteria |
|----------|----------|
| Action Required | Needs a reply or task |
| FYI | Informational only |
| Calendar | Event invite or scheduling |
| Finance | Invoice, receipt, payment |
| Newsletter | Subscriptions, digests |
| Skip | Spam, promotions, irrelevant |

**Action: draft**
For each action-required message:
- Generate a reply draft
- Match the tone of the original
- Keep concise
- **Present draft for approval — NEVER auto-send**

**Action: inbox-zero**
Full pipeline: classify → summarize → draft replies for action-required → propose archive/delete for rest.

### Step 4: Present results
**Type**: generate

Format all results and present. For drafts, always include:
```
Draft reply for: {subject}
---
{draft text}
---
Send this? (yes / edit / skip)
```

---

## Safety Rules

- **NEVER send email automatically.** All sends require explicit user approval (Draft-Approve-Execute).
- **NEVER expose email credentials** in Claude context. Use CLI tools that handle auth independently.
- **NEVER modify or delete emails** without user confirmation.

---

## Edge Cases

**No email CLI**: Guide installation. Suggest himalaya (Rust, fast) or gog (Python, Google-native).

**Auth expired**: If CLI returns auth errors, guide re-authentication without touching tokens directly.

**Large inbox (100+ unread)**: Process in batches of `$COUNT`. Report: "Processing first {count} of {total} messages."

**HTML-heavy emails**: Extract text content only. Note if important formatting was lost.

**Sensitive content**: Do not summarize emails marked confidential. Note: "1 confidential email skipped."

---

## Integration Points

- **morning-briefing**: Provides the email section of the morning briefing. morning-briefing calls this skill's "summary" action.
- **bridge-placeholder**: Email CLI setup guide lives in bridge-placeholder.
- **calendar**: Cross-reference meeting invites with calendar events.
- **memory-capture**: Important email decisions can be captured to durable memory.
