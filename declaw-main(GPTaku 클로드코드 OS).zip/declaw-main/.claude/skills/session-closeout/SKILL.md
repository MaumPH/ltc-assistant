---
name: session-closeout
description: This skill should be used when the user asks to "end session", "close session", "세션 종료", "세션 마무리", "wrap up", "closeout", or when the Stop hook suggests session cleanup. Focuses on next-session handoff rather than human-facing review.
arguments:
  - name: reason
    description: Why the session is ending (e.g. "done for today", "switching context", "rate limited"). Helps tailor the handoff.
    default: ""
tools:
  - Bash
  - Glob
  - Read
  - Write
  - Edit
---

# Session Closeout

> Close the current session cleanly with a focus on next-session continuity. Write handoff, flush memory, verify wiki integrity, flag risks.

Difference from `/daily-review`:
- `daily-review` = human-facing record of the day (reflective, thorough)
- `session-closeout` = agent-facing handoff for the next session (concise, actionable)

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

First action: run Step 1. Do not ask if the user wants to close — they already said so.

---

## Workflow

### Step 1: Assess session state
**Type**: prompt

Scan the current conversation and identify:

1. **Completed work** — what was finished this session
2. **Open work** — what was started but not finished (with current state)
3. **Unresolved risks** — things that could break, are fragile, or need attention
4. **Decisions made** — choices that should persist
5. **Files changed** — key files that were created, modified, or deleted

### Step 2: Trigger memory-capture
**Type**: prompt

Invoke the memory-capture skill to handle durable and daily memory writes.

This ensures:
- Stable knowledge goes to wiki pages in `memory/wiki/`
- Wiki index `memory/MEMORY.md` is updated
- Daily handoff goes to `memory/daily/{TODAY}.md`
- Human daily log goes to `40-personal/41-daily/{TODAY}.md`
- Any Unsorted items from PreCompact are promoted to wiki pages

If memory-capture was already run this session, skip and note "memory already captured."

### Step 3: Verify handoff completeness
**Type**: review

Read `memory/daily/{TODAY}.md` after memory-capture and verify it contains:

- [ ] At least one "Done" item
- [ ] "In Progress" items with current state (not just names)
- [ ] "Next Session" with a concrete first action
- [ ] "References" with file paths the next session will need

If any section is missing or empty, fill it in based on Step 1's scan.

### Step 4: Check for dangling state
**Type**: prompt

Look for:
- Uncommitted git changes (run `git status` if in a git repo)
- Temporary files that should be cleaned up
- Background processes that should be noted
- Todos that were discussed but not captured in `40-personal/46-todos/active-todos.md`

Report any dangling state found.

### Step 5: Wiki index lint
**Type**: script + review

Verify wiki index integrity:

1. **Glob** `memory/wiki/**/*.md` → collect all wiki page file paths
2. **Read** `memory/MEMORY.md` → extract all page links from index tables
3. **Compare**:
   - **Orphan pages** (file exists, not in index) → report with frontmatter summary
   - **Ghost entries** (index row exists, file missing) → report with `[MISSING]` tag
   - **Page count mismatch** (header `Pages: N` vs actual file count) → auto-correct

4. **Actions**:
   - Page count mismatch → fix automatically (non-destructive)
   - Orphan pages → report to user: "Found N orphan wiki pages not in index. Add them?"
     - If user approves → read frontmatter, add index rows
     - If user declines → note in report and move on
   - Ghost entries → report to user: "Found N index entries with missing files. Remove them?"
     - If user approves → remove rows from index
     - If user declines → add `[MISSING]` tag to affected rows

5. **Skip conditions**: If no wiki pages exist yet (`memory/wiki/` is empty), skip this step entirely.

### Step 6: Final report
**Type**: prompt

```
Session closeout complete.

Completed: {N} items
Open: {N} items carried forward
Risks: {N} flagged
Memory: {captured / already done}
  - Wiki pages: {N} new, {N} updated
  - Unsorted promoted: {N}
Handoff: memory/daily/{TODAY}.md {ready / updated}
Wiki integrity: {clean / N issues found}

{If dangling state exists:}
Note: {uncommitted changes / temp files / uncaptured todos}

Next session should start with:
→ {single most important action}
```

---

## Edge Cases

**Very short session (< 5 minutes)**: If almost nothing happened, write a minimal handoff: "Brief session. No significant changes." Skip wiki lint and daily log update.

**Multiple closeouts same day**: If a handoff already exists for today, append a new section with timestamp rather than overwriting.

**Session ending due to error/rate limit**: If `$ARGUMENTS` indicates "rate limited" or "error", prioritize saving context quickly. Skip wiki lint, focus on preserving work state via Unsorted section.

**No open work**: If everything was completed, handoff should say "All tasks completed. No carry-forward." and suggest what could be done next session.

**No wiki pages exist**: Skip Step 5 entirely. Wiki lint is only useful after the first wiki page has been created.

---

## Integration Points

- **Stop hook**: The Stop hook suggests running this skill. The user decides whether to accept.
- **/daily-review command**: A more thorough, human-facing version. Can run session-closeout as a sub-step.
- **memory-capture skill**: Called from Step 2 to handle actual memory writes.
- **daily-sync skill**: Handles the daily file creation/update mechanics.
