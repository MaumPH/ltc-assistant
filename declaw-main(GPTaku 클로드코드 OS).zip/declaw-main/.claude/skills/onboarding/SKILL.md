---
name: onboarding
description: This skill should be used when the user asks to "set up declaw", "get started", "처음 설정", "declaw 셋업", "온보딩 시작", "initialize workspace", or wants to start using declaw for the first time. For scaffold validation only, use workspace-bootstrap instead.
arguments:
  - name: step
    description: Start from a specific onboarding step
    default: ""
tools:
  - Bash
  - Read
  - Write
  - Glob
  - WebFetch
---

# Onboarding

> Guide the user through declaw setup as a workspace operating system.

## Goal

The purpose of onboarding is not just account connection.

It should help the user:
1. understand the workspace OS structure
2. fill in the contract documents
3. learn the operator surface
4. choose optional capability packs

## State

Track progress in `~/.declaw/onboarding-state.json`.

## Steps

### Step 1: Environment check

Verify:

```bash
claude --version
python3 --version
node --version
which icalBuddy || true
which whisper || true
```

Classify results into:
- required
- optional

### Step 2: Workspace OS tour

Read and explain:
- `README.md`
- `INDEX.md`
- `00-system/02-contracts/README.md`
- `00-system/04-docs/OPERATING_MODEL.md`
- `00-system/04-docs/MEMORY_LANES.md`

### Step 3: Contract setup

Help the user fill:
- `IDENTITY.md`
- `SOUL.md`
- `USER.md`
- `TOOLS.md`

### Step 4: Operator surface setup

Introduce:
- `/onboarding`
- `/setup-workspace`
- `/daily-note`
- `/daily-review`
- `/todo`
- `/todos`
- `/idea`
- `/thinking-partner`
- `/sync`

### Step 5: Memory lanes

Explain the three lanes:
- `memory/MEMORY.md`
- `memory/daily/`
- `40-personal/41-daily/`

Then help the user create their first:
- daily note
- continuity note

### Step 6: Optional capability packs

Introduce available packs:
- Assistant Pack
- Research Pack
- Bridge Pack

### Step 7: Optional integrations

Only after the core is understood, help the user set up optional integrations:
- Google Workspace
- MCP-backed services
- wrapper-based bridges

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Start with Step 1 immediately. Guide the user through each step conversationally.

---

## Completion criteria

Onboarding is complete when:
- the user understands the workspace structure
- the contract files are minimally filled
- the operator surface is understood
- the user has used the memory lanes once
- optional packs are intentionally chosen

---

## Edge Cases

**Already onboarded**: If contracts are filled and scaffold is valid, skip to Step 6 (pack selection). Report: "Core setup looks complete. Let's pick your packs."

**Partial onboarding**: If `$ARGUMENTS` specifies a step number, resume from that step.

**Non-declaw workspace**: If CLAUDE.md exists but declaw structure is absent, offer to add declaw scaffold without overwriting existing files.

**User wants to skip**: Allow skipping any step. Track which steps were skipped and remind at the end.

---

## Integration Points

- **workspace-bootstrap**: Called during onboarding to validate scaffold integrity.
- **/setup-workspace command**: Alternative entry point that delegates to this skill.
- **bridge-placeholder**: Step 7 (optional integrations) references bridge-placeholder for external service setup.
- **memory-capture**: Step 5 (memory lanes) demonstrates memory-capture as a live example.
