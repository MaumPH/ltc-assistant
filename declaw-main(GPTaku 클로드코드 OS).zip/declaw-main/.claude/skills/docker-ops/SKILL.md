---
name: docker-ops
description: This skill should be used when the user asks to "check containers", "docker status", "도커 확인", "컨테이너 상태", "docker compose up", "restart container", "container logs", "도커 로그", or any Docker container management request.
arguments:
  - name: action
    description: "status", "logs", "restart", "up", "down", "build", "prune". Default is "status".
    default: "status"
  - name: target
    description: Container name, service name, or compose file path.
    default: ""
tools:
  - Bash
  - Read
---

# Docker Ops

> Manage Docker containers and Compose stacks through natural language. Status checks, log viewing, lifecycle management.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

---

## Workflow

### Step 1: Check Docker availability
**Type**: script

```bash
command -v docker >/dev/null 2>&1 && docker info --format '{{.ServerVersion}}' 2>/dev/null || echo "DOCKER=unavailable"
command -v docker-compose >/dev/null 2>&1 || command -v "docker compose" >/dev/null 2>&1 && echo "COMPOSE=yes" || echo "COMPOSE=no"
```

If Docker is not running, report and suggest: `open -a Docker` (macOS) or `sudo systemctl start docker` (Linux).

### Step 2: Execute action
**Type**: script

**Action: status** — Overview of all containers
```bash
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Image}}" 2>/dev/null
echo "---"
docker ps -a --filter "status=exited" --format "{{.Names}}: exited {{.Status}}" 2>/dev/null
```

**Action: logs** — View container logs
```bash
docker logs --tail 50 "$TARGET" 2>&1
```
If `$TARGET` is empty, show running containers and ask which one.

**Action: restart** — Restart a container
```bash
docker restart "$TARGET" && echo "Restarted: $TARGET"
```

**Action: up** — Start Compose stack
```bash
docker compose up -d 2>&1 || docker-compose up -d 2>&1
```

**Action: down** — Stop Compose stack
```bash
docker compose down 2>&1 || docker-compose down 2>&1
```

**Action: build** — Build/rebuild
```bash
docker compose build --no-cache 2>&1
```

**Action: prune** — Clean unused resources
```bash
echo "This will remove unused containers, networks, and dangling images."
docker system prune -f 2>&1
```
Note: prune is destructive. Confirm with user first (Draft-Approve-Execute).

### Step 3: Report
**Type**: prompt

Format output cleanly:
```
Docker Status:
  Running: {N} containers
  Stopped: {N} containers
  
  {container list with status and ports}
  
  {any warnings: unhealthy, restarting, OOM}
```

For logs: highlight errors/warnings in the output.

---

## Edge Cases

**Docker not installed**: Guide installation for the user's platform.
**Docker daemon not running**: Suggest starting it.
**Permission denied**: Suggest adding user to docker group or using sudo.
**Prune confirmation**: Always ask before pruning. Show what will be removed.

---

## Integration Points

- **ci-monitor**: Docker status as part of CI/CD health checks.
- **/daily-review**: Include container health in daily review.
- **Scheduled Tasks**: `/loop 5m docker status check` for monitoring.
