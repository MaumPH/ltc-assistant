---
name: agent-builder
description: This skill should be used when the user asks to "create agent", "build agent", "new agent", "add agent", "에이전트 만들어줘", "에이전트 추가해줘", "서브에이전트 추가", or when the orchestrator detects no suitable agent exists for a task.
arguments:
  - name: idea
    description: Agent concept or role description.
    default: ""
tools:
  - Read
  - Write
  - Edit
  - Glob
  - Bash
  - Agent
---

# Agent Builder

> Build specialized sub-agents for the declaw workspace OS through expert discussion. Creates production-ready `.claude/agents/*.md` files and auto-registers them in AGENTS_INDEX.md.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

**This document is an execution directive, not a reference.**
- First action: call AskUserQuestion immediately
- All questions must use AskUserQuestion tool calls only
- Never output questions as plain text

---

## Workflow

### Phase A: Idea Collection

**Goal:** Understand what kind of agent the user wants.

If the user already described the agent (e.g. "데이터 분석가 에이전트 만들어줘"), extract:
- Agent purpose
- Domain expertise
- Expected tasks

If unclear, ask:

```json
{
  "questions": [
    {
      "question": "What kind of agent do you want to create?",
      "header": "Agent idea",
      "options": [
        {"label": "Domain analyst (example)", "description": "Analyzes data, trends, or metrics in a specific domain."},
        {"label": "Quality reviewer (example)", "description": "Reviews outputs for quality, risks, and regressions."},
        {"label": "Strategy advisor (example)", "description": "Provides strategic perspectives and recommendations."}
      ],
      "multiSelect": false
    }
  ]
}
```

### Phase B: Duplicate Check

Before expert discussion, check for existing agents with similar roles.

1. Read `AGENTS_INDEX.md` (if exists) from `.claude/agents/AGENTS_INDEX.md`
2. Run `Glob .claude/agents/*.md` to list existing agents
3. Read each agent's frontmatter (first 5 lines) to get name and description
4. Compare the new agent's purpose against existing descriptions

If a similar agent exists:
```
"Similar agent already exists: {name} — {description}
 Options:
 A. Create anyway (different specialization)
 B. Modify existing agent instead
 C. Cancel"
```

If no conflict, proceed to Phase C.

### Phase C: Expert Discussion

**Goal:** 4 expert agents analyze the idea in parallel.

Announce:
```
Building your agent with 4 experts. One moment...

Assembling: Planner / User / Specialist / Inspector
```

**Spawn 4 agents simultaneously (one message, all at once):**

| Expert | model | Focus |
|--------|-------|-------|
| Planner | sonnet | Role scope, mission clarity, when to use vs not use |
| User | sonnet | How would I invoke this? What output do I expect? |
| Specialist | sonnet | Technical: model choice, tools needed, maxTurns, isolation |
| Inspector | sonnet | Edge cases, overlap with existing agents, failure modes |

Each expert prompt must include:
- The agent idea + domain
- List of existing agents (from Phase B)
- Reference structure from `.claude/agents/` format
- Required output: structured analysis with one-line summary

### Phase D: Synthesize + Confirm

Combine 4 expert outputs into a design proposal:

```
Experts have finished. Here's the proposed agent:

Name: {name}
Role: {one-line description}
Model: {sonnet/opus/haiku}
Tools: {tool list}
Best for: {task types}
Not for: {what to avoid}

Proceed with this design?
```

Ask user confirmation via AskUserQuestion.

### Phase E: Generate Agent File

Create `.claude/agents/{name}.md` with full persona (80-150 lines).

**File structure (mandatory sections):**

```markdown
---
name: {name}
description: {one-line — MUST be specific enough for orchestrator auto-selection}
model: {sonnet|opus|haiku}
tools: {comma-separated tool list}
maxTurns: {10-30}
color: {blue|green|red|yellow|cyan|magenta}
---

# {Name} Agent

## Identity
- **Role**: {specific role definition}
- **Personality**: {personality traits}
- **Expertise**: {domain knowledge}

## Core Mission
{3-5 bullet points describing what this agent does}

## Critical Rules
{5-8 rules the agent must follow}
- Never {forbidden action 1}
- Always {required action 1}
- {domain-specific constraints}

## Workflow
### Step 1: {phase name}
{what to do, what to look for}

### Step 2: {phase name}
{next step}

### Step 3: {phase name}
{final step}

## Deliverables
{what the agent returns — format, structure, content}

## Communication Style
- **Tone**: {tone description}
- **Format**: {output format preferences}
- **Example**: "{sample output line}"

## Success Metrics
- {metric 1}
- {metric 2}
```

**Input validation before writing:**
- name: lowercase, hyphens only, no path separators, no special chars
- name must not match existing `.claude/agents/*.md` filenames
- description: minimum 10 words, must include purpose + domain
- tools: validated against allowed Claude Code tools list

**Allowed tools whitelist:**
Read, Write, Edit, Glob, Grep, Bash, Agent, WebFetch, WebSearch, NotebookEdit

### Phase F: Register in AGENTS_INDEX.md

After file creation, update `.claude/agents/AGENTS_INDEX.md`.

**Index format:**

```markdown
# Agents Index

This index is read by the orchestrator to select appropriate agents.

| name | file | model | description | suitable_tasks |
|------|------|-------|-------------|----------------|
| architect | architect.md | sonnet | Structure, decomposition, system judgment | design decisions, task breakdown |
| reviewer | reviewer.md | sonnet | Risks, regressions, verification | code review, quality gates |
| {new} | {new}.md | {model} | {description} | {tasks} |
```

**Registration steps:**
1. Read existing AGENTS_INDEX.md
2. Verify new agent name is not already in the index
3. Append new row to the table using Edit tool
4. If AGENTS_INDEX.md doesn't exist, create it with header + all existing agents + new agent

**Rollback on failure:**
- If index update fails after file creation → warn user: "Agent file created but index registration failed. Run `/setup-workspace` to sync."
- Never silently leave an orphaned agent file

### Phase G: Completion

Output:
```
Agent created successfully!

File: .claude/agents/{name}.md
Index: AGENTS_INDEX.md updated
Model: {model}
Tools: {tools}

How to use:
- The orchestrator will auto-select this agent when appropriate
- Or mention it directly: "@{name} analyze this data"
- To modify: "이 에이전트 수정해줘" or edit .claude/agents/{name}.md

Want to test it now?
```

If user wants to test, spawn the new agent with a sample task.

---

## Agent Modification Mode

When the user says "에이전트 수정해줘", "modify agent", "update agent {name}":

1. Read the existing agent file
2. Ask what to change (AskUserQuestion)
3. Apply changes with Edit tool
4. Update AGENTS_INDEX.md if description changed
5. Confirm changes

---

## References

- `references/agent-template.md` — Full agent file template
- `references/tools-whitelist.md` — Allowed tools for agents

---

## Settings

| Setting | Default | Notes |
|---------|---------|-------|
| Target directory | `.claude/agents/` | Agent files location |
| Index file | `.claude/agents/AGENTS_INDEX.md` | Orchestrator catalog |
| Persona depth | 80-150 lines | Agency-agents reference level |
| Name format | lowercase-hyphen | No spaces, no special chars |
