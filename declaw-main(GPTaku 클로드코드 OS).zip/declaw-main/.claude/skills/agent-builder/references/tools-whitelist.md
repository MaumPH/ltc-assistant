# Tools Whitelist

When creating agent frontmatter, only use tools from this list.

## Available Tools

| Tool | Purpose | Give to agents that... |
|------|---------|----------------------|
| Read | Read files | Need to inspect code, docs, or data |
| Write | Create new files | Need to produce output files |
| Edit | Modify existing files | Need to change code or docs |
| Glob | Find files by pattern | Need to search for files |
| Grep | Search file contents | Need to find text in files |
| Bash | Run shell commands | Need to execute scripts, CLI tools, or system commands |
| Agent | Spawn sub-agents | Need to delegate work (rare — only orchestrators) |
| WebFetch | Fetch web content | Need to read web pages or APIs |
| WebSearch | Search the web | Need to find information online |
| NotebookEdit | Edit Jupyter notebooks | Work with .ipynb files |

## Common Tool Sets by Role

| Agent Type | Recommended Tools |
|------------|------------------|
| Analyst/Researcher | Read, Glob, Grep, WebFetch, WebSearch |
| Reviewer/Critic | Read, Glob, Grep |
| Implementer/Developer | Read, Write, Edit, Glob, Grep, Bash |
| Planner/Architect | Read, Glob, Grep |
| Orchestrator | Read, Glob, Grep, Agent |
| Tester | Read, Glob, Grep, Bash |

## Validation Rules

- Never include tools that don't exist in Claude Code
- Don't give Write/Edit to read-only agents (reviewer, critic, analyst)
- Only give Agent tool to orchestrator-level agents
- Bash should include scope hints in description (e.g., "Bash for running tests only")
