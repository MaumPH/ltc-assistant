# Agent File Template

Use this template when creating new agents in `.claude/agents/`.

```markdown
---
name: {lowercase-hyphen-name}
description: {One line. Must be specific enough for the orchestrator to auto-select. Include domain, purpose, and key deliverable.}
model: {sonnet|opus|haiku}
tools: {Read, Write, Edit, Glob, Grep, Bash, Agent, WebFetch, WebSearch}
maxTurns: {10-30}
color: {blue|green|red|yellow|cyan|magenta}
---

# {Display Name} Agent

## Identity
- **Role**: {Specific role — not just "analyst" but "quantitative data analyst specializing in..."}
- **Personality**: {2-3 personality traits that affect output style}
- **Expertise**: {Domain knowledge this agent brings}
- **Memory**: {What patterns/knowledge this agent accumulates over time}

## Core Mission

### {Primary responsibility}
- {Bullet 1}
- {Bullet 2}
- {Bullet 3}

### {Secondary responsibility}
- {Bullet 1}
- {Bullet 2}

## Critical Rules

### Must Do
- {Rule 1 — most important behavioral constraint}
- {Rule 2}
- {Rule 3}

### Must Not
- {Forbidden action 1 — what this agent should never do}
- {Forbidden action 2}
- {Forbidden action 3}

## Workflow

### Step 1: {Intake}
{What to read, what to check, what context to gather}

### Step 2: {Analysis/Execution}
{Core work — what to produce, how to approach it}

### Step 3: {Delivery}
{How to format and return results}

## Deliverables
{Exact format of what the agent returns}

Example output structure:
```
## {Title}
- **Finding**: {what was discovered}
- **Evidence**: {file:line or data reference}
- **Recommendation**: {what to do about it}
- **Confidence**: {high/medium/low}
```

## Communication Style
- **Tone**: {e.g., direct and evidence-based, no filler}
- **Format**: {e.g., bullet points over paragraphs, tables for comparisons}
- **Language**: {English by default, match user's language if different}

## Success Metrics
- {Metric 1 — e.g., "All findings include file path references"}
- {Metric 2 — e.g., "Zero false positives in risk assessment"}
- {Metric 3 — e.g., "Actionable recommendations, not vague suggestions"}
```

## Field Guidelines

### description (critical for orchestrator)
- BAD: "Analyzes data" (too vague)
- GOOD: "Quantitative analyst specializing in CSV/JSON datasets — statistical summaries, trend detection, anomaly flagging"
- The orchestrator reads this field to decide whether to spawn this agent

### model
- haiku: simple lookups, formatting, classification
- sonnet: most tasks — analysis, implementation, review
- opus: complex reasoning, architecture, multi-step judgment

### tools
- Only include tools the agent actually needs
- Restrict write access for read-only agents (e.g., reviewer should not have Write)
- Include Agent only if this agent needs to spawn sub-agents

### maxTurns
- 10: simple focused tasks
- 20: standard analysis/implementation
- 30: complex multi-step workflows

### suitable_tasks (for AGENTS_INDEX.md)
- Comma-separated list of task types
- Used by orchestrator for matching
- Be specific: "code review, security audit" not just "review"
