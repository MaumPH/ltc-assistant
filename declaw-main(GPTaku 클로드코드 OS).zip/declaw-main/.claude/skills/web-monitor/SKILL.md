---
name: web-monitor
description: This skill should be used when the user asks to "watch this site", "monitor changes", "사이트 감시", "변경 감지", "페이지 변경 확인", "check if page changed", "웹 모니터링", or any web page monitoring request.
arguments:
  - name: url
    description: Target page URL.
    default: ""
  - name: keywords
    description: Optional comma-separated focus keywords to filter changes.
    default: ""
  - name: action
    description: "check" (compare to snapshot), "watch" (add to list), "list" (show targets), "remove" (delete target). Default is "check".
    default: "check"
tools:
  - WebFetch
  - Bash
  - Read
  - Write
---

# Web Monitor

> Monitor important web pages and summarize meaningful changes. Append-only snapshots, token-light comparison.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Determine action from `$ARGUMENTS` and execute.

---

## Workflow

### Step 1: Load watch state
**Type**: script

State file: `~/.declaw/web-monitor/watchlist.json`

```bash
mkdir -p ~/.declaw/web-monitor/snapshots
cat ~/.declaw/web-monitor/watchlist.json 2>/dev/null || echo '{"targets": []}'
```

If state directory doesn't exist, create it.

### Step 2: Execute action
**Type**: script + prompt

**Action: watch** — Register a new target
1. Validate URL (must start with http/https)
2. Fetch current page content via WebFetch
3. Save initial snapshot to `~/.declaw/web-monitor/snapshots/{domain}-{hash}.md`
4. Add target to watchlist.json: `{url, keywords, added_date, last_checked}`
5. Confirm: "Now watching: {url}"

**Action: check** — Compare current vs last snapshot
1. Fetch current page via WebFetch
2. Read last snapshot from `~/.declaw/web-monitor/snapshots/`
3. Diff the two: identify added, removed, and changed content
4. If keywords specified, filter changes to only those containing keywords
5. Save current as new snapshot (append-only — keep previous)
6. Summarize meaningful changes

Output:
```
Web Monitor: {url}
Last checked: {date}
Changes detected: {yes/no}

{If changes:}
Summary:
- {added/changed/removed items}

{If keywords matched:}
Keyword matches: {keyword}: {context}
```

**Action: list** — Show all watched targets
```
Watched Sites:
1. {url} — last checked {date} — keywords: {keywords}
2. {url} — last checked {date}
```

**Action: remove** — Remove a target
1. Remove from watchlist.json
2. Optionally delete snapshots
3. Confirm: "Removed: {url}"

### Step 3: Token-light strategy
**Type**: prompt

To stay token-efficient:
- Compare only the **latest 2 snapshots** (not full history)
- Extract **text content only** (strip HTML tags, scripts, styles)
- Limit snapshot size to **first 500 lines** of meaningful content
- Focus on structural changes (headings, lists, key paragraphs), not cosmetic changes

---

## Edge Cases

**URL not reachable**: Report fetch error. Retry once. If still failing, note "Site unreachable" and skip.

**No previous snapshot**: If checking a URL that was never watched, create initial snapshot and report "First snapshot taken. Check again later for changes."

**Very large pages**: Truncate to first 500 lines of text content. Note truncation.

**Dynamic/JS-heavy pages**: WebFetch may not capture JS-rendered content. Warn: "This page may use JavaScript rendering — changes in dynamic content may not be detected."

**Too many targets**: Warn if watchlist exceeds 20 targets. Suggest removing stale ones.

---

## Integration Points

- **morning-briefing**: Check all watched targets as part of the morning briefing.
- **Scheduled Tasks**: `/loop 1h check all watched pages` or Cloud Task for daily monitoring.
- **bridge-placeholder**: Forward change alerts to Channels (Discord/Telegram).
- **/inbox-processor**: Route significant web changes to inbox for triage.
