---
name: rss-feeds
description: This skill should be used when the user asks to "subscribe feed", "RSS 구독", "피드 추가", "check feeds", "새 글 확인", "블로그 모니터링", "list feeds", "unsubscribe", "feed reader", "피드 리더", or any RSS/Atom feed tracking request.
arguments:
  - name: action
    description: "subscribe", "list", "check", "remove". Default is "check".
    default: "check"
  - name: url
    description: Feed URL (subscribe) or feed name (remove).
    default: ""
  - name: store_dir
    description: Directory holding feeds.json and seen.json.
    default: "50-resources/feeds"
tools:
  - Bash
  - Read
  - Write
  - WebFetch
---

# RSS Feeds

> Lightweight feed tracking on the workspace filesystem. No daemon, no external service.

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Ensure `store_dir` exists, then run the action.

## Workflow

### Step 1: Ensure store
```bash
mkdir -p "$STORE_DIR"
[ -f "$STORE_DIR/feeds.json" ] || echo '{"feeds": []}' > "$STORE_DIR/feeds.json"
[ -f "$STORE_DIR/seen.json" ] || echo '{"seen": {}}' > "$STORE_DIR/seen.json"
```
`feeds.json` = subscriptions; `seen.json` = article IDs already reported.

### Step 2: Detect parser
Prefer `python3` + stdlib `xml.etree.ElementTree`. Fallback: `xmllint --xpath`. No pip installs.

### Step 3: Execute action
- **subscribe**: WebFetch URL → validate xml/rss/atom → extract `<title>` → append `{name,url,added}` to feeds.json.
- **list**: read feeds.json, print numbered list with names and URLs.
- **check**: for each feed: WebFetch → parse `<item>`/`<entry>` (title, link, pubDate, guid) → diff against seen.json → report new articles → update seen.json. Sleep 1s between feeds.
- **remove**: match by name or URL, remove from feeds.json, clean that feed's entries from seen.json.

### Step 4: Present results
```
Feed Scan ({N} feeds, {M} new)
  {feed}: {k} new
    - {title} ({date}) — {url}
```
For subscribe/remove: confirm with feed count.

## Safety Rules
- No auto-subscribe: confirm URL and resolved title before adding.
- seen.json is append-only during normal operation.
- Respect rate limits (1s between fetches).
- Credential Isolation: never store auth tokens in feeds.json for private feeds.

## Edge Cases
- **HTML URL, not feed**: try `/feed`, `/rss`, `/atom.xml`, or parse `<link rel="alternate" type="application/rss+xml">`.
- **Malformed XML**: log parse error, skip feed, continue.
- **404/410 feed**: mark `"status": "stale"` in feeds.json, prompt user to remove.
- **Duplicate subscribe**: report existing entry, do not re-add.
- **First check of new feed**: seed seen.json with all current IDs, display "Baseline set for {feed} ({N} marked seen)."
- **All feeds empty**: "All caught up — no new articles across {N} feeds."

## Integration Points
- **morning-briefing**: scheduled `check` feeds the daily "what's new" section.
- **deep-research**: new titles seed research topics.
- **content-draft**: flagged articles fuel blog/newsletter drafts.
- **memory-capture**: promote important article insights to durable memory.
- **web-monitor**: handles arbitrary URL diffs; rss-feeds is the structured path.
