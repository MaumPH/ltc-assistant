---
name: notion-sync
description: This skill should be used when the user asks to "notion sync", "노션에 저장", "notion page 만들어", "query notion", "노션 조회", "notion database", "노션 DB", "update notion", "노션 업데이트", or any Notion workspace CRUD request via the Notion API.
arguments:
  - name: action
    description: "query", "create", "update", "search". Default is "query".
    default: "query"
  - name: target
    description: Database ID, page ID, or search keyword.
    default: ""
tools:
  - Bash
  - Read
  - Write
---

# Notion Sync

> Curl-based Notion API client. Credential Isolation — never touches raw tokens in chat.

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Verify API key availability, then run the action.

## Workflow

### Step 1: Load API key
```bash
[ -z "$NOTION_API_KEY" ] && [ -f ~/.notion.env ] && source ~/.notion.env
[ -z "$NOTION_API_KEY" ] && echo "NOTION_API_KEY not set"
```
Precedence: env var → `~/.notion.env` (chmod 600) → keychain (`security find-generic-password -s notion-api -w`).
Setup guide when missing: create integration at notion.so/my-integrations → save key to `~/.notion.env` → share target pages/DBs with integration in Notion UI.
**Never echo the key in chat.**

### Step 2: Pin API version
```bash
NV="Notion-Version: 2025-09-03"  # databases = "data sources" in queries
```

### Step 3: Execute action
All calls use `-H "Authorization: Bearer $NOTION_API_KEY" -H "$NV" -H "Content-Type: application/json"`.
- **search**: `POST /v1/search -d '{"query":"..."}'`
- **query**: `POST /v1/data_sources/$TARGET/query -d '{"page_size":20,"filter":...}'`
- **create**: draft properties JSON → present for approval → `POST /v1/pages -d @/tmp/notion-payload.json`
- **update**: `PATCH /v1/pages/$TARGET -d '{"properties":{...}}'`

Pipe output through `python3 -m json.tool` or `jq` for readable results.

### Step 4: Present results
Reads: `{N} results` with title/status/url per row.
Writes: present draft payload, require explicit approval, then apply.

## Safety Rules
- Credential Isolation: load key from env/file/keychain only; never prompt user to paste it.
- Draft-Approve-Execute for create/update/archive.
- Notion archives, does not truly delete — confirm archive intent.
- Rate limit: ~3 req/s; sleep 0.4s between bulk calls.
- 404 on valid ID → integration likely not shared with page; report that.

## Edge Cases
- **401 invalid key**: guide re-auth, never log key value.
- **404 with valid ID**: prompt user to share the page/DB with integration via "..." menu → Connect to.
- **Property type mismatch**: read page schema first, adapt payload, report mismatch.
- **Archived page**: report `"archived": true`, do not treat as missing.
- **429 rate limited**: honor `Retry-After`, back off, retry once.
- **database_id vs data_source_id**: create uses database_id; query uses data_source_id. Resolve via `/v1/databases/{id}` if unknown.
- **UTF-8 titles**: Notion handles natively; do not escape emoji/CJK.

## Integration Points
- **content-draft**: push drafted content to a Notion DB as new page.
- **meeting-notes**: meeting summaries flow to a Notion meetings DB.
- **habit-tracker**: habit entries sync to tracker DB.
- **daily-sync**: cross-reference Notion tasks DB with workspace daily note.
- **obsidian-pkm**: notes live in Obsidian OR Notion — user picks sync direction.
- **memory-capture**: mirror key decisions to durable memory + Notion log.
