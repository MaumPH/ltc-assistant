---
name: calendar
description: This skill should be used when the user asks to "check my schedule", "add an event", "what's on my calendar", "일정 확인", "일정 추가", "오늘 뭐 있어", "이번주 일정", "free time", "가용 시간", "schedule a meeting", or any calendar-related query. Manages calendar events through CLI tools.
arguments:
  - name: action
    description: "view" (default), "add", "search", "week", "free"
    default: "view"
  - name: query
    description: Event details for add, or search terms for search.
    default: ""
tools:
  - Bash
  - Read
  - Write
---

# Calendar

> View, add, and search calendar events through CLI tools. Supports Google Calendar (gcalcli) and Apple Calendar (icalBuddy).

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Detect which calendar CLI is available, then run the requested action.

---

## Workflow

### Step 1: Detect calendar backend
**Type**: script

```bash
command -v gcalcli >/dev/null 2>&1 && echo "BACKEND=gcalcli"
command -v icalBuddy >/dev/null 2>&1 && echo "BACKEND=icalBuddy"
```

If neither is installed, guide installation:
- macOS: `brew install gcalcli` (Google) or `brew install ical-buddy` (Apple)
- Linux: `pip install gcalcli`

If both exist, prefer gcalcli (more features). Note the backend for subsequent steps.

### Step 2: Execute action
**Type**: script

**Action: view (default)** — Show today's agenda
```bash
# gcalcli
gcalcli agenda --nocolor $(date +%Y-%m-%d) $(date +%Y-%m-%d)T23:59

# icalBuddy
icalBuddy -f eventsToday
```

**Action: week** — Show this week's events
```bash
# gcalcli
gcalcli agenda --nocolor $(date +%Y-%m-%d) $(date -v+7d +%Y-%m-%d 2>/dev/null || date -d '+7 days' +%Y-%m-%d)

# icalBuddy
icalBuddy -f eventsToday+7
```

**Action: add** — Add a new event
```bash
# gcalcli — requires: title, date, time, duration
gcalcli add --title "$TITLE" --when "$WHEN" --duration "$DURATION" --noprompt

# icalBuddy — read-only, cannot add. Fall back to AppleScript:
osascript -e 'tell application "Calendar" to make new event ...'
```

**Action: search** — Find events matching a query
```bash
gcalcli search "$QUERY" --nocolor
```

**Action: free** — Show free/busy slots for a date range
```bash
gcalcli agenda --nocolor "$START" "$END" | grep -v "^$"
```
Then analyze gaps between events to identify free slots.

### Step 3: Format output
**Type**: prompt

Format the raw CLI output into a readable summary:

```
Today's Schedule (2026-04-04):
  09:00-10:00  Team standup
  14:00-15:00  Design review
  
Free slots: 10:00-14:00, 15:00-18:00
```

For add actions, confirm: "Event added: {title} on {date} at {time}"

### Step 4: Workspace integration
**Type**: prompt

If relevant, suggest workspace actions:
- "You have a meeting in 30 min — need to prepare?" → link to /thinking-partner
- "Today is packed — want to reschedule any todos?" → link to /todos

---

## Edge Cases

**No CLI installed**: Provide installation instructions. Do not attempt API calls without a CLI wrapper.

**Auth expired**: If gcalcli returns auth errors, guide: `gcalcli init` to re-authenticate. Never handle OAuth tokens directly.

**Add event validation**: Before adding, confirm with user: "Add '{title}' on {date} {time} for {duration}? (y/n)" — Draft-Approve-Execute.

**Multiple calendars**: gcalcli supports `--calendar` flag. If user has multiple, ask which one.

---

## Integration Points

- **morning-briefing**: Calls this skill's "view" action for the calendar section of the briefing. This skill provides the full calendar management; morning-briefing only reads.
- **/daily-note**: Can include today's schedule summary at the top of the daily note.
- **Scheduled Tasks**: "Check tomorrow's calendar at 9pm" → Cloud/Desktop Task with this skill.
