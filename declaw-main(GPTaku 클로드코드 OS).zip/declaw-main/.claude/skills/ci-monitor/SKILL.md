---
name: ci-monitor
description: This skill should be used when the user asks to "check CI", "build status", "CI 확인", "빌드 상태", "pipeline status", "GitHub Actions", "check workflow", "PR checks", "배포 상태", or any CI/CD monitoring request.
arguments:
  - name: action
    description: "status" (check recent runs), "watch" (monitor a specific run), "logs" (view run logs). Default is "status".
    default: "status"
  - name: target
    description: Run ID, PR number, branch name, or workflow name.
    default: ""
tools:
  - Bash
  - Read
---

# CI Monitor

> Monitor CI/CD pipelines — GitHub Actions, builds, deployments. Check status, view logs, watch runs.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

---

## Workflow

### Step 1: Detect CI system
**Type**: script

```bash
# Check if in a git repo
git rev-parse --is-inside-work-tree 2>/dev/null && echo "GIT=yes" || echo "GIT=no"

# Check gh CLI
command -v gh >/dev/null 2>&1 && echo "GH=yes" || echo "GH=no"

# Detect CI config
ls .github/workflows/*.yml 2>/dev/null && echo "CI=github-actions"
ls .gitlab-ci.yml 2>/dev/null && echo "CI=gitlab"
ls Jenkinsfile 2>/dev/null && echo "CI=jenkins"
ls .circleci/config.yml 2>/dev/null && echo "CI=circleci"
```

### Step 2: Execute action
**Type**: script

**Action: status** — Recent CI runs
```bash
# GitHub Actions
gh run list --limit 10 --json status,conclusion,name,headBranch,createdAt \
  --template '{{range .}}{{.name}} | {{.headBranch}} | {{.status}}/{{.conclusion}} | {{.createdAt}}{{"\n"}}{{end}}'
```

**Action: watch** — Watch a specific run
```bash
# By run ID
gh run watch "$TARGET" --exit-status

# By PR
gh pr checks "$TARGET"
```

**Action: logs** — View run logs
```bash
gh run view "$TARGET" --log-failed 2>/dev/null || gh run view "$TARGET" --log
```

### Step 3: Analyze and report
**Type**: prompt

Format output:
```
CI Status:
  ✅ build (main) — passed 2 min ago
  ✅ test (main) — passed 3 min ago
  ❌ deploy (feature/auth) — FAILED 10 min ago
      Error: npm test exit code 1
  🔄 lint (feature/auth) — running...

{If failures: extract error message and suggest fix}
```

For failed runs:
- Extract the error from logs
- Suggest likely cause
- Offer to fix if it's a code issue

### Step 4: Alert (optional)
**Type**: prompt

If monitoring via `/loop`:
- Report only if status changed from last check
- Highlight new failures
- Confirm when previously failed runs pass

---

## Edge Cases

**No gh CLI**: Guide installation: `brew install gh && gh auth login`
**Not a git repo**: Report "Not in a git repo. Navigate to a project first."
**No CI configured**: Report "No CI configuration found in this repo."
**Rate limited**: Report API rate limit and suggest waiting.
**Private repos**: Ensure gh is authenticated with proper scope.

---

## Integration Points

- **docker-ops**: Container health alongside CI status.
- **/daily-review**: Include CI status in daily review.
- **Scheduled Tasks**: `/loop 5m check CI status` or Cloud Task for daily CI health report.
- **bridge-placeholder**: Forward CI alerts to Channels (Discord/Telegram).
