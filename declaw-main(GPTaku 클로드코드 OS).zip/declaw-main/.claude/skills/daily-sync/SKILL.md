---
name: daily-sync
description: This skill should be used when the user asks to "sync today", "update daily", "오늘 정리", "daily sync", "일지 갱신", "daily 업데이트", or when /daily-note or /daily-review commands need to update memory lanes. Keeps continuity handoffs and daily logs current.
arguments:
  - name: mode
    description: "start" for session start (read yesterday, prepare today), "end" for session end (write today's summary). Default is "end".
    default: "end"
tools:
  - Bash
  - Glob
  - Read
  - Write
  - Edit
---

# Daily Sync

> Keep daily memory lanes synchronized. Read yesterday's handoff at session start, write today's summary at session end.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

First action: determine mode (start or end) and run the corresponding workflow.

---

## Mode: Start (beginning of session)

### Step 1: Get dates
**Type**: script

```bash
echo "TODAY=$(date +%Y-%m-%d)"
echo "YESTERDAY=$(date -v-1d +%Y-%m-%d 2>/dev/null || date -d 'yesterday' +%Y-%m-%d)"
```

### Step 2: Read yesterday's handoff
**Type**: script

Check if `memory/daily/{YESTERDAY}.md` exists. If yes, read it.

This file contains what the previous session left behind:
- What was done
- What was in progress
- What to do first today
- Reference files to check

### Step 3: Read today's existing notes
**Type**: script

Check if today's files already exist:
- `memory/daily/{TODAY}.md`
- `40-personal/41-daily/{TODAY}.md`

If they exist, read them to avoid overwriting.

### Step 4: Present session start context
**Type**: prompt

Summarize for the user:
```
Yesterday's handoff:
- {key items from yesterday's continuity note}

Today's existing notes:
- {if any already exist}

Suggested first actions:
- {carry-forward items from yesterday}
```

If no yesterday handoff exists, say: "No previous handoff found. Starting fresh."

---

## Mode: End (end of session)

### Step 1: Get today's date
**Type**: script

```bash
echo "TODAY=$(date +%Y-%m-%d)"
```

### Step 2: Read existing daily files
**Type**: script

Read both lane files if they exist:
- `memory/daily/{TODAY}.md` — agent continuity
- `40-personal/41-daily/{TODAY}.md` — human daily log

### Step 3: Scan session for daily content
**Type**: prompt

Scan the current conversation and extract:

**For continuity handoff** (`memory/daily/{TODAY}.md`):
- What was completed today
- What is still in progress (with current state)
- What the next session should start with
- Key file paths or references needed

**For daily log** (`40-personal/41-daily/{TODAY}.md`):
- Main focus of the day
- Progress summary
- Decisions made
- Open questions or blockers

Keep continuity notes **short and action-oriented** (agent audience).
Keep daily log **readable and reflective** (human audience).

### Step 4: Check for carry-forward items
**Type**: prompt

Look at yesterday's continuity note (if exists) and today's todos (`40-personal/46-todos/active-todos.md`).

Items marked "In Progress" yesterday that were not completed today should be carried forward with updated status.

### Step 5: Delegate writes to memory-capture
**Type**: prompt

Do NOT write to memory files directly. Instead, invoke the **memory-capture** skill with the extracted content from Steps 3-4.

memory-capture is the sole write engine for all 3 memory lanes. Pass it:
- Durable candidates (decisions, preferences)
- Continuity handoff items (done, in progress, next session, references)
- Daily log items (focus, progress, decisions, notes)

memory-capture will handle file creation, merging, and dedup.

Expected formats that memory-capture will produce:

**Continuity handoff** (`memory/daily/{TODAY}.md`):
```markdown
# {TODAY} Continuity Note

## Done
- {completed items}

## In Progress
- {item} — {current state}

## Next Session
- {what to start with}

## References
- {relevant file paths}
```

**Daily log** (`40-personal/41-daily/{TODAY}.md`):
```markdown
# {TODAY} Daily Note

## Focus
- {main focus}

## Progress
- {accomplishments}

## Decisions
- {key decisions}

## Notes
- {reflections, observations}
```

### Step 6: Report
```
Candidates for durable memory:
- {item} — promote to MEMORY.md? (will persist across all sessions)
```

Let the user decide, or defer to memory-capture skill.

### Step 7: Report
**Type**: prompt

```
Daily sync complete:
- Continuity: memory/daily/{TODAY}.md {created/updated}
- Daily log: 40-personal/41-daily/{TODAY}.md {created/updated}
- Carry-forward items: {N}
- Durable memory candidates: {N}
```

---

## Edge Cases

**No work done**: If the session had no meaningful work, create minimal continuity note with "No significant work this session" and skip daily log creation.

**Multiple syncs same day**: Append new content with timestamp separator. Do not duplicate existing items.

**Missing yesterday's handoff**: Proceed without carry-forward. Note "No previous handoff" in the report.

**Weekend/gap**: If yesterday's file doesn't exist, check the last 3 days for the most recent handoff.

---

## Integration Points

- **/daily-note command**: Creates the human daily log structure, then calls daily-sync in "end" mode for the continuity handoff.
- **/daily-review command**: Triggers daily-sync in "end" mode as part of the review workflow.
- **SessionStart hook**: Can trigger daily-sync in "start" mode to load yesterday's context.
- **memory-capture skill**: Handles durable memory writes. daily-sync proposes candidates but defers actual promotion.
