---
name: social-publish
description: This skill should be used when the user asks to "post tweet", "트윗 올려줘", "X에 올려", "publish thread", "스레드 발행", "social post", "SNS 발행", "schedule tweet", "포스팅 예약", or any social media publishing request.
arguments:
  - name: platform
    description: "x" (Twitter/X), "threads", "linkedin". Default is "x".
    default: "x"
  - name: content
    description: Post content or path to a content-draft file.
    default: ""
  - name: mode
    description: "single", "thread", "reply", "quote". Default is "single".
    default: "single"
tools:
  - Bash
  - Read
  - Write
---

# Social Publish

> Publish drafted content to social platforms. Draft-Approve-Execute is MANDATORY on every call.

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Verify CLI + credentials, validate char counts, present draft, WAIT for explicit approval, then post.

## Workflow

### Step 1: Verify platform CLI
```bash
case $PLATFORM in
  x) command -v x-cli >/dev/null || echo "install: uv tool install git+https://github.com/Infatoshi/x-cli.git" ;;
  threads|linkedin) echo "no stable free CLI — use manual publish flow" ;;
esac
```
If CLI missing, guide install and stop. Never raw-API with credentials in chat.

### Step 2: Enforce platform limits
| Platform | Single | Thread unit | Media |
|---|---|---|---|
| x | 280 (Basic) / 25k (Premium) | 280 | 4 img / 1 video |
| threads | 500 | 500 | 10 media |
| linkedin | 3000 | n/a | 9 img |
Auto-split long content into thread units; report split plan.

### Step 3: Validate content
If `content` is a file path, Read it. Validate char count per unit, flag obvious PII/spam, ≤1 link per tweet, ≤2 hashtags.

### Step 4: Present draft (MANDATORY)
```
Draft ({platform}, {mode}):
  [1/{N}] ({chars}/{limit})
  {body}
  [2/{N}] ...
Post this? (yes / edit / cancel)
```
**Never post without explicit "yes".** Silence/ambiguity = NOT approved.

### Step 5: Execute publish
- **x single**: `x-cli tweet post "$CONTENT"`
- **x thread**: `x-cli -j tweet post "$T1"` → capture id → loop `x-cli -j tweet reply $parent "$Ti"` with 2s sleep.
- **x quote/reply**: `x-cli tweet quote|reply $TARGET_ID "$CONTENT"`
- **threads/linkedin**: copy to clipboard + open browser composer. Do not scrape.

### Step 6: Report + audit
```
Published to {platform}: {url}
Thread: {N} posts  Root: {url}
```
Append record to `sessions/YYYY-MM-DD_social-publish.md` with timestamp + content snapshot.

## Safety Rules
- Draft-Approve-Execute is ABSOLUTE — explicit "yes" required every time.
- Credential Isolation: rely on x-cli's `~/.config/x-cli/.env`; never echo `X_*` tokens.
- No auto-schedule without approval; no auto-delete/auto-retweet of existing posts.
- No scraping for platforms without official CLI — manual publish only.
- Audit trail logged to `sessions/` for every post.

## Edge Cases
- **Content exceeds single limit**: propose thread split, show per-unit breakdown.
- **Draft file missing**: report path, ask user to re-run content-draft.
- **403 oauth1-permissions**: regenerate X access token after enabling Read+Write.
- **Rate limited**: honor cooldown, do not loop-retry; report wait time.
- **Reply target deleted**: abort thread, offer standalone post.
- **URL shortener**: do not shorten without consent.
- **Media path missing**: abort, report.
- **CJK char counting**: X counts each CJK char as 2; adjust split.

## Integration Points
- **content-draft**: primary upstream — pipeline `/content-draft → /social-publish`.
- **deep-research**: findings → content-draft → threads.
- **session-closeout**: logs recent posts in session summary.
- **memory-capture**: promote engaging post themes to durable memory.
- **habit-tracker**: track posting cadence if user has a publishing routine.
