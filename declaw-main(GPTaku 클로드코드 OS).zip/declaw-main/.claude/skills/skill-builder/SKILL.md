---
name: skill-builder
description: This skill should be used when the user asks to "make a skill", "create a skill", "build a skill", "create a command", "스킬 만들어줘", "커맨드 만들어줘", "이거 스킬로 만들어", "자동화해줘", or when repeated requests suggest a workflow should be turned into a reusable skill. For agent creation, use agent-builder instead.
arguments:
  - name: idea
    description: One-sentence description of the skill to create.
    default: ""
tools:
  - Read
  - Write
  - Edit
  - Glob
  - Bash
  - Agent
---

# Skill Builder

> Assemble 4 expert agents to analyze your idea, then generate a production-ready skill. No coding knowledge required.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

**This is an execution directive, not a reference.**
- First action: call AskUserQuestion immediately (Phase A)
- All questions must use AskUserQuestion tool calls only
- Never output questions as plain text

---

## Proactive Trigger

Beyond explicit requests, suggest skill creation when:
- The same or similar request appears 2+ times in conversation
- User uses words like "every time", "always", "automate", "repeatedly"
- A multi-step workflow is described that could be reused
- User says "make this reusable" or similar

Suggestion format:
```
This looks like a repeatable workflow. Want me to turn it into a skill?
Once created, you can run it with a single command next time.
```

If user agrees, extract the workflow from conversation context and start Phase A.

---

## Workflow

### Phase A: Idea Collection
**Type**: prompt

**Goal:** Understand the core idea for the skill.

**Context extraction:** If the conversation already contains a workflow (e.g. "turn this into a skill"), extract from history: tools used, step order, user corrections, input/output formats. Let the user fill gaps, confirm before proceeding.

If `$ARGUMENTS` provides an idea, use it directly. Otherwise:

**EXECUTE:** Call AskUserQuestion:

```json
{
  "questions": [
    {
      "question": "What kind of skill do you want to create? Describe in one sentence.",
      "header": "Idea",
      "options": [
        {"label": "Translation skill (example)", "description": "Translate documents into another language."},
        {"label": "Meeting notes (example)", "description": "Summarize meetings and extract action items."},
        {"label": "Code review (example)", "description": "Analyze code and find improvements."}
      ],
      "multiSelect": false
    }
  ]
}
```

If the idea is too vague, ask ONE clarifying question. If clear, proceed to Phase B.

---

### Phase B: Expert Team Discussion
**Type**: prompt + agent

**Goal:** 4 expert agents analyze the idea in parallel.

#### Step 1: Announce

```
Assembling 4 experts. One moment...

Experts: Planner / User / Specialist / Inspector
```

#### Step 2: Spawn 4 agents simultaneously

**Must use Agent tool to spawn all 4 in a single message (parallel, not sequential).**

| Expert | subagent_type | model | description |
|--------|---------------|-------|-------------|
| Planner | `general-purpose` | `sonnet` | "Planner perspective analysis" |
| User | `general-purpose` | `sonnet` | "User perspective analysis" |
| Specialist | `general-purpose` | `sonnet` | "Specialist perspective analysis" |
| Inspector | `general-purpose` | `sonnet` | "Inspector perspective analysis" |

Each agent prompt must include:
- The skill idea and any context from Phase A
- Their analysis focus (see `references/interview-guide.md` section 2-1 for templates)
- Required output: structured analysis with one-line summary

#### Step 3: Synthesize results

Collect all 4 responses and present in conversation format:

```
4 experts have finished! Here's the summary:

Planner: "{one-line summary}"
→ {key analysis 1-2 lines}

User: "{one-line summary}"
→ {key analysis 1-2 lines}

Specialist: "{one-line summary}"
→ {key analysis 1-2 lines}

Inspector: "{one-line summary}"
→ {key analysis 1-2 lines}

Overall: {integrated direction proposal 2-3 lines}
```

If experts disagree, show the conflict:
```
Experts disagree:
- Planner suggested "{A}" but User prefers "{B}".
- Which direction do you want?
```

#### Step 4: Confirm direction

**EXECUTE:** Call AskUserQuestion:

```json
{
  "questions": [
    {
      "question": "Based on the expert analysis, how should we proceed?",
      "header": "Direction",
      "options": [
        {"label": "Looks good, proceed (Recommended)", "description": "Design the workflow based on expert recommendations."},
        {"label": "I want to adjust", "description": "Tell me what to change."},
        {"label": "Discuss again", "description": "Give additional context and experts will re-analyze."}
      ],
      "multiSelect": false
    }
  ]
}
```

---

### Phase C: Detail Interview (1-2 questions max)
**Type**: prompt

**Goal:** Ask only about items the expert discussion couldn't resolve.

Auto-determined from discussion:
- `purpose` — Planner analyzed
- `input_type` / `output_type` — User analyzed
- `trigger_keywords` — Planner proposed
- `domain` — Specialist determined
- `constraints` — Inspector identified

Only ask about uncertain items. Maximum 2 additional questions via AskUserQuestion.

Skip this phase entirely if the discussion resolved everything.

**Question rules (all AskUserQuestion calls):**

| Rule | Description |
|------|-------------|
| AskUserQuestion required | Every question must use the tool, never plain text |
| Descriptions required | Every option must explain what it is + pros/cons |
| Recommended first | Mark best option with "(Recommended)" and place first |
| Plain language | Use everyday language, avoid technical jargon |
| One at a time | Ask 1 question per call |
| No "Other" needed | AskUserQuestion provides it automatically |

---

### Phase D: Workflow Design
**Type**: prompt

**Goal:** Design the skill workflow from discussion results + user answers.

**6 step types:**

| Type | When to use | Example |
|------|-------------|---------|
| `prompt` | Claude reasoning needed (analysis, summary, judgment, creation) | Text analysis, translation |
| `script` | Repeatability, consistency, API calls — Python/Bash | Data parsing, API requests |
| `api_mcp` | External tool integration (priority: API > MCP > direct) | Slack, Notion, GitHub |
| `rag` | Domain knowledge lookup from `references/` | Glossary, style guide |
| `review` | Quality gate (required after api_mcp/rag) | Accuracy check, user confirmation |
| `generate` | Final output (file creation, report) | Save results, present to user |

**Component type decision:**

| Type | Characteristics | When |
|------|----------------|------|
| Skill | Blends into conversation, single task | Default |
| Agent | Independent execution, own context, multi-step autonomous | Complex autonomous work |
| Command | User-triggered explicitly, argument-based branching | Clear entry point needed |

**Eval criteria definition:**

Define eval scenarios alongside the workflow. Use Inspector's analysis for edge cases.

Save as `evals.json`:
```json
{
  "skill_name": "{skill-name}",
  "evals": [
    {
      "id": 1,
      "prompt": "Realistic, specific user prompt",
      "expected_output": "Expected result description",
      "should_trigger": true,
      "files": []
    }
  ]
}
```

**Realistic prompt philosophy:** Eval prompts should be what real users would type — include file paths, personal context, abbreviations, typos, casual language.

Define 2-3 should-trigger + 1-2 should-not-trigger scenarios.

**Confirm workflow + eval:** Present workflow design and eval scenarios as plain text, then ask confirmation via AskUserQuestion.

---

### Phase E: File Generation
**Type**: generate

**Goal:** Create the actual skill files from the confirmed workflow.

**File structure:**
```
.claude/skills/{skill-name}/
├── SKILL.md              # Workflow (1,500-2,000 words max)
├── scripts/              # For script-type steps
│   └── {script}.py
├── references/           # For rag-type steps
│   └── {reference}.md
└── assets/               # Output assets (not loaded into context)
    └── {template/image/etc.}
```

**SKILL.md template:**

```markdown
---
name: {skill-name}
description: This skill should be used when the user asks to "{trigger1}", "{trigger2}", "{trigger3}".
arguments:
  - name: {arg}
    description: {description}
    default: {default}
tools:
  - {tool1}
  - {tool2}
---

# {Display Name}

> {One-line description}

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

{Execution directive}

---

## Workflow

### Step 1: {step name}
**Type**: {prompt/script/api_mcp/rag/review/generate}
{Instructions}

### Step 2: ...

---

## Edge Cases
{Error handling and special situations}

---

## Integration Points
{How this skill connects to other skills/commands}
```

**Description writing (Pushy strategy):**

Claude tends to under-trigger skills, so write descriptions aggressively:
1. Include both Korean and English trigger phrases
2. Add "Make sure to use this skill whenever..." guidance
3. Explain WHY, not just WHAT
4. Include specific user phrases that should activate the skill

**Writing style rules:**
- Imperative form: "Read the file." not "You should read the file."
- Description in third person: "This skill should be used when..."
- Explain WHY before ALWAYS/NEVER rules
- Keep under 2,000 words — split details to `references/`

**Script rules:**
- Python: `#!/usr/bin/env python3`, errors to stderr, results as JSON to stdout
- Bash: `#!/usr/bin/env bash`, `set -euo pipefail`
- Use `${CLAUDE_SKILL_DIR}` for relative paths

**File overwrite:** Always confirm with user before overwriting existing files.

---

### Phase E-verify: Quality Check
**Type**: script

Run verification immediately after file generation:

```bash
python3 "${CLAUDE_SKILL_DIR}/scripts/verify-skill.py" <generated SKILL.md path>
```

| Result | Action |
|--------|--------|
| All PASS | Proceed to Phase F |
| WARN | Inform user, proceed |
| FAIL | Auto-fix → re-verify |

**Auto-fix rules:**
- `third_person` FAIL → Rewrite description as "This skill should be used when..."
- `trigger_phrases` FAIL → Extract keywords from workflow and add
- `imperative_form` FAIL → Convert second-person to imperative
- `references_exist` FAIL → Create missing files or remove references
- `word_count` FAIL → Ask user what to split into `references/`

---

### Phase F: Automated Eval + Benchmark
**Type**: script + agent

**Goal:** Run eval scenarios from Phase D and measure effectiveness.

1. Save eval scenarios as `evals/evals.json`
2. For each eval: spawn 2 subagents simultaneously
   - `with_skill`: Execute with the skill applied
   - `without_skill`: Execute without (baseline)
3. Grade results using `references/agents/grader.md` assertion template
4. Aggregate benchmark: `python -m scripts.aggregate_benchmark`
5. Generate review viewer: `python assets/eval-viewer/generate_review.py`
6. Collect user feedback

**EXECUTE:** After eval, ask via AskUserQuestion:
```json
{
  "questions": [
    {
      "question": "Eval results are ready. What next?",
      "header": "Eval Results",
      "options": [
        {"label": "Looks good, continue (Recommended)", "description": "Move to description optimization."},
        {"label": "Needs improvement", "description": "Improve the skill based on feedback and re-test."},
        {"label": "Modify eval cases", "description": "Change the test scenarios."}
      ],
      "multiSelect": false
    }
  ]
}
```

If "Needs improvement" → Phase G.

---

### Phase G: Iterative Improvement
**Type**: prompt

**Improvement principles** (see `references/improvement-principles.md`):
1. **Generalize** — Fix patterns, not individual test cases
2. **Stay lean** — Remove ineffective instructions
3. **Explain why** — Use reasons instead of ALWAYS/NEVER
4. **Bundle repeated code** — If subagents independently wrote the same script, bundle it

**Loop:**
1. Modify skill based on feedback
2. Re-run eval in new `iteration-{N+1}/` directory
3. Compare with previous iteration via viewer
4. Collect user feedback
5. Repeat until satisfied or no meaningful improvement

---

### Phase H: Description Optimization
**Type**: script

**Goal:** Automatically optimize the skill's description for trigger accuracy.

1. Generate ~20 eval queries (10 should-trigger + 10 should-not-trigger)
2. User reviews via `assets/eval_review.html`
3. Run optimization loop:
   ```bash
   python -m scripts.run_loop \
     --eval-set {eval_set.json} \
     --skill-path {skill path} \
     --max-iterations 5 --verbose
   ```
4. 60/40 train/test split, 3 runs per description (prevents overfitting)
5. Apply `best_description` to SKILL.md frontmatter

---

### Phase I: Packaging (optional)
**Type**: script

If `present_files` tool is available:

```bash
python -m scripts.package_skill {skill folder path}
```

Provides `.skill` file path to user.

---

## Agent Analysis Mode

Triggered by: `/skill-builder analyze .claude/agents/{agent}.md`

1. Read the target agent file (frontmatter + body)
2. Spawn 4 experts in parallel (same as Phase B) to analyze:
   - Planner: Role clarity, purpose fitness
   - User: Trigger naturalness, usability
   - Specialist: Tool assignment, prompt quality
   - Inspector: R&R completeness, edge case coverage
3. Synthesize and propose improvements
4. Ask user whether to apply, partially apply, or skip
5. If applying, use Edit tool to modify agent file

---

## Behavioral Rules

### Must do:
- Always spawn 4 real agents in Phase B (never simulate as text)
- Spawn all 4 simultaneously in one message
- Run verify-skill.py after file generation
- Run eval with baseline comparison
- Use Pushy description strategy
- Keep SKILL.md under 2,000 words
- Split details to `references/`
- Apply writing style rules (imperative form, third-person description)
- Define eval scenarios with should-trigger / should-not-trigger
- Generalize improvements (no hardcoding for specific test cases)

### Must not:
- Simulate expert discussion as text (must use Agent tool)
- Create files without interview
- Use technical jargon without explanation
- Ask more than 4 total questions (Phase A: 1-2, Phase C: 1-2)
- Use api_mcp/rag results as final output without review step
- Overwrite files without user confirmation
- Hardcode eval case solutions

---

## References

Detailed guidance (progressive disclosure):

### Writing Guides
- **`references/writing-style-guide.md`** — SKILL.md writing rules
- **`references/trigger-mechanism.md`** — Trigger mechanism, undertrigger prevention
- **`references/improvement-principles.md`** — Iterative improvement principles

### Eval & Verification
- **`references/eval-guide.md`** — Eval methodology
- **`references/schemas.md`** — evals.json, grading.json, benchmark.json schemas
- **`references/agents/grader.md`** — Assertion grading agent prompt
- **`references/agents/comparator.md`** — Blind A/B comparison agent prompt
- **`references/agents/analyzer.md`** — Benchmark analysis agent prompt

### Design Guides
- **`references/interview-guide.md`** — Interview methodology + persona agent design
- **`references/workflow-step-types.md`** — 6 step types with selection criteria
- **`references/component-type-decision.md`** — Skill vs agent vs command decision tree
- **`references/mcp-catalog.md`** — MCP server catalog
- **`references/agent-templates.md`** — Agent component quality standards

### Scripts & Tools
- **`scripts/`** — verify-skill.py, run_eval.py, run_loop.py, aggregate_benchmark.py, generate_report.py, improve_description.py, package_skill.py, quick_validate.py
- **`assets/eval-viewer/`** — Browser-based eval result viewer
- **`assets/eval_review.html`** — Eval query review template
- **`references/script-templates.md`** — Python/Bash script templates
- **`references/api-mcp-integration.md`** — API/MCP integration guide

---

## Edge Cases

**Vague idea**: Ask ONE clarifying question. Do not proceed without a concrete purpose.

**Skill already exists**: Check `.claude/skills/` for same name. Offer to modify instead of duplicating.

**Agent request**: Redirect to agent-builder skill. Do not create agent files.

**Overly complex workflow**: If >7 steps, suggest splitting into multiple skills.

**Script dependencies**: Document installation steps and add dependency check step.

---

## Integration Points

- **agent-builder**: Agent creation routes to agent-builder. This skill handles skills and commands only.
- **workspace-bootstrap**: New skills go to `.claude/skills/`. workspace-bootstrap verifies structure.
- **onboarding**: Users learn about skill-builder during onboarding Step 6 (pack selection).
- **deep-research**: Research-heavy skills can delegate to deep-research.
- **memory-capture**: Captured patterns from repeated workflows feed into durable memory.
