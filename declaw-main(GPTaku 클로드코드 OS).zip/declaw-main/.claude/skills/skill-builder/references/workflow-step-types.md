# Workflow Step Types

Use these step types to structure a skill workflow.

## Prompt

Use when the assistant should reason, synthesize, or generate text directly.

## Script

Use when execution must be deterministic or repeated.

Example:

```bash
python3 ".claude/skills/{skill-name}/scripts/{filename}.py" [args]
```

## API or MCP

Use when the skill must talk to an external service or tool layer.

Always define:

- what service is used
- what failsafe exists
- what review step follows the external call

## RAG / References

Use when the skill should load local guidance from `references/`.

Example:

```text
Read `.claude/skills/{skill-name}/references/{filename}.md`.
```

## Review

Use when a quality gate is required before presenting or saving a result.

## Generate

Use when the workflow must produce a final artifact such as a report, note, or command file.
