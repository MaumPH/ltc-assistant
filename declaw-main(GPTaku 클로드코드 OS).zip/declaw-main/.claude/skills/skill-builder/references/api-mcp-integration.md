# API and MCP Integration Guide

Use this guide when a skill needs to call an external service.

## Priority Order

1. Use a stable API when one exists.
2. Use MCP when the API is unavailable or the MCP surface is better.
3. Fall back to manual reasoning only when neither exists.

## API Pattern

Implement the call in a helper script and keep credentials outside Claude context.

```bash
python3 ".claude/skills/{skill-name}/scripts/call_{service}_api.py" "$INPUT"
```

## MCP Pattern

Document:

- server name
- tool name
- expected inputs and outputs
- fallback behavior

## Safety Rules

- Never hard-code secrets.
- Prefer environment variables or external credential managers.
- Always state what happens when the external dependency is unavailable.
