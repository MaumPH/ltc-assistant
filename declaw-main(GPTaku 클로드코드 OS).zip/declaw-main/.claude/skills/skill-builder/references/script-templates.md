# Script Templates

Use these patterns when a skill needs a helper script.

## General Rules

- Prefer standard-library-only scripts when possible.
- Write machine-readable output to stdout.
- Write errors to stderr and exit non-zero on failure.
- Use skill-root-relative paths instead of hard-coded absolute paths.

## Python Template

```python
#!/usr/bin/env python3
import json
import sys

def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "missing argument"}), file=sys.stderr)
        sys.exit(1)

    result = {"ok": True, "input": sys.argv[1]}
    print(json.dumps(result))

if __name__ == "__main__":
    main()
```

## Bash Template

```bash
#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "missing argument" >&2
  exit 1
fi

echo "{\"ok\":true,\"input\":\"$1\"}"
```

## Path Guidance

- Prefer `.claude/skills/{skill-name}/scripts/{file}` in workspace examples.
- If the runtime provides a skill-root variable, document it explicitly in the skill.
