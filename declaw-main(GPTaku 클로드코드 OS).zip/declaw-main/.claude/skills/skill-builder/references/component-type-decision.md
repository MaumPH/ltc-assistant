# Component Type Decision Guide

Use this guide to decide whether a new capability should become a skill, an agent, or a slash command.

## Decision Table

| Type | Best for | Trigger mode | State model |
|---|---|---|---|
| Skill | Reusable workflow logic | automatic or explicit | shared with the current session |
| Agent | Delegated role with scoped tools | explicit delegation | isolated role context |
| Command | Operator-facing entrypoint | slash command | shared with the current session |

## Choose a Skill When

- one workflow should be reused across many requests
- the work fits inside the current session context
- the assistant should decide when the capability applies

## Choose an Agent When

- the work benefits from role isolation
- the task needs constrained tools or a fixed responsibility
- the result should come back as a scoped report

## Choose a Command When

- the user needs a stable operator entrypoint
- the action is easier to remember as `/name`
- the workflow should be explicitly invoked rather than auto-triggered

## Neutral Metadata Rule

Do not include source labels or migration-only metadata in active components unless it directly helps runtime behavior.
