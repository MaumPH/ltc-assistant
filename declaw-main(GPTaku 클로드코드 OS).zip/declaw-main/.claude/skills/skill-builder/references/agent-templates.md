# Agent Template Guide

Use this guide when `skill-builder` needs to create a role agent under `.claude/agents/`.

## Standard Structure

```markdown
---
name: {agent-name}
description: Clear one-line role description with trigger context
model: inherit
tools: [Read, Write, ...]
---

# {Agent Name}

Role:
- what this agent owns
- what this agent should inspect or produce

Output format:
- sections the agent should always return

Rules:
- what it must do
- what it must not do
```

## Required Sections

| Section | Why it matters |
|---|---|
| `name` | Stable identifier for delegation |
| `description` | Makes the role discoverable and understandable |
| `tools` | Keeps scope safe and intentional |
| `Role` | Defines responsibility boundaries |
| `Output format` | Makes agent results predictable |
| `Rules` | Prevents overlap and misuse |

## Quality Bar

- Keep the role narrow and specific.
- Prefer a small tool set.
- State when the agent should report instead of changing files.
- Make the output format easy to scan.
- Avoid product- or repo-specific source labels in frontmatter.

## Recommended Metadata

Optional metadata is allowed when it helps routing or discovery, but it should stay neutral:

- `recommended_for`: target workflow category such as `research`, `review`, or `operations`
- `team_compatible`: whether the role is suitable for multi-agent use

Avoid source-tracking fields tied to earlier projects or internal toolchains.
