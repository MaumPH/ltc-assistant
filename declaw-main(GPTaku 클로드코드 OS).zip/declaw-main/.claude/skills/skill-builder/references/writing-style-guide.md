# Writing Style Guide

Use this guide when drafting `SKILL.md` files for declaw.

## Core Style Rules

- Write instructions in imperative form.
- Keep the description in third person.
- Explain why a rule exists when the reason improves compliance.
- Move bulky detail into `references/` and keep `SKILL.md` lean.

## Description Pattern

```yaml
description: This skill should be used when the user asks to "trigger one", "trigger two", or "trigger three".
```

Good descriptions:

- include concrete user phrases
- explain the main capability
- avoid vague labels like "general helper"

## Progressive Disclosure

Keep information in the right layer:

1. metadata for discovery
2. `SKILL.md` for the main workflow
3. `references/`, `scripts/`, and `assets/` for detail

## Tone

- Be direct.
- Be specific.
- Avoid repeating basic facts Claude already knows.
- Prefer short tables over long prose when comparing options.
