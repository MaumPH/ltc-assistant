# Eval Guide

Use this guide to validate a generated skill in a repeatable way.

## Core Checks

Validate these dimensions before calling a skill complete:

| Dimension | What to check |
|---|---|
| Trigger accuracy | Does the skill activate on the intended requests? |
| Workflow completeness | Can the full workflow run end to end? |
| Output quality | Is the result useful and well-structured? |
| Edge-case handling | Does the skill fail safely and recover clearly? |

## Structural Verification

Run the workspace verifier after generating a skill:

```bash
python3 ".claude/skills/skill-builder/scripts/verify-skill.py" path/to/SKILL.md
```

Interpret results this way:

- `PASS`: continue
- `WARN`: review and decide whether to tighten the skill
- `FAIL`: fix and rerun verification

## Eval Scenario Template

```text
Scenario: {name}
Input: {user request}
Expected behavior: {what the skill should do}
Success criteria: {observable outcome}
```

## Manual Review

Structural checks are not enough. Also review:

- factual accuracy
- workflow clarity
- tool usage discipline
- output usefulness

## Regression Practice

When a skill is already in use, keep a small golden set of representative prompts and rerun it after major edits.
