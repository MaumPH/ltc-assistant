---
name: obsidian-pkm
description: This skill should be used when the user asks to "create note", "옵시디언에 저장", "obsidian note", "vault 검색", "daily note", "데일리 노트", "link note", "노트 연결", "PKM", "second brain", "지식 관리", or any Obsidian vault CRUD request.
arguments:
  - name: action
    description: "create", "search", "link", "daily". Default is "search".
    default: "search"
  - name: title
    description: Note title or search query.
    default: ""
  - name: folder
    description: Subfolder within the vault.
    default: ""
tools:
  - Bash
  - Read
  - Write
  - Grep
  - Glob
---

# Obsidian PKM

> File-based CRUD against an Obsidian vault using native Claude Code file tools.

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Resolve vault path, then run the action.

## Workflow

### Step 1: Resolve vault path
```bash
VAULT="${OBSIDIAN_VAULT_PATH:-$HOME/Documents/Obsidian Vault}"
[ -d "$VAULT" ] || echo "Vault not found at: $VAULT"
```
Precedence: `OBSIDIAN_VAULT_PATH` env → `CLAUDE.local.md` entry → default. If missing, ask user to confirm path and save it to `CLAUDE.local.md`. Always quote `"$VAULT"` — vault names contain spaces.

### Step 2: Execute action
- **create**: `TARGET="$VAULT/${FOLDER:+$FOLDER/}$TITLE.md"`; draft with YAML frontmatter (`created`, `tags`); Write file; never overwrite silently.
- **search**: Grep tool for content (`-i $QUERY --include="*.md"`) + Glob for filenames; present clickable `obsidian://` links.
- **link**: Read target note, Grep for related notes, suggest `[[wikilinks]]` — present diff before applying.
- **daily**: `TODAY=$(date +%Y-%m-%d)`; `$VAULT/Daily/$TODAY.md` — if exists, append `## Session HH:MM` subsection; if missing, create from template.

### Step 3: Present or confirm
Writes (create/link/daily):
```
Draft note: {path}
---
{content preview}
---
Save? (yes / edit / cancel)
```
Searches: list top matches with snippet.

## Safety Rules
- Draft-Approve-Execute for every write.
- Never overwrite silently: offer rename/merge/cancel on collision.
- Never auto-delete notes.
- Preserve existing YAML frontmatter when editing.
- Only inject `[[links]]` to notes that exist in the vault.

## Edge Cases
- **Vault path unset**: guide "Set `OBSIDIAN_VAULT_PATH` in shell profile or `CLAUDE.local.md`."
- **Special chars in title** (`/`, `:`, `|`): sanitize to `-` in filename, keep original in `title:` frontmatter.
- **Duplicate title**: propose `{title} (2).md` or `{title} - {context}.md`.
- **Large vault (10k+ notes)**: Grep tool (ripgrep-backed) only.
- **Daily exists**: append subsection, never overwrite.
- **Empty search query**: list 10 most recently modified notes.
- **Binary/image attachments**: ignore, process only `.md`.

## Integration Points
- **daily-sync / morning-briefing**: daily note creation; briefings read yesterday's daily.
- **memory-capture**: promoted memory items can also land as vault notes.
- **deep-research**: research outputs archive here with tags/links.
- **meeting-notes**: meeting summaries flow via `create` action.
- **content-draft**: vault notes source material for blog/newsletter drafts.
