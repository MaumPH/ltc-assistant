---
name: diagram-gen
description: This skill should be used when the user asks to "draw diagram", "다이어그램 그려", "아키텍처 그림", "architecture diagram", "flowchart", "플로우차트", "sequence diagram", "시퀀스 다이어그램", "ER diagram", "ERD", "mermaid", "excalidraw", "그림 그려줘", or any visual diagram generation request.
arguments:
  - name: kind
    description: "architecture", "flow", "sequence", "er", "concept". Default is "flow".
    default: "flow"
  - name: topic
    description: What to diagram.
    default: ""
  - name: format
    description: "mermaid", "excalidraw", "both". Default is "both".
    default: "both"
  - name: output_dir
    description: Where to save diagram files.
    default: "50-resources/diagrams"
tools:
  - Read
  - Write
---

# Diagram Gen

> Generate Mermaid code + Excalidraw JSON from a textual spec. Both outputs shipped by default.

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

If topic is vague, ask ONE clarifying question. Otherwise gather spec and emit diagrams.

## Workflow

### Step 1: Gather spec
Extract from `$ARGUMENTS`: **subject**, **nodes** (entities/services/steps/actors/tables), **edges** (calls/transitions/relationships/messages), **direction**. If <3 nodes, ask: "What are the main components?"

### Step 2: Pick structure by kind
| kind | Mermaid | Excalidraw layout |
|------|---------|-------------------|
| architecture | `graph LR` | left-right zones |
| flow | `flowchart TD` | top-down, diamonds for decisions |
| sequence | `sequenceDiagram` | vertical lanes per actor |
| er | `erDiagram` | rectangles with PK/FK columns |
| concept | `mindmap` | central node, radial children |

### Step 3: Generate Mermaid
Fenced code block with short node IDs, human labels in `[]`/`()`/`{}`, arrow labels via `-->|label|`. Cap at 30 nodes per diagram; split if larger.

### Step 4: Generate Excalidraw JSON (if format includes it)
Envelope: `{"type":"excalidraw","version":2,"source":"declaw-diagram-gen","elements":[...],"appState":{"viewBackgroundColor":"#ffffff"}}`.
Rules:
- Each element has `type,id,x,y,width,height`.
- Labeled shapes: shape has `boundElements:[{id:"t_X",type:"text"}]`; text has `containerId:"X"`, `fontFamily:1`.
- Arrows with bindings: `startBinding`/`endBinding` with `fixedPoint` (`[1,0.5]`=right middle).
- Min shape 120x60; min fontSize 16 body / 20 title.
- z-order: zones → shape → its text → its arrows → next shape.
- Palette: input `#a5d8ff`, output `#b2f2bb`, warn `#ffd8a8`, note `#fff3bf`, data `#c3fae8`.

### Step 5: Save and present
```bash
mkdir -p "$OUTPUT_DIR"  # write <slug>.mmd and <slug>.excalidraw
```
```
Diagram: {topic} ({kind})
Mermaid: {output_dir}/{slug}.mmd
Excalidraw: {output_dir}/{slug}.excalidraw (open at excalidraw.com)
Nodes: {N}  Edges: {M}
```

## Safety Rules
- Never overwrite existing diagrams — append `-v2`, `-v3`.
- No emoji in Excalidraw text (Virgil font skips them).
- No inline render — write files, let user open in excalidraw.com.
- Refuse diagrams with >50 nodes; split instead.

## Edge Cases
- **Topic vague (<3 nodes)**: one clarifying question.
- **Circular references**: Mermaid handles cycles; Excalidraw use dashed arrows for back-edges.
- **5+ actors in sequence**: recommend Mermaid only.
- **ER self-reference**: label relationship clearly.
- **Wide architecture (10+ services)**: split by layer/bounded context.
- **Dark mode**: `appState.theme:"dark"` + dark palette variants.
- **Editable SVG**: out of scope; export from excalidraw.com.

## Integration Points
- **deep-research**: pipeline `research → diagram-gen` for architecture summaries.
- **content-draft**: blog posts embed generated Mermaid blocks.
- **meeting-notes**: sequence diagrams from discussions.
- **presentation**: slide decks embed these diagrams.
- **onboarding**: new-member docs pair with architecture diagrams here.
