---
name: apple-notes
description: This skill should be used when the user asks to "check my notes", "Apple Notes", "노트 확인", "메모 검색", "create a note", "메모 만들어", "save to Notes", or wants to interact with the macOS Notes app.
arguments:
  - name: action
    description: "list", "search", "read", "create", "append". Default is "list".
    default: "list"
  - name: query
    description: Note title, search term, or content to create.
    default: ""
tools:
  - Bash
  - Read
  - Write
---

# Apple Notes

> Interact with macOS Notes.app through CLI. Search, read, create, and append notes.

**Platform**: macOS only.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

Check for macOS, then run the requested action.

---

## Workflow

### Step 1: Check platform and tools
**Type**: script

```bash
[[ "$(uname)" == "Darwin" ]] && echo "MACOS=yes" || echo "MACOS=no"
command -v memo >/dev/null 2>&1 && echo "MEMO=yes" || echo "MEMO=no"
```

If not macOS, report: "Apple Notes is macOS only."
If `memo` CLI not installed: `brew install memo` (recommended) or fall back to AppleScript.

### Step 2: Execute action
**Type**: script

**Action: list** — List recent notes
```bash
memo list --limit 20
# fallback: osascript -e 'tell application "Notes" to get name of every note of default account'
```

**Action: search** — Search notes by keyword
```bash
memo search "$QUERY"
# fallback: osascript with whose clause
```

**Action: read** — Read a specific note
```bash
memo show "$QUERY"
```

**Action: create** — Create a new note
```bash
memo add --title "$TITLE" --body "$BODY"
# fallback: osascript -e 'tell application "Notes" to make new note with properties {name:"...", body:"..."}'
```

**Action: append** — Add content to existing note
```bash
memo append "$TITLE" "$CONTENT"
```

### Step 3: Format and report
**Type**: prompt

Format output cleanly. For list/search, show titles with dates. For read, show full content.

---

## Edge Cases

**Not macOS**: Report incompatibility. Suggest using workspace markdown files instead.
**memo not installed**: Fall back to AppleScript (slower but works natively).
**Note not found**: Report "No note matching '{query}'" and suggest similar titles.
**Large notes**: Truncate display to first 100 lines, note total length.

---

## Integration Points

- **memory-capture**: Save important notes to workspace memory lanes.
- **/inbox-processor**: Route captured Apple Notes to workspace inbox.
