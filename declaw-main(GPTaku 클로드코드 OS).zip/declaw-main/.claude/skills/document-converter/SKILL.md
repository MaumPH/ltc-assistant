---
name: document-converter
description: This skill should be used when the user asks to "convert to PDF", "markdown to docx", "PDF로 변환", "문서 변환", "docx로 만들어", "export as PDF", "convert document", "pandoc", or any file format conversion request involving documents.
arguments:
  - name: source
    description: Path to the source file to convert.
    default: ""
  - name: format
    description: Target format — "pdf", "docx", "html", "md", "txt". Default is "pdf".
    default: "pdf"
tools:
  - Bash
  - Read
  - Glob
---

# Document Converter

> Convert documents between formats using pandoc. Supports markdown, PDF, DOCX, HTML, and plain text.

---

## WHEN TRIGGERED - EXECUTE IMMEDIATELY

If source file is provided, run conversion immediately. If not, ask what to convert.

---

## Workflow

### Step 1: Check pandoc installation
**Type**: script

```bash
command -v pandoc >/dev/null 2>&1 && pandoc --version | head -1 || echo "NOT_INSTALLED"
```

If not installed:
- macOS: `brew install pandoc`
- For PDF output: `brew install --cask basictex` or `brew install wkhtmltopdf`

### Step 2: Validate source file
**Type**: script

If `$ARGUMENTS` provides a source path, verify it exists with Glob.
If no source provided, scan the current directory for convertible files and suggest.

Supported source formats:
- `.md` (Markdown)
- `.docx` (Word)
- `.html` (HTML)
- `.txt` (Plain text)
- `.pdf` (PDF — for extraction to other formats)
- `.rst` (reStructuredText)
- `.org` (Org-mode)

### Step 3: Determine conversion path
**Type**: prompt

Based on source format and target format, select the pandoc command:

| Source → Target | Command |
|----------------|---------|
| md → pdf | `pandoc input.md -o output.pdf --pdf-engine=wkhtmltopdf` |
| md → docx | `pandoc input.md -o output.docx` |
| md → html | `pandoc input.md -o output.html --standalone` |
| docx → md | `pandoc input.docx -o output.md --wrap=none` |
| html → md | `pandoc input.html -o output.md --wrap=none` |
| pdf → txt | `pdftotext input.pdf output.txt` (not pandoc) |
| any → any | `pandoc input.{ext} -o output.{ext}` |

Output filename: same name as input with new extension, in the same directory.

### Step 4: Execute conversion
**Type**: script

```bash
pandoc "$SOURCE" -o "$OUTPUT" $FLAGS 2>&1
```

If PDF engine is missing, fall back:
1. Try `--pdf-engine=wkhtmltopdf`
2. Try `--pdf-engine=pdflatex`
3. Convert to HTML first, then suggest browser print-to-PDF

### Step 5: Verify and report
**Type**: script

Check output file exists and report size:
```bash
ls -lh "$OUTPUT" 2>/dev/null
```

Report:
```
Converted: {source} → {output}
Size: {file size}
Format: {target format}
```

---

## Advanced Options

**Custom styling (PDF/HTML):**
If a CSS file exists at `00-system/01-templates/document-style.css`, apply it:
```bash
pandoc input.md -o output.pdf --css=00-system/01-templates/document-style.css
```

**Table of contents:**
Add `--toc` flag if the document has 3+ headings.

**Batch conversion:**
If user says "convert all markdown files", use Glob to find all `.md` files and convert each:
```bash
for f in *.md; do pandoc "$f" -o "${f%.md}.pdf"; done
```

---

## Edge Cases

**Large files**: Warn if source is >1MB. PDF conversion of very large documents may be slow.

**Images in markdown**: pandoc handles relative image paths. If images are missing, warn and continue without them.

**PDF to markdown**: Quality varies. Warn: "PDF→MD conversion may lose formatting. Review the output."

**No pandoc**: If pandoc cannot be installed, offer alternatives:
- For md→html: use a simple Python script
- For viewing PDFs: `open file.pdf` (macOS)

---

## Integration Points

- **/daily-review**: Export weekly review as PDF for sharing.
- **deep-research**: Convert research reports to DOCX for external distribution.
- **bridge-placeholder**: Document conversion as part of external delivery pipeline.
