# Memory Policy

- store durable knowledge as wiki pages in `memory/wiki/{category}/`
- maintain the wiki index at `memory/MEMORY.md`
- store agent continuity handoff in `memory/daily/YYYY-MM-DD.md`
- store human-facing daily logs in `40-personal/41-daily/YYYY-MM-DD.md`
- leave a next-session handoff before ending long sessions
- only promote stable knowledge into wiki pages
- see `00-system/04-docs/MEMORY_LANES.md` for the lane model

## Wiki Memory Protocol

### Writing (Ingest)

1. Read `memory/MEMORY.md` index — check if a page on this topic already exists
2. If exists → Edit the existing wiki page, update `updated` date in frontmatter
3. If not → Write new page using template, add row to index
4. Update cross-references in related pages (bidirectional)
5. Update page count in index header

### Reading (Query)

1. Read `memory/MEMORY.md` — scan index tables for relevant pages
2. Read relevant wiki pages (1-3 max per query to protect context budget)
3. If index scan finds nothing → Grep `memory/wiki/` for keywords
4. Do not rely on in-context recall alone — wiki pages are the source of truth

### Wiki page template

```markdown
---
title: Page Title
category: decisions|preferences|project-context|tool-patterns|pitfalls
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags: [tag1, tag2]
status: active|draft|archived|superseded
---

# Page Title

## Summary
One paragraph. This text feeds the index.

## Detail
Full content.

## Cross-references
- Related: [Other Page](../category/slug.md)

## Changelog
- YYYY-MM-DD: Description of change
```

### PreCompact (urgent save)

When context compaction is imminent and tool budget is tight:
1. Do NOT create wiki pages (too many tool calls)
2. Append 1-line summaries to `## Unsorted` section at the end of `memory/MEMORY.md`
3. Next session's memory-capture will promote Unsorted items to proper wiki pages

### Wiki health (Lint)

During weekly review or session-closeout:
- Glob `memory/wiki/**/*.md` → compare with index → find orphan pages
- Check cross-references for broken links
- Flag pages with `updated` older than 60 days as review candidates
- If index exceeds 100 lines → consider archiving or merging pages

## File Naming Standards

All date-based files use `YYYY-MM-DD` format (ISO 8601).

| Location | Naming Pattern | Example |
|----------|---------------|---------|
| `memory/daily/` | `YYYY-MM-DD.md` | `2026-04-04.md` |
| `memory/wiki/{category}/` | `{slug}.md` | `three-lane-memory.md` |
| `40-personal/41-daily/` | `YYYY-MM-DD.md` | `2026-04-04.md` |
| `40-personal/42-weekly/` | `YYYY-Www.md` (ISO week) | `2026-W14.md` |
| `sessions/` | `YYYY-MM-DD_{slug}.md` | `2026-04-04_feature-review.md` |
| `20-testing/` | `phase-NN-{slug}.md` | `phase-05-usability-validation.md` |
| `00-inbox/` | `YYYY-MM-DD_{slug}.md` or free-form | `2026-04-04_idea-capture.md` |

Rules:
- dates always come first in filenames for chronological sorting
- slugs use lowercase and hyphens — no spaces, no underscores in slugs
- no personal names or usernames in filenames
- wiki page slugs are descriptive: `english-first-docs.md`, not `pref-001.md`
- templates use the pattern name literally: `daily-note-template.md`, `todo-template.md`

## Proactive Memory Discipline

> Rationale: Hermes MEMORY_GUIDANCE -- prevent context drift and knowledge loss across compaction boundaries.

### Check memory before responding

- Before answering a question about past decisions, preferences, or project context, read `memory/MEMORY.md` index and follow links to relevant wiki pages first.
- Do not rely on in-context recall alone -- wiki pages are the source of truth.

### Periodic checkpoint

- After every 10+ exchanges in a session, pause and assess:
  1. Were any decisions made that are not yet in a wiki page?
  2. Are there new preferences, conventions, or corrections to record?
  3. Is a daily handoff overdue?
- If yes to any, run memory-capture skill or write wiki pages directly before continuing.

### Save before compression

- When context window pressure is high (approaching compaction), prioritize saving to `## Unsorted` in `memory/MEMORY.md` **before** the compaction discards it.
- Signal to the user: "Saving session knowledge before context flush."

### Proactive save triggers

| Trigger | Action |
|---------|--------|
| User states a preference or convention | Create/update wiki page in `preferences/` |
| A non-obvious decision is finalized | Create/update wiki page in `decisions/` |
| Session exceeds 10 exchanges with no save | Run checkpoint (see above) |
| User says "remember this" / "기억해줘" | Invoke memory-capture skill |
| Context compaction imminent | Flush to `## Unsorted` in MEMORY.md |
