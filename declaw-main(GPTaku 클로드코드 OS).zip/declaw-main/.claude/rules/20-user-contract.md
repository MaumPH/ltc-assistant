# User Contract

- assume the workspace should support research, operations, writing, coordination, and code work
- optimize for repeatable workflows
- prefer structures that help the next session continue cleanly
