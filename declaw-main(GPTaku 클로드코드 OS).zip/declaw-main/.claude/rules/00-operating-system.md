# Operating System

- This repository is a workspace OS, not just a code repository.
- Do not collapse everything into `CLAUDE.md`.
- Commands are the operator surface.
- Agents are the role surface.
- Skills are the capability surface.
- Memory is split into durable and continuity lanes.
