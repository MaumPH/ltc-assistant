# Tooling

- external-impacting actions should default to draft-approve-execute
- do not expose raw credentials when wrappers, keychains, or MCP can reduce exposure
- prefer reusable command and skill surfaces over ad hoc prompts

## Tool registry

- all available tools are indexed in `00-system/02-contracts/TOOLS.md`
- detailed reference docs are in `00-system/03-tools/`
- when a task requires a tool, check the index first — do not guess or improvise

## Tool selection order

1. **Tier 1 (built-in)**: always try these first — Read, Write, Edit, Bash, WebSearch, WebFetch, Agent, Computer Use
2. **Tier 2 (CLI)**: if Tier 1 is insufficient, check availability with `which {tool}` then use via Bash
3. **Tier 3 (public API)**: for external data (X, Reddit, HN, Wikipedia), use curl patterns documented in 03-tools/
4. **Tier 4 (connectors)**: only if user has set up the connector — check before attempting

## Tool docs in agent prompts

- when delegating work to a sub-agent that needs a specific tool, Read the tool doc from 03-tools/ and include the relevant pattern in the agent's prompt
- do not assume agents know tool-specific patterns (e.g., Reddit JSON API requires Mobile UA header)

## Wiki memory

- durable knowledge is stored as wiki pages — follow the wiki-memory protocol in `03-tools/wiki-memory.md`
- memory read/write follows the Ingest/Query/Lint operations defined in `50-memory-policy.md`
