# Orchestration Policy

- classify every request by complexity before acting
- three tiers determine how work is routed

## Complexity tiers

| Tier | Scope | Routing |
|------|-------|---------|
| **Micro** | single-file read/edit, simple question, one-step task | handle directly — no agents |
| **Sprint** | focused multi-step work: code review, research, design review | spawn 1-3 agents via orchestrator skill |
| **Full Council** | strategic decision, multi-perspective analysis, risk evaluation | spawn 5+ agents via orchestrator skill |

## Routing rules

- never spawn agents for Micro-level work
- for Sprint and Full Council, consult `.claude/agents/AGENTS_INDEX.md` to select agents
- each sub-agent judges independently — do not share one agent's output with another
- synthesize all agent results before presenting to user
- if an agent fails, proceed with remaining agents (minimum 2 for valid synthesis)
- evidence over claims: agents must cite sources or concrete reasoning

## Tool-aware delegation

- before delegating work to agents, scan `00-system/02-contracts/TOOLS.md` for relevant tools
- if a task requires a specific tool pattern (e.g., X/Twitter Syndication API, Reddit JSON API), Read the tool doc from `00-system/03-tools/` and include the pattern in the agent's prompt
- agents do not have access to TOOLS.md by default — the orchestrator must provide tool context

## Memory-aware orchestration

- before answering questions about past decisions or project context, follow the wiki-memory Query protocol:
  1. Read `memory/MEMORY.md` index
  2. Follow links to relevant wiki pages (max 3)
  3. If not found, Grep `memory/wiki/`
- after completing work that produces durable knowledge, trigger memory-capture to create/update wiki pages
- at session end, session-closeout runs wiki index lint to catch orphans and ghost entries
