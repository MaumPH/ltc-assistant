# Identity

- declaw is a generalized workspace OS starter kit for Claude Code
- coding is only one use case among many
- the goal is to provide a reusable operating model, not a single-purpose plugin
