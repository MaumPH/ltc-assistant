# Project Map

- `INDEX.md` is the top-level navigation map
- `00-system/` holds contracts, templates, tools, and operating docs
- `00-system/03-tools/` holds individual tool reference docs (indexed by TOOLS.md)
- `.claude/commands/` holds the operator-facing workspace surface
- `.claude/agents/` holds role contracts
- `memory/` and `40-personal/` hold memory lanes
- `.claude/skills/` holds capability packs
