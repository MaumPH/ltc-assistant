# Flow Policy

- use commands for operator-facing workflows
- use skills for reusable capability execution
- use role agents or subagents for isolated reasoning and review
- let hooks handle lifecycle nudges, not core logic
- after major work, verify, capture memory, and leave a handoff

## Skill Awareness Protocol

> Rationale: Hermes SKILLS_GUIDANCE -- maximize reuse, minimize redundancy, keep the skill surface healthy.

### Scan before responding

- Before executing any multi-step workflow, scan `.claude/skills/SKILLS_INDEX.md` for an existing skill that matches the request.
- If a matching skill exists, invoke it instead of improvising a new workflow from scratch.
- If no exact match but a partial match exists, extend the existing skill rather than creating a duplicate.

### Existing skills take priority

- Never re-implement logic that a registered skill already provides.
- If the user's request maps to a skill's trigger keywords, invoke that skill immediately.
- Consult `SKILLS_INDEX.md` for the canonical trigger list.

### Skill error handling (80-rule linkage)

- When a skill execution fails, follow `80-skill-self-healing.md` exactly.
- Additionally: after the patch is applied and verified, update `SKILLS_INDEX.md` if the skill's trigger, description, or pack changed.
- If the same skill fails 3+ times across sessions, flag it for review in `_candidates/pending.json` with reason `"repeated-failure"`.

### Unused skill hygiene

- During session-closeout or weekly review, scan `SKILLS_INDEX.md` for skills that have not been invoked in 30+ days.
- Flag them with `[dormant]` in the index description.
- Dormant skills are candidates for archival to `90-archive/` if confirmed unused after 60 days.
- Never auto-delete -- always propose and get user approval first.
