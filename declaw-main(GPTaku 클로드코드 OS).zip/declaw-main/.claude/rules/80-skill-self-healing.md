# Skill Self-Healing Protocol

When a skill execution fails, follow this protocol exactly.

## Error Response Flow

### 1. Diagnose

- Read the error message and traceback fully
- Identify root cause: missing file, bad path, syntax error, API change, permission issue
- Check if the skill has known pitfalls in `memory/MEMORY.md` under "Repeated Pitfalls"

### 2. Draft

- Write a proposed patch as a diff or replacement block
- Explain what the patch changes and why
- Present the patch to the user for approval

### 3. Backup

- Before applying any patch, copy the current skill file to:
  `.claude/skills/_candidates/backups/{skill-name}_{YYYY-MM-DD}.md`
- If a backup for the same skill and date already exists, append a counter:
  `{skill-name}_{YYYY-MM-DD}_2.md`

### 4. Execute

- Apply the approved patch only after explicit user approval
- Verify the patched skill runs without error

### 5. Record

- Append a brief entry to `memory/MEMORY.md` under the "Repeated Pitfalls" section
- Format: `- {skill-name}: {what broke} -> {what fixed it} ({date})`

## Constraints

| Rule | Detail |
|------|--------|
| No auto-apply | Never apply a patch without user approval |
| No hook patching | Never patch a skill while inside a hook execution |
| One per turn | Patch at most one skill per conversational turn |
| Draft-Approve-Execute | Always follow the three-step cycle |
| Backup required | Never overwrite a skill file without creating a backup first |
