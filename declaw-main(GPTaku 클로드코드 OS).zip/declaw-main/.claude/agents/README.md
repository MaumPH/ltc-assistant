# Agents

These files define declaw's role-oriented agents.

## Core roles

- `architect` — structure, decomposition, system judgment
- `reviewer` — risks, regressions, and verification
- `researcher` — evidence gathering and synthesis
- `operator` — workspace maintenance and organizational work

These are long-lived role contracts.
They are not the same as one-off subagent calls.
