# Agents Index

This index is read by the orchestrator to select appropriate agents.

| name | file | model | description | suitable_tasks |
|------|------|-------|-------------|----------------|
| architect | architect.md | sonnet | Structure, decomposition, and system-level design judgment | design decisions, task breakdown, architecture review |
| reviewer | reviewer.md | sonnet | Review outputs for risks, regressions, and quality gaps | code review, quality gates, regression checks |
| researcher | researcher.md | sonnet | Gather evidence, compare sources, and synthesize findings | documentation research, competitive analysis, fact-finding |
| operator | operator.md | haiku | Workspace maintenance, organization, and routine operational tasks | file management, cleanup, inbox triage, index updates |
| analyst | analyst.md | sonnet | Data-driven objective analyst — quantitative analysis, trend detection, pattern recognition, evidence-based conclusions | data analysis, trend detection, pattern recognition, statistical summary |
| advocate | advocate.md | sonnet | Evidence-based opportunity advocate — argues for action with data-backed rationale and upside potential | opportunity assessment, benefit-cost analysis, strategic argumentation |
| critic | critic.md | sonnet | Evidence-based risk assessor — identifies failure scenarios, hidden costs, and downside risks | risk assessment, failure mode analysis, hidden cost detection, assumption challenge |
| planner | planner.md | sonnet | Task decomposition and sequencing specialist — breaks complex work into concrete steps with dependencies | task breakdown, dependency mapping, execution planning, effort estimation |
| implementer | implementer.md | sonnet | Execution specialist — writes code, creates files, modifies configurations, produces testable artifacts | code writing, file creation, configuration changes, implementation |
| chairman | chairman.md | opus | Decision synthesizer — aggregates multiple agent outputs into weighted Go/Pivot/No-Go verdicts | multi-agent synthesis, conflict resolution, final judgment, decision-making |
| gate-keeper | gate-keeper.md | sonnet | Evidence-based GO/NO-GO gate enforcer — verifies phase transitions against completion checklists | quality gates, phase transitions, completion verification, compliance checks |
