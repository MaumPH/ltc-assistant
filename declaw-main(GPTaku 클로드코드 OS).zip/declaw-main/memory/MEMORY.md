# Memory Wiki Index

> Last updated: 2026-04-07 | Pages: 0

## How to use

1. Scan tables below for the topic you need
2. Follow the link to the wiki page
3. If no match, Grep `memory/wiki/` for keywords
4. If still not found, the knowledge has not been captured yet

## Decisions

| Page | Summary | Updated |
|------|---------|---------|

## Preferences

| Page | Summary | Updated |
|------|---------|---------|

## Project Context

| Page | Summary | Updated |
|------|---------|---------|

## Tool Patterns

| Page | Summary | Updated |
|------|---------|---------|

## Pitfalls

| Page | Summary | Updated |
|------|---------|---------|

## Unsorted

> PreCompact 긴급 저장용. 다음 세션에서 정식 위키 페이지로 정리.
