# Sessions

This directory stores session summaries and handoff notes.

Recommended naming:
- `YYYY-MM-DD_topic_summary.md`

Use it for:
- sync summaries
- handoff notes
- temporary synthesis before promoting knowledge elsewhere
