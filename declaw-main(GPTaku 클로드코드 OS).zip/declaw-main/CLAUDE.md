# declaw

> A workspace operating system starter kit for Claude Code.

## Identity

```
declaw = a generalized workspace OS starter kit built on top of Claude Code

Primary roles:
- workspace operating system core
- operator surface (commands, agents, hooks, memory)
- capability packs (assistant, research, bridge)
- self-evolution surface (skill-builder)

This workspace is:
- the place where declaw core scaffold is designed and tested
- a lab for validating how rules, commands, agents, skills, and memory work together
- a working example of the system it is trying to ship
```

## Core principles

| Principle | Meaning |
| --- | --- |
| **English First** | Repo-facing docs, templates, and seed files are written in English by default |
| **Vanilla Tools Only** | Prefer built-in Claude Code tools unless a wrapper or bridge is clearly justified |
| **Draft-Approve-Execute** | Any external or user-visible action should default to proposal first |
| **Credential Isolation** | Never expose raw secrets directly in Claude context when a safer path exists |
| **Be Resourceful** | Read files, inspect context, search, and connect evidence before asking questions |
| **Workspace OS First** | Build commands, agents, memory, index, and structure before adding more capability skills |

## Quick start

```bash
git clone https://github.com/fivetaku/declaw.git
cd declaw
claude
```

Then start with:

- `/onboarding`
- `/setup-workspace`
- `/daily-note`
- `/todo`
- `/thinking-partner`

## Repository structure

```text
declaw/
├── CLAUDE.md
├── README.md
├── INDEX.md
├── .claude/
│   ├── CLAUDE.md
│   ├── commands/
│   ├── agents/
│   ├── rules/
│   ├── bootstrap/
│   ├── skills/
│   └── settings.json
├── 00-inbox/
├── 00-system/
├── 10-backlog/
├── 20-testing/
├── 30-docs/
├── 40-personal/
├── 50-resources/
├── 90-archive/
├── memory/
└── sessions/
```

## Working modes

### 1. Workspace OS mode

Use this repo to validate:
- root constitution
- contract documents
- operator commands
- role agents
- memory lanes
- lifecycle hooks

### Skill awareness

Before executing any multi-step workflow, scan `.claude/skills/SKILLS_INDEX.md` for an existing skill that matches the request. Existing skills take priority over ad-hoc workflows. When adding or modifying skills, keep the index in sync.

### 2. Capability pack mode

Use `.claude/skills/` to maintain reusable capabilities such as:
- morning briefing
- email automation
- web monitoring
- meeting notes
- deep research
- skill building

### 3. Validation mode

For any meaningful change:
1. update the relevant contract or operator surface
2. test it through a realistic usage loop
3. record the result in `20-testing/`
4. only then move to the next phase

## Current direction

declaw is moving from an assistant skill pack toward a full workspace OS core.

Already strong:
- onboarding
- skill-builder
- deep-research
- assistant-oriented capability skills

Still being built:
- `.claude/commands/`
- `.claude/agents/`
- memory lane discipline
- hook usefulness validation
- bridge-ready extension patterns
