English | [한국어](README.ko.md)

# declaw

![declaw](declaw-banner-v9.png)

> **A workspace operating system starter kit for Claude Code.**

Turn Claude Code from a coding assistant into a general-purpose workspace OS.

[Quick Start](#quick-start) • [Commands](#commands) • [Agents](#agents) • [Skills](#skills) • [Memory](#memory-lanes) • [Docs](#documentation)

---

## Quick Start

### 1. Clone

```bash
git clone https://github.com/fivetaku/declaw.git
cd declaw
```

### 2. Launch Claude Code

```bash
claude
```

### 3. Run onboarding

```
/onboarding
```

This walks you through:
- reading the workspace structure
- filling in your identity and user contracts
- validating the scaffold
- choosing which capability packs to activate

### 4. Start working

```
/daily-note          # start today's log
/todo fix auth bug   # capture a task
/thinking-partner    # structure a problem
/setup-workspace     # validate scaffold anytime
```

### How it works

When you clone declaw, you get a **pre-structured workspace** — not just a `CLAUDE.md`. It includes:

```
declaw/
├── CLAUDE.md                  # root constitution
├── INDEX.md                   # workspace navigation map
├── .claude/
│   ├── CLAUDE.md              # control plane (imports contracts + rules)
│   ├── commands/              # 12 operator commands (slash commands)
│   ├── agents/                # 4 role-oriented agents
│   ├── rules/                 # 7 modular rule files (auto-loaded)
│   ├── skills/                # core OS skills
│   ├── bootstrap/             # session start/setup/heartbeat checklists
│   └── settings.json          # lifecycle hooks seed
├── 00-inbox/                  # raw incoming capture
├── 00-system/
│   ├── 01-templates/          # daily note, todo, weekly review templates
│   ├── 02-contracts/          # IDENTITY, SOUL, USER, TOOLS
│   ├── 03-tools/              # 39 tool reference docs (indexed by TOOLS.md)
│   └── 04-docs/               # MEMORY_LANES, OPERATING_MODEL
├── 10-backlog/                # captured ideas and queued work
├── 20-testing/                # validation, gates, reviewer scenarios
├── 30-docs/                   # user-facing guides and pack docs
├── 40-personal/
│   ├── 41-daily/              # human-facing daily logs
│   ├── 42-weekly/             # weekly reviews
│   └── 46-todos/              # active todos
├── 50-resources/              # supporting references
├── 90-archive/                # completed/retired material
├── memory/
│   ├── MEMORY.md              # wiki index (LLM Wiki pattern)
│   ├── wiki/                  # durable knowledge as wiki pages
│   │   ├── decisions/
│   │   ├── preferences/
│   │   ├── project-context/
│   │   ├── tool-patterns/
│   │   └── pitfalls/
│   └── daily/                 # agent continuity handoffs
```

Claude Code auto-loads `CLAUDE.md`, `.claude/CLAUDE.md`, and `.claude/rules/*.md` on every session. The contracts, bootstrap checklists, and memory are pulled in through `@import` and lifecycle hooks. You don't need to configure anything — just clone and start.

---

## Why declaw?

- **Not just CLAUDE.md** — A full workspace structure with contracts, memory lanes, commands, agents, skills, and hooks
- **Not just a coding assistant** — Supports research, operations, knowledge work, personal assistance, content pipelines, and code work
- **Inspired by document-orchestrated agent workspaces** — Rebuilt on Claude Code native features without depending on an external gateway product
- **Repeatable sessions** — Memory lanes + daily handoffs mean each session picks up where the last one left off
- **Operator surface** — 12 slash commands give you a workspace UI, not just a chat interface
- **Role agents** — Delegate to architect, reviewer, researcher, or operator with scoped tool access
- **Extensible** — Add your own commands, agents, skills, and capability packs on top of the core

---

## Commands

Slash commands are the operator-facing workspace UI.

| Command | Description |
|---------|-------------|
| `/onboarding` | First-run walkthrough — read structure, fill contracts, validate scaffold |
| `/setup-workspace` | Validate and complete the workspace scaffold |
| `/daily-note` | Open or create today's daily note |
| `/daily-review` | Review the day, update memory, write handoff |
| `/session-closeout` | Capture end-of-session state and write a clean handoff |
| `/weekly-review` | Create a weekly review from daily notes |
| `/todo [task]` | Capture a task quickly |
| `/todos` | Inspect current todo state |
| `/idea [idea]` | Capture an idea to inbox |
| `/thinking-partner` | Structure a problem through dialogue |
| `/inbox-processor` | Triage and route inbox items |
| `/sync` | Summarize and sync workspace changes |
| `/create-command` | Create a new operator command |

---

## Agents

Role-oriented agents for delegated reasoning. These are long-lived role contracts, not one-off subagent calls.

| Agent | Role | Best for |
|-------|------|----------|
| `architect` | Structure, decomposition, system judgment | Design decisions, task breakdown, architecture review |
| `reviewer` | Risks, regressions, verification | Code review, quality gates, regression checks |
| `researcher` | Evidence gathering and synthesis | Documentation research, competitive analysis, fact-finding |
| `operator` | Workspace maintenance and organization | File management, cleanup, routine workspace operations |

---

## Skills

Skills are reusable capabilities. Core skills power the workspace OS. Pack skills add domain-specific features.

### Core Skills (Workspace OS)

| Skill | Description |
|-------|-------------|
| `workspace-bootstrap` | Scaffold validation and initial setup |
| `memory-capture` | Capture decisions and knowledge into durable memory |
| `daily-sync` | Sync daily notes and continuity handoffs |
| `session-closeout` | End-of-session memory flush and handoff |
| `bridge-placeholder` | Extension point for external service integration |
| `onboarding` | First-run guided setup |
| `skill-builder` | Create new skills from repeated workflows |

### Capability Packs

| Pack | Skills | Description |
|------|--------|-------------|
| **Assistant** | `morning-briefing`, `email-automation`, `calendar`, `habit-tracker` | Personal assistant |
| **Research** | `deep-research`, `web-monitor`, `data-analyst`, `transcribe` | Research and analysis |
| **Content** | `content-draft`, `presentation`, `document-converter` | Content creation |
| **Platform** | `apple-notes`, `apple-reminders` | macOS app integration |
| **DevOps** | `docker-ops`, `ci-monitor` | Infrastructure monitoring |

---

## Memory Lanes

declaw separates memory into three lanes to prevent drift and enable clean session handoffs. Durable memory uses the **LLM Wiki pattern** — an index file pointing to structured wiki pages, no vector DB required.

| Lane | Location | Purpose | Audience |
|------|----------|---------|----------|
| **Wiki (Durable)** | `memory/MEMORY.md` + `memory/wiki/` | Stable knowledge as wiki pages with YAML frontmatter | Agent (auto-loaded index) |
| **Continuity** | `memory/daily/YYYY-MM-DD.md` | Session handoff — what was done, what's next | Agent (session start) |
| **Daily Log** | `40-personal/41-daily/YYYY-MM-DD.md` | Human-readable work journal | Human |

Wiki pages are organized by category (`decisions`, `preferences`, `project-context`, `tool-patterns`, `pitfalls`) and retrieved index-first: read `MEMORY.md` → follow links to relevant pages → Grep if not found.

See `00-system/04-docs/MEMORY_LANES.md` for the full lane model.

---

## Contract Layer

declaw uses modular contracts instead of one giant `CLAUDE.md`.

| Contract | Claude Code mapping | Purpose |
|----------|-------------------|---------|
| `IDENTITY.md` | `.claude/rules/10-identity.md` | Who this workspace agent is |
| `SOUL.md` | `.claude/rules/10-identity.md` | Core values and behavior principles |
| `USER.md` | `CLAUDE.local.md` | Who uses this workspace |
| `TOOLS.md` | `.claude/rules/40-tooling.md` | How tools should be used |

Full contracts live in `00-system/02-contracts/`. Summaries are auto-loaded via `.claude/rules/`.

---

## Tool Registry

declaw maintains a 4-tier tool registry so the agent knows what's available and how to use it.

| Tier | What | Examples |
|------|------|---------|
| **Tier 1 — Built-in** | Always available in Claude Code | Read, Write, Edit, Bash, WebSearch, WebFetch, Agent, Computer Use |
| **Tier 2 — CLI** | Available via Bash (check with `which`) | git, gh, python3, curl, pandoc, ffmpeg, whisper, osascript |
| **Tier 3 — Public API** | No-auth endpoints via curl | X/Twitter Syndication API, Reddit JSON API, Hacker News Firebase API, Wikipedia REST |
| **Tier 4 — Connectors** | User-setup MCP servers | Perplexity, Playwright, Slack, Discord, Linear, Supabase |

- **Index**: `00-system/02-contracts/TOOLS.md` — loaded every session via `@TOOLS.md`
- **Reference docs**: `00-system/03-tools/{tool}.md` — 39 individual tool docs with usage patterns and examples
- **Selection order**: Tier 1 first → Tier 2 if insufficient → Tier 3 for external data → Tier 4 only if configured

When delegating to sub-agents, the orchestrator reads the relevant tool doc and includes the pattern in the agent's prompt — agents don't know tool-specific patterns by default.

---

## Lifecycle Hooks

Hooks automate workspace discipline at session boundaries.

| Event | What it does |
|-------|-------------|
| `SessionStart` | Injects boot checklist and recent memory context |
| `Stop` | Reminds to capture memory and write handoff |
| `PreCompact` | Prompts memory flush before context compression |
| `Setup:init` | Suggests `/setup-workspace` on first run |
| `SubagentStart` | Scoping reminder for delegated work |
| `SubagentStop` | Result format verification |

Configured in `.claude/settings.json`.

---

## Beyond the Terminal

After onboarding, you do not have to stay in the terminal. declaw is designed to work through **Remote Control**, **native messaging channels**, and **Scheduled Tasks**.

When used via channels or remote, the same workspace contracts, commands, and skills still apply. The interaction surface changes, but the operating model stays the same.

### Remote Control — Use from Phone/Browser

Start a remote session:

```bash
claude remote-control
```

This displays a session URL and QR code. Open the URL on any device or scan the QR with the Claude mobile app. Your local files, MCP servers, and workspace stay on your machine.

To enable for all sessions:

```
/config → Enable Remote Control for all sessions → true
```

### Channels — Messaging Bridges

Channels push external messages directly into an active Claude Code session.

Typical pattern:

1. Enable a supported Claude Code channel using the current official workflow.
2. Pair or authorize the sender.
3. Route the incoming work through declaw commands, skills, and memory lanes.

Use `.claude/skills/bridge-placeholder/SKILL.md` as the canonical place to adapt channel and bridge setup to the current Claude Code release. Do not treat README examples as fixed CLI syntax.

### Scheduled Tasks — Recurring Automation

| Method | Runs on | Machine required | Min interval |
|--------|---------|-----------------|-------------|
| `/loop` | Your machine | Yes (session open) | 1 min |
| Cloud tasks | Claude-hosted scheduled execution | No | 1 hour |
| Desktop tasks | Your machine | Yes (app open) | 1 min |

**In-session polling:**

```
/loop 5m check project status and alert if issues
/loop 30m /daily-review
```

**Cloud scheduled tasks** (runs 24/7 without your machine):

```
/schedule daily morning briefing at 9am
```

Or configure at [claude.ai/code/scheduled](https://claude.ai/code/scheduled).

### Feature Comparison

| Feature | Trigger | Best for |
|---------|---------|----------|
| **Remote Control** | You drive from browser/phone | Steering in-progress work from another device |
| **Channels** | External event pushed in | React to messages on Discord/Telegram while away |
| **Scheduled Tasks** | Cron/interval | Morning briefings, periodic health checks, recurring reviews |

All three keep your files local and require claude.ai login.

---

## What declaw is not

- **Not a gateway product** — It composes Claude Code features into a workspace operating model
- **Not only a coding assistant plugin** — Coding is one use case among many
- **Not only a skill collection** — Skills sit on top of the workspace OS core
- **Not a CLAUDE.md template** — It's a full operating structure with 7 layers

---

## Documentation

| Document | Description |
|----------|-------------|
| `INDEX.md` | Workspace navigation map |
| `30-docs/GETTING_STARTED.md` | First-run guide with examples |
| `30-docs/PACKS.md` | Capability pack overview |
| `00-system/04-docs/MEMORY_LANES.md` | Memory lane model and policy |
| `00-system/04-docs/OPERATING_MODEL.md` | End-to-end operating flow |
| `00-system/02-contracts/README.md` | Contract layer explanation |

---

## Requirements

- [Claude Code](https://docs.anthropic.com/claude-code) CLI
- Claude Max/Pro subscription or a supported Claude API key

No other dependencies. No npm install. No build step. Just clone and start.

---

## License

MIT

---

<div align="center">

**Claude Code is the only claw you need.**

</div>
